//
// Created by electricsoul on 19-2-28.
//

#ifndef PROJECT_NNVOXEL_H
#define PROJECT_NNVOXEL_H

#include "GlobalPlanner.h"
#include "Global.h"

namespace nnstation {

    struct NNVoxel {

        // VoxelMap
//        unsigned char space_snapshot[snapshot_x][snapshot_y][snapshot_z];
        /**********************************
        // Pose
        double pos[3];
        double rot[9];
        double rovio_score = 0;

        // stereo angle
        double stereo_angle;

        // way-points
        double wpx[10];
        double wpy[10];
        double wpz[10];

        // control from OA tp Captain
        double next_wp[3];  // x,y,z

        // time matcher
        double sync_rovio_time = 0;
        double sync_stereo_time = 0;
        **********************************/
        double serialized_status_data[49];
    };

    class VoxelClient : NanoClient<NNVoxel>{

    public:
        typedef NanoClient<NNVoxel> Base;
        typedef Base::mtParsed mtParsed;
        typedef Base::mtQueueParsed mtQueueParsed;
        using Base::connect;
        using Base::msgLen;
        using Base::startRecv;
        using Base::close;
        using Base::mutexQueue_;

        uint32_t voxSize_;
        uint32_t infoSize_;
        uint32_t bufSize_;

        VoxelClient(){
            // 计算 bufSize_
            voxSize_ = 0;//(snapshot_x*snapshot_y*snapshot_z)*sizeof(unsigned char);
            infoSize_ = 49*sizeof(double);
            bufSize_ = voxSize_ + infoSize_;
        };

        ~VoxelClient() override = default;

        bool parseData(uint8_t *pMsg, size_t len, mtParsed &parsed) override {
//            memcpy(parsed.space_snapshot, pMsg, voxSize_);
            memcpy(parsed.serialized_status_data, pMsg+ voxSize_, infoSize_);
            return true;
        }
    };

    class VoxelServer : NanoServer<NNVoxel> {
    public:
        typedef NanoServer<NNVoxel> Base;
        typedef Base::mtParsed mtParsed;
        using Base::bind;
        using Base::close;
        uint32_t voxSize_;
        uint32_t infoSize_;
        uint32_t bufSize_;

        VoxelServer() {
            // 计算 bufSize_
            voxSize_ = 0;//(snapshot_x*snapshot_y*snapshot_z)*sizeof(unsigned char);
            infoSize_ = 49*sizeof(double);
            bufSize_ = voxSize_ + infoSize_;
        };

        ~VoxelServer() override = default;

        // 打包发送的数据
        bool send(const mtParsed &parsed) override {

            auto *buf = (uint8_t *) calloc(bufSize_, sizeof(uint8_t));
//            memcpy(buf, parsed.space_snapshot, voxSize_);
            memcpy(buf + voxSize_, parsed.serialized_status_data , infoSize_);
            bool success = sendMsg(buf, bufSize_);
            free(buf);
            return success;
        }

    };


}

#endif //PROJECT_NNVOXEL_H
