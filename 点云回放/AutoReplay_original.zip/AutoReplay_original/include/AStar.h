//
// Created by ZZ_AI_Team on 18-4-29.
//

#ifndef ZZ_PATH_PLANNING_ASTAR_H
#define ZZ_PATH_PLANNING_ASTAR_H

#include <iostream>
#include <iomanip>
#include <map>
#include <set>
#include <array>
#include <vector>
#include <utility>
#include <queue>
#include <tuple>
#include <algorithm>
#include <cstdlib>
#include <unordered_map>
#include <Eigen/Core>

namespace PathPlanning {

struct Grid3DLocation {
    int x, y, z;
};

struct Grid2DLocation {
    int x, y;
};

struct Square2DGrid {
    static std::array<Grid2DLocation, 8> DIRS_8;
    static std::array<Grid2DLocation, 4> DIRS_4;

    int x_length, y_length;
    std::set<Grid2DLocation> walls;

    Square2DGrid(int x, int y) : x_length(x), y_length(y) {}

    bool in_bounds(Grid2DLocation id) const {
        return 0 <= id.x && id.x < x_length &&
               0 <= id.y && id.y < y_length;
    }

    bool passable(Grid2DLocation id) const {
        return walls.find(id) == walls.end();
    }

    std::vector<Grid2DLocation> neighbors(Grid2DLocation id, int dir_num = 4) const {
        std::vector<Grid2DLocation> results;

        if (dir_num == 4) {
            for (Grid2DLocation dir : DIRS_4) {
                Grid2DLocation next{id.x + dir.x, id.y + dir.y};
                if (in_bounds(next) && passable(next)) {
                    results.push_back(next);
                }
            }
        } else if (dir_num == 8) {
            for (Grid2DLocation dir : DIRS_8) {
                Grid2DLocation next{id.x + dir.x, id.y + dir.y};
                if (in_bounds(next) && passable(next)) {
                    results.push_back(next);
                }
            }
        }

        if ((id.x + id.y) % 2 == 0) {
            // aesthetic improvement on square grids
            std::reverse(results.begin(), results.end());
        }

        return results;
    }
};

struct Square3DGrid {
    static std::array<Grid3DLocation, 10> DIRS;

    int x_length, y_length, z_length;
    std::set<Grid3DLocation> walls;

    Square3DGrid(int x, int y, int z)
            : x_length(x), y_length(y), z_length(z) {}

    bool in_bounds(Grid3DLocation id) const {
        return 0 <= id.x && id.x < x_length &&
               0 <= id.y && id.y < y_length &&
               0 <= id.z && id.z < z_length;
    }

    bool passable(Grid3DLocation id) const {
        return walls.find(id) == walls.end();
    }

    std::vector<Grid3DLocation> neighbors(Grid3DLocation id, int dir_num = 4) const {
        std::vector<Grid3DLocation> results;

        for (Grid3DLocation dir : DIRS) {
            Grid3DLocation next{id.x + dir.x, id.y + dir.y, id.z + dir.z};
            if (passable(next)) {
                results.push_back(next);
            }
        }

        if ((id.x + id.y + id.z) % 3 == 0) {
            // aesthetic improvement on square grids
            std::reverse(results.begin(), results.end());
        }

        return results;
    }
};

static void add_2d_wall(Square2DGrid &grid, int x1, int y1, int x2, int y2) {
    for (int x = x1; x <= x2; ++x) {
        for (int y = y1; y <= y2; ++y) {
            grid.walls.insert(Grid2DLocation{x, y});
        }
    }
}

static void remove_2d_wall(Square2DGrid &grid, int x1, int y1, int x2, int y2) {
    for (int x = x1; x <= x2; ++x) {
        for (int y = y1; y <= y2; ++y) {
            grid.walls.erase(Grid2DLocation{x, y});
        }
    }
}

// Helpers for Grid3DLocation

inline bool operator == (Grid3DLocation a, Grid3DLocation b) {
    return a.x == b.x && a.y == b.y && a.z == b.z;
}

inline bool operator != (Grid3DLocation a, Grid3DLocation b) {
    return !(a == b);
}

inline Grid3DLocation operator - (Grid3DLocation a, Grid3DLocation b) {
    return Grid3DLocation{a.x - b.x, a.y - b.y, a.z - b.z};
}

inline Grid3DLocation operator + (Grid3DLocation a, Grid3DLocation b) {
    return Grid3DLocation{a.x + b.x, a.y + b.y, a.z + b.z};
}

inline bool operator < (Grid3DLocation a, Grid3DLocation b) {
    return std::tie(a.x, a.y, a.z) < std::tie(b.x, b.y, b.z);
}

inline std::basic_iostream<char>::basic_ostream& operator<<(std::basic_iostream<char>::basic_ostream& out, const Grid3DLocation& loc) {
    out << '(' << loc.x << ',' << loc.y << ',' << loc.z << ')';
    return out;
}

// Helpers for Grid2DLocation

inline bool operator == (Grid2DLocation a, Grid2DLocation b) {
    return a.x == b.x && a.y == b.y;
}

inline bool operator != (Grid2DLocation a, Grid2DLocation b) {
    return !(a == b);
}

inline bool operator < (Grid2DLocation a, Grid2DLocation b) {
    return std::tie(a.x, a.y) < std::tie(b.x, b.y);
}

inline std::basic_iostream<char>::basic_ostream& operator<<(std::basic_iostream<char>::basic_ostream& out, const Grid2DLocation& loc) {
    out << '(' << loc.x << ',' << loc.y << ')';
    return out;
}

template<typename T, typename priority_t>
struct PriorityQueue {
    typedef std::pair<priority_t, T> PQElement;
    std::priority_queue<PQElement, std::vector<PQElement>, std::greater<PQElement>> elements;

    inline bool empty() const {
        return elements.empty();
    }

    inline void put(T item, priority_t priority) {
        elements.emplace(priority, item);
    }

    T get() {
        T best_item = elements.top().second;
        elements.pop();
        return best_item;
    }
};

template<typename Location>
std::vector<Location> reconstruct_path (Location start,
                                        Location goal,
                                        std::map<Location, Location> came_from) {
    std::vector<Location> path;
    Location current = goal;
    while (current != start) {
        path.push_back(current);
        current = came_from[current];
//        std::cout<<"rec"<<std::endl;
    }
    path.push_back(start); // optional
    std::reverse(path.begin(), path.end());
    return path;
}

// manhatten heuristic is (x + y)
inline double heuristic (Grid3DLocation a, Grid3DLocation b) {
    return std::abs(a.x - b.x) + std::abs(a.y - b.y) + std::abs(a.z- b.z);
}

//inline double heuristic (Grid3DLocation a, Grid3DLocation b) {
//    double dx = std::abs(a.x - b.x);
//    double dy = std::abs(a.y - b.y);
//    double dz = std::abs(a.z - b.z);
//
//    double h;
//    int diag = std::min(std::min(dx, dy), dz);
//    dx -= diag;
//    dy -= diag;
//    dz -= diag;
//
//    if (dx == 0) {
//        h = 1.0 * sqrt(3.0) * diag + sqrt(2.0) * std::min(dy, dz) + 1.0 * std::abs(dy - dz);
//    }
//    if (dy == 0) {
//        h = 1.0 * sqrt(3.0) * diag + sqrt(2.0) * std::min(dx, dz) + 1.0 * std::abs(dx - dz);
//    }
//    if (dz == 0) {
//        h = 1.0 * sqrt(3.0) * diag + sqrt(2.0) * std::min(dx, dy) + 1.0 * std::abs(dx - dy);
//    }
//
//    return h * (1.0 + 1.0 / 100);
//}

inline double heuristic (Grid2DLocation a, Grid2DLocation b) {
//    int dx = std::abs(a.x - b.x);
//    int dy = std::abs(a.y - b.y);
//    return std::max(dx, dy) + SQRT2 * std::min(dx, dy);

    return std::abs(a.x - b.x) + std::abs(a.y - b.y);
}

template<typename Location, typename Graph>
void dijkstra_search(Graph *graph,
                     Location start,
                     Location goal,
                     std::map<Location, Location>& came_from,
                     std::map<Location, double>& cost_so_far) {
    PriorityQueue<Location, double> frontier;
    frontier.put(start, 0);

    came_from[start] = start;
    cost_so_far[start] = 0;

    while (!frontier.empty()) {
        Location current = frontier.get();

        if (current == goal) {
            break;
        }

        for (Location next : graph->neighbors(current)) {
            double new_cost = cost_so_far[current] + 1;
            if (cost_so_far.find(next) == cost_so_far.end()
                || new_cost < cost_so_far[next]) {
                cost_so_far[next] = new_cost;
                came_from[next] = current;
                frontier.put(next, new_cost);
            }
        }
    }
}

template<typename Location, typename Graph>
void a_star_search (Graph *graph,
                    Location start, Location goal,
                    std::map<Location, Location> &came_from) {
    PriorityQueue<Location, double> open_set;
    open_set.put(start, 0);

    std::map<Location, double> close_set;
    close_set[start] = 0;

    came_from[start] = start;

    while (!open_set.empty()) {
        Location current = open_set.get();

        if (current == goal) {
            break;
        }

        for (Location next : graph->neighbors(current, 8)) {
            double new_g_cost = close_set[current] + 1;
            if (close_set.find(next) == close_set.end()
                || new_g_cost < close_set[next]) {
                close_set[next] = new_g_cost;
                double f_score = new_g_cost + heuristic(next, goal);
                open_set.put(next, f_score);
                came_from[next] = current;
            }
        }
    }
}

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_ASTAR_H
