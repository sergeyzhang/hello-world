//
// Created by ZZ_AI_Team on 18-4-29.
//

#ifndef ZZ_PATH_PLANNING_PATHFINDER_H
#define ZZ_PATH_PLANNING_PATHFINDER_H

#include "ChunkVoxel.h"
#include "VoxelMap.h"
#include "AStar.h"
//#include "Dstar.h"
#include "CollisionDetector.h"
//#include <mav_trajectory_generation/eigen_mav_msgs.h>
//#include "mav_trajectory_generation/trajectory.h"
//#include "mav_trajectory_generation/polynomial_optimization_linear.h"

//#include "tic_toc.h"

namespace PathPlanning {

struct DistPosition{
    float dist;
    Eigen::Vector3d p;
};

class DistComapre {
public:
    bool operator()(const DistPosition &p0, const DistPosition &p1) const;
};

class PathFinder {
 public:
    PathFinder(VoxelMap *voxelMap = NULL, CollisionDetector *collision = NULL);

    std::vector<Eigen::Vector3d> find_path(const Eigen::Vector3d &start_point,
                                           const Eigen::Vector3d &target_point);

    inline int get_path_finder_state() {
        return path_finder_state_;
    }

    std::vector<Eigen::Vector3i> get_grid_path() {
        std::vector<Eigen::Vector3i> path;
        for (int i = 0; i < path_grid_points_.size(); ++i) {
            path.push_back(Eigen::Vector3i(path_grid_points_[i].x, path_grid_points_[i].y, path_grid_points_[i].z));
        }
        return path;
    }

    inline cv::Rect get_collision_rect() {
        return collision_rect_;
    }
    inline float get_collision_point_depth() {
        return collision_point_depth_;
    }

 private:
    VoxelMap          *voxel_map_;
    CollisionDetector *collision_detector_;

//    Dstar dstar;

    std::map<int, Chunk_ptr> chunk_map_;
    Square3DGrid *grid_3d_map_;

    Eigen::Vector3i chunk_grid_num_;
    Eigen::Vector3i voxel_grid_num_;
    Eigen::Vector3i voxel_index_num_;

    int voxel_index_in_chunk_;
    int chunk_id_;

    std::vector<Grid3DLocation> path_grid_points_;

    std::set<DistPosition, DistComapre> dist_pos_set_;

    cv::Rect collision_rect_;
    float average_collision_distance_;
    float collision_point_depth_;
    std::vector<Eigen::Vector3d> core_points_w_;

    PathFinderState path_finder_state_;

 private:
    void voxel_map_2_3d_gird_map();

    std::vector<Grid3DLocation> a_star_find_grid_path(Square3DGrid *graph,
                                                      const Grid3DLocation &start_point,
                                                      const Grid3DLocation &target_point);

    void a_star_find_grid_path2(Square3DGrid *graph,
                                const Eigen::Vector3d &start_point,
                                const Eigen::Vector3d &target_point);

//    std::vector<Grid3DLocation> d_star_find_grid_path(int start_x, int start_y, int end_x, int end_y);

    std::vector<Eigen::Vector3d> simplify_grid_path(const std::vector<Eigen::Vector3d> &grid_path, int segment_num);
    std::vector<Eigen::Vector3d> simplify_grid_path(const std::vector<Grid3DLocation> &grid_path);

    Eigen::Vector3d get_safe_target_point(const Eigen::Vector3d &start_point,
                                          const Eigen::Vector3d &target_point);

    // 查找安全的避障点
    std::vector<Eigen::Vector3d> find_safe_core_point(const std::vector<Grid3DLocation> &grid_path,
                                                      const Eigen::Vector3d &target);

    // 根据碰撞点, 最大化找到碰撞体在图像上的区域大小, 返回碰撞方框
    cv::Rect get_collision_rect(const cv::Mat &disparity,
                                const Eigen::Vector2d &uv_collision,
                                const float disparity_value);

    // 根据四个方向生成新的关键点
    Eigen::Vector3d get_new_core_point_from_direction(const PathDirection direction,
                                                      const Eigen::Vector2d &collision_uv);
    // 检测关键点是否有效
    bool check_core_point_valid(const cv::Mat &disparity,
                                const Eigen::Vector3d &core_point,
                                const Eigen::Vector2d &core_uv,
                                const float disparity_value,
                                const Eigen::Vector3d &collision_average_point,
                                const Eigen::Vector3d &mov_dir,
                                const Eigen::Vector3d &cam_pos);

    // 检测关键点在碰撞方框的左右上下方向
    PathDirection check_path_direction(const Eigen::Vector2d &core_uv, const cv::Rect &collision_rect);

    // 检测关键点空间周围是否存在碰撞体
    bool check_core_point_around_collision(const Eigen::Vector3d &core_point, const Eigen::Vector3d &main_dir);

    // 检测关键点投影在视差图上周边视差是否合理有效
    bool check_disparity_valid(const cv::Mat &disparity, const float disparity_value, const Eigen::Vector2d &uv);
};

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_PATHFINDER_H
