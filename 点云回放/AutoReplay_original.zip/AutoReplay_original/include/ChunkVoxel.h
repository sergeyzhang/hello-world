

#ifndef ZZ_PATH_PLANNING_TRUNKVOXEL_H
#define ZZ_PATH_PLANNING_TRUNKVOXEL_H

#include "iostream"
#include <vector>
#include <map>
#include <memory>
#include <Eigen/Core>

namespace PathPlanning {


#define VOXEL_SIZE_CM           20.0
#define CHUNK_SIDE_SIZE_VOXEL   10.0
#define VOXEL_SIZE_M            (VOXEL_SIZE_CM / 100.0)
#define CHUNK_SIDE2_SIZE_VOXEL  (CHUNK_SIDE_SIZE_VOXEL * CHUNK_SIDE_SIZE_VOXEL)
#define CHUNK_SIDE_SIZE_CM      (VOXEL_SIZE_CM * CHUNK_SIDE_SIZE_VOXEL)
#define CHUNK_SIDE_SIZE_M       (VOXEL_SIZE_CM * CHUNK_SIDE_SIZE_VOXEL / 100.0)
#define CHUNK_TOTAL_VOXEL_NUM   (CHUNK_SIDE_SIZE_VOXEL * CHUNK_SIDE_SIZE_VOXEL * CHUNK_SIDE_SIZE_VOXEL)

#define CENTRE_OFFSET_M         500.0
#define AREA_1         CENTRE_OFFSET_M*2
#define AREA_2         AREA_1*AREA_1
//#define CENTRE_OFFSET_M         CHUNK_SIDE_SIZE_VOXEL * CHUNK_SIDE_SIZE_VOXEL * CHUNK_SIDE_SIZE_VOXEL

#define VOXEL_OBS_THRESHOLD 7

static int chunk_grid_num_2_id(const Eigen::Vector3i &grid_num) {
    // 构造唯一的chunk id, 以便再map中查找
    // id = 1000 * x + 10 * y + x
    return  AREA_2 * (grid_num(2)) + AREA_1 * (grid_num(1)) + (grid_num(0));
}

static int voxel_index_num_2_index(const Eigen::Vector3i &index_num) {
    // voxel在chunk里面的vector的index
    // index_num = 25 * int_v_z + 5 * int_v_y + int_v_x
    return  CHUNK_SIDE2_SIZE_VOXEL * index_num(2) + CHUNK_SIDE_SIZE_VOXEL * index_num(1) + index_num(0);
}

static void grid_world_position(const Eigen::Vector3d &p,
                                Eigen::Vector3i &chunk_grid_num,
                                Eigen::Vector3i &voxel_grid_num,
                                Eigen::Vector3i &voxel_index_num,
                                int &voxel_index_in_chunk,
                                int &chunk_id) {
    double x_double = (p[0] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;
    double y_double = (p[1] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;
    double z_double = (p[2] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;

    int x_c_int = floor(x_double);
    int y_c_int = floor(y_double);
    int z_c_int = floor(z_double);

    chunk_grid_num[0] = x_c_int;
    chunk_grid_num[1] = y_c_int;
    chunk_grid_num[2] = z_c_int;
    chunk_id = chunk_grid_num_2_id(chunk_grid_num);

//    Eigen::Vector3i voxel_index_num;
    voxel_index_num[0] = floor((x_double - x_c_int) * CHUNK_SIDE_SIZE_CM / VOXEL_SIZE_CM);
    voxel_index_num[1] = floor((y_double - y_c_int) * CHUNK_SIDE_SIZE_CM / VOXEL_SIZE_CM);
    voxel_index_num[2] = floor((z_double - z_c_int) * CHUNK_SIDE_SIZE_CM / VOXEL_SIZE_CM);
    voxel_index_in_chunk = voxel_index_num_2_index(voxel_index_num);

    voxel_grid_num[0] = floor((p[0] + CENTRE_OFFSET_M) / VOXEL_SIZE_M);
    voxel_grid_num[1] = floor((p[1] + CENTRE_OFFSET_M) / VOXEL_SIZE_M);
    voxel_grid_num[2] = floor((p[2] + CENTRE_OFFSET_M) / VOXEL_SIZE_M);
}

static void grid_world_position(const Eigen::Vector3d &p, int &chunk_id, Eigen::Vector3i &chunk_grid_num) {
    double x_double = (p[0] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;
    double y_double = (p[1] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;
    double z_double = (p[2] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;

    int x_c_int = floor(x_double);
    int y_c_int = floor(y_double);
    int z_c_int = floor(z_double);

    chunk_grid_num[0] = x_c_int;
    chunk_grid_num[1] = y_c_int;
    chunk_grid_num[2] = z_c_int;

    chunk_id = chunk_grid_num_2_id(chunk_grid_num);
}

static void grid_world_position(const Eigen::Vector3d &p,
                                int &voxel_index_in_chunk,
                                int &chunk_id) {
    double x_double = (p[0] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;
    double y_double = (p[1] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;
    double z_double = (p[2] + CENTRE_OFFSET_M) / CHUNK_SIDE_SIZE_M;

    int x_c_int = floor(x_double);
    int y_c_int = floor(y_double);
    int z_c_int = floor(z_double);

    Eigen::Vector3i chunk_grid_num;
    chunk_grid_num[0] = x_c_int;
    chunk_grid_num[1] = y_c_int;
    chunk_grid_num[2] = z_c_int;
    chunk_id = chunk_grid_num_2_id(chunk_grid_num);

    Eigen::Vector3i voxel_index_num;
    voxel_index_num[0] = (int)((x_double - x_c_int) * CHUNK_SIDE_SIZE_CM / VOXEL_SIZE_CM);
    voxel_index_num[1] = (int)((y_double - y_c_int) * CHUNK_SIDE_SIZE_CM / VOXEL_SIZE_CM);
    voxel_index_num[2] = (int)((z_double - z_c_int) * CHUNK_SIDE_SIZE_CM / VOXEL_SIZE_CM);
    voxel_index_in_chunk = voxel_index_num_2_index(voxel_index_num);
}

static void grid_world_position(const Eigen::Vector3d &p, Eigen::Vector3i &voxel_grid_num) {
    voxel_grid_num[0] = (int)((p[0] + CENTRE_OFFSET_M) / VOXEL_SIZE_M);
    voxel_grid_num[1] = (int)((p[1] + CENTRE_OFFSET_M) / VOXEL_SIZE_M);
    voxel_grid_num[2] = (int)((p[2] + CENTRE_OFFSET_M) / VOXEL_SIZE_M);
}

static Eigen::Vector3d chunk_grid_num_2_pos(const Eigen::Vector3i &chunk_grid_num) {
    Eigen::Vector3d chunk_pos;
    double x_grid = (double)chunk_grid_num[0] ;
    double y_grid = (double)chunk_grid_num[1] ;
    double z_grid = (double)chunk_grid_num[2] ;
    chunk_pos[0] = x_grid * CHUNK_SIDE_SIZE_M - CENTRE_OFFSET_M;
    chunk_pos[1] = y_grid * CHUNK_SIDE_SIZE_M - CENTRE_OFFSET_M;
    chunk_pos[2] = z_grid * CHUNK_SIDE_SIZE_M - CENTRE_OFFSET_M;
    return chunk_pos;
}

static Eigen::Vector3d voxel_grid_num_2_pos(const Eigen::Vector3i &voxel_grid_num) {
    Eigen::Vector3d voxel_pos;
    double x_grid = (double)voxel_grid_num[0] ;
    double y_grid = (double)voxel_grid_num[1] ;
    double z_grid = (double)voxel_grid_num[2] ;
    voxel_pos[0] = x_grid * VOXEL_SIZE_M - CENTRE_OFFSET_M;
    voxel_pos[1] = y_grid * VOXEL_SIZE_M - CENTRE_OFFSET_M;
    voxel_pos[2] = z_grid * VOXEL_SIZE_M - CENTRE_OFFSET_M;
    return voxel_pos;
}

struct Voxel {
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    Voxel() : is_valid(false), obs(0), collision_level(0) {}
    Voxel(const Eigen::Vector3d &pos,
          const int t_id,
          const int v_index,
          const Eigen::Vector3i &grid_num) :
            world_pos(pos),
            is_valid(false),
            thunk_id(t_id),
            voxel_index_in_chunk(v_index),
            voxel_grid_num(grid_num),
            obs(1),
            collision_level(0){}

    Eigen::Vector3d world_pos;

    bool is_valid;

    int thunk_id;
    int voxel_index_in_chunk;
    Eigen::Vector3i voxel_grid_num;

    int obs;
    int time_id;
    int collision_level;

    bool is_focus =false;
};

typedef std::shared_ptr<Voxel> Voxel_ptr;

struct Chunk {
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    Chunk() {
        reset_voxels();
        active_voxels=0;
    }
    Chunk(const int id, const Eigen::Vector3i &grid_num) {
        reset_voxels();
        chunk_id = id;
        chunk_pos = chunk_grid_num_2_pos(grid_num);
        chunk_grid_num = grid_num;
        active_voxels=0;
    }

    void reset_voxels() {
        voxels.clear();
        voxels.resize(CHUNK_TOTAL_VOXEL_NUM, NULL);
    }

    void increase_active_voxels()
    {
        active_voxels++;
    }
    void decrease_active_voxels()
    {
        if(active_voxels>0)active_voxels--;
    }
    double get_active_percent()
    {
        double ar = ((double)(active_voxels))/((double)(CHUNK_TOTAL_VOXEL_NUM));
        return ar;
    }

    int time_id;

    Eigen::Vector3i chunk_grid_num;
    Eigen::Vector3d chunk_pos;
    int chunk_id;

    int active_voxels;

    std::vector<Voxel_ptr> voxels;
};

typedef std::shared_ptr<Chunk> Chunk_ptr;

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_TRUNKVOXEL_H
