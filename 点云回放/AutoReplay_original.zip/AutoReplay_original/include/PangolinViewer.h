//
// Created by ZZ_AI_Team on 17-2-22.
//

#ifndef SLAM_PANGOLINVIEWER_H
#define SLAM_PANGOLINVIEWER_H

#include "opencv2/opencv.hpp"
#include <mutex>
#include <thread>
#include <Eigen/Core>
#include <unistd.h>

namespace pangolin {
class OpenGlMatrix;
}

class PangolinViewer {
public :
    PangolinViewer(bool enable_random_map = false);
    ~PangolinViewer();

    // Main thread function. Draw points, keyframes, the current camera pose and the trajectory
    // Drawing is refreshed according to the camera fps. We use Pangolin.
    void Run();

    void send_slam_all_map_points_color(const std::vector<cv::Point3d> &color);
    void send_slam_data_to_viewer(const cv::Mat &T_c_2_w,
                                  const std::vector<cv::Point3d> &all_map_points,
                                  const std::vector<cv::Point3d> &ref_map_points,
                                  const std::vector<cv::Mat> &key_frames_pose);

    void send_voxel_map(const std::vector<Eigen::Vector4d> &voxel_grid_map);
    void send_chunk_map(const std::vector<Eigen::Vector3d> &chunk_map);
    void send_astar_path(const std::vector<Eigen::Vector3i> &path);
    void send_core_point_path(const std::vector<Eigen::Vector3d> &points);

    void send_random_map(const std::vector<Eigen::Vector3i> &map);
    inline void send_start_end_point(const std::vector<Eigen::Vector3d> &point) {
        start_end_point = point;
    }

    inline void set_dist(float &caution_dist, float &dangerous_dist, float &emergency_dist, Eigen::Vector3d &cam_mov_dir_c) {
        _c_dist = caution_dist;
        _d_dist = dangerous_dist;
        _e_dist = emergency_dist;
        _mov_dir_c = cam_mov_dir_c;
    }

    inline void send_trajectory_data(const std::vector<Eigen::Vector3d> &positions,
                                     const std::vector<Eigen::Vector3d> &sampled_velocities,
                                     const std::vector<Eigen::Matrix4d> &sampled_poses,
                                     const std::vector<Eigen::Vector3d> &core_points) {
        std::unique_lock<std::mutex> lock(_mutex_T);
        trajectory_positions = positions;
        sampled_trajectory_velocities = sampled_velocities;
        sampled_trajectory_poses = sampled_poses;
        trajectory_core_points = core_points;
    }
    inline void send_trajectory2_data(const std::vector<Eigen::Vector3d> &positions) {
        std::unique_lock<std::mutex> lock(_mutex_T);
        trajectory_positions2 = positions;
    }
    inline void send_motion_trajectory_position(const Eigen::Vector3d &pos) {
        motion_position_along_trajectory = pos;
    }

    inline bool get_re_generate_value() {
        return _re_generate_trajectory;
    }
    inline void set_re_generate_value(bool v) {
        _re_generate_trajectory = v;
    }

    void reset_data();

public :
    pangolin::OpenGlMatrix   *_T_c_2_w;

    // slam data
    std::vector<cv::Point3d> _all_map_point_color;
    std::vector<cv::Point3d> _all_map_point;
    std::vector<cv::Point3d> _ref_map_point;
    std::vector<cv::Mat>     _key_frames_pose;
    std::vector<cv::Point3d> _all_positions;

    // voxel data
    std::vector<Eigen::Vector3d> _astar_path_data;
    std::vector<Eigen::Vector4d> _voxel_map_data;
    std::vector<Eigen::Vector3d> _chunk_map_data;

    Eigen::Vector3d probe_vector;
    Eigen::Vector3d control_vector;
    Eigen::Vector3d self_t;

    // collision data
    float _c_dist, _d_dist, _e_dist;
    Eigen::Vector3d _mov_dir_c;

    // random tree data
    bool _enable_draw_random_tree;
    std::vector<Eigen::Vector3d> random_tree_map;
    std::vector<Eigen::Vector3d> start_end_point;

    // trajectory generation data
    std::vector<Eigen::Vector3d> trajectory_positions;
    std::vector<Eigen::Vector3d> trajectory_positions2;
    std::vector<Eigen::Vector3d> sampled_trajectory_velocities;
    std::vector<Eigen::Matrix4d> sampled_trajectory_poses;
    std::vector<Eigen::Vector3d> trajectory_core_points;
    Eigen::Vector3d motion_position_along_trajectory;
    bool _re_generate_trajectory;

    float _view_point_X, _view_point_Y, _view_point_Z, _view_point_F;
    float _camera_size;
    float _point_size;
    float _camera_line_width;
    float _keyFrame_size;
    float _keyFrame_line_width;
    float _trajectory_line_width;


    bool system_pause = false;
    bool last_frame_t = false;
    bool next_frame_t = false;


    void cv_mat_2_gl_matrix(const cv::Mat &pose_mat, pangolin::OpenGlMatrix &T_c_2_w);

    void draw_current_camera(const pangolin::OpenGlMatrix &T_c_2_w);
    void draw_all_map_points(const bool b_draw_poinst);
    void draw_ref_map_points(const bool b_draw_poinst);
    void draw_keyFrames(const bool b_draw_KF);
    void draw_trajectory();

    void draw_voxel_map();
    void draw_astar_path();
    void draw_fix_color_cube(float x, float y, float z, float size);
    void draw_your_color_cube(float x, float y, float z, float size, Eigen::Vector4d rgb);

    void draw_random_tree();

    void draw_trajectory_generation_data();

    bool check_finish();

    bool       _b_finished;
    std::mutex _mutex_finish;
    std::mutex _mutex_T;

    std::thread* _viewer_thread;
};

#endif //SLAM_PANGOLINVIEWER_H
