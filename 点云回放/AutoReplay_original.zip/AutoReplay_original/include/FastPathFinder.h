//
// Created by ZZ_AI_Team on 7/23/18.
//

#ifndef ZZ_PATH_PLANNING_FASTPATHFINDER_H
#define ZZ_PATH_PLANNING_FASTPATHFINDER_H

#include "Global.h"
#include "Camera.h"
#include "Eigen/Core"

namespace PathPlanning {

class FastPathFinder {
 public:
    FastPathFinder();
    FastPathFinder(std::string setting_file);

    void add_disparity_T(const cv::Mat &disparity, const double t);
    Eigen::Vector3d fast_find_safe_core_point(const Sophus::SE3d &T_wc,
                                              const double timestamp);

    Eigen::Vector3d fast_find_safe_core_point(const cv::Mat &disparity, const Sophus::SE3d &T_wc);

    inline Eigen::Vector3d get_look_dir() {
        return look_dir;
    }
    inline Sophus::SE3d get_T_wc() {
        return T_wc_;
    }
    inline CollisionStatus get_collision_status() {
        return collisionStatus;
    }
    inline float get_collision_depth() {
        return collision_depth;
    }

 private:
    std::vector<Eigen::Vector3d> caution_points_c;
    std::vector<Eigen::Vector3d> dangerous_points_c;
    std::vector<Eigen::Vector3d> emergency_points_c;

    Eigen::Vector2d centre_uv;
    std::vector<Eigen::Vector2d> caution_points_uv;
    std::vector<Eigen::Vector2d> dangerous_points_uv;
    std::vector<Eigen::Vector2d> emergency_points_uv;

    std::vector<Eigen::Vector2d> base_caution_points_uv;
    std::vector<Eigen::Vector2d> base_dangerous_points_uv;
    std::vector<Eigen::Vector2d> base_emergency_points_uv;

    float centre_depth;
    std::vector<float> caution_points_depth;
    std::vector<float> dangerous_points_depth;
    std::vector<float> emergency_points_depth;

    CollisionStatus collisionStatus;

    cv::Rect collision_rect;
    cv::Rect safe_rect;
    Eigen::Vector2d collision_uv;
    float collision_depth;

    std::vector<RtTime> Rt_time_vec_;
    std::vector<DisparityTime> depth_data_vec_;

    Sophus::SE3d T_cw_;
    Sophus::SE3d T_wc_;
    RtTime curr_T_t_;

    Eigen::Vector3d look_dir;

 private:
    void init();

    CollisionStatus check_depth_status(const float depth);
    void get_collision_status(Eigen::Vector2d &collision_uv, float &collision_depth);

    // 查找安全的避障点
    std::vector<Eigen::Vector3d> find_safe_core_point(const Eigen::Vector3d &start_point,
                                                      const Eigen::Vector3d &target);

    // 根据碰撞点, 最大化找到碰撞体在图像上的区域大小, 返回碰撞方框
    cv::Rect get_collision_rect(const cv::Mat &disparity,
                                const Eigen::Vector2d &uv_collision,
                                const float disparity_value);

    cv::Rect get_safe_rect(const cv::Mat &disparity,
                           const Eigen::Vector2d &uv_collision,
                           const float disparity_value);

    // 根据四个方向生成新的关键点
    Eigen::Vector3d get_new_core_point_from_direction(const PathDirection direction,
                                                      const Eigen::Vector2d &collision_uv);
    // 检测关键点是否有效
    bool check_core_point_valid(const cv::Mat &disparity,
                                const Eigen::Vector3d &core_point,
                                const Eigen::Vector2d &core_uv,
                                const float disparity_value,
                                const PathDirection &direction);

    // 检测关键点在碰撞方框的左右上下方向
    PathDirection check_path_direction(const Eigen::Vector2d &core_uv, const cv::Rect &collision_rect);

    // 检测关键点投影在视差图上周边视差是否合理有效
    bool check_disparity_valid(const cv::Mat &disparity, const float disparity_value, const Eigen::Vector2d &uv);

    bool check_poor_disparity(const cv::Mat &disparity);
};

}

#endif  // ZZ_PATH_PLANNING_FASTPATHFINDER_H
