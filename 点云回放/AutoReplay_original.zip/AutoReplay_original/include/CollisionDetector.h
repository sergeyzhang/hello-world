//
// Created by ZZ_AI_Team on 18-4-29.
//

#ifndef ZZ_PATH_PLANNING_COLLISIONDETECTOR_H
#define ZZ_PATH_PLANNING_COLLISIONDETECTOR_H

#include "VoxelMap.h"
#include "FastPathFinder.h"

namespace PathPlanning {

#define CENTRE_RECT_W 100
#define CENTRE_RECT_H 60

class CollisionDetector {
 public:
    CollisionDetector(VoxelMap *voxel_map);

    void set_velocity(const Eigen::Vector3d &velocity_w);
    CollisionStatus detect_collision();

    inline void get_dist(float &c_dist, float &d_dist, float &e_dist, Eigen::Vector3d &mov_dir) {
        c_dist = caution_dist_;
        d_dist = dangerous_dist_;
        e_dist = emergency_dist_;
        mov_dir = cam_mov_dir_w_;
    }

    inline float get_average_collision_dist() {
        return average_collision_distance_;
    }

    inline float get_mean_depth() {
        return mean_depth_;
    }

    inline CollisionStatus get_collision_status() {
        return collision_status_;
    }

    inline Eigen::Vector3d get_average_v_w() {
        return avg_v_w;
    }

    inline Eigen::Vector3d get_cam_mov_dir() {
        return cam_mov_dir_w_;
    }

    inline std::vector<Eigen::Vector3d> get_collision_voxels_pos() {
        return collision_voxel_pos_vec_;
    }

    inline Eigen::Vector3d get_core_point() {
        return core_point_;
    }

    inline Eigen::Vector3d get_collision_3d_point() {
        return collision_average_point;
    }

 private:
    VoxelMap *voxel_map_;
    FastPathFinder fast_path_finder;

    double last_timestamp_;
    Eigen::Vector3d last_pos_;

    bool has_velocity_value_;
    Eigen::Vector3d velocity_w_;

    Eigen::Vector3d cam_mov_dir_w_;

    Eigen::Vector3d velocity_queue_sum_;
    std::queue<Eigen::Vector3d> v_queue_;
    Eigen::Vector3d avg_v_w;

    float caution_dist_;
    float dangerous_dist_;
    float emergency_dist_;

    float average_collision_distance_;

    Eigen::Vector3d collision_average_point;

    CollisionStatus collision_status_;

    float mean_depth_;

    float emergency_disparity_value_;
    float caution_disparity_value_;

    cv::Mat emergency_map_;
    cv::Mat caution_map_;

    std::vector<Eigen::Vector3d> collision_voxel_pos_vec_;
    std::vector<Eigen::Vector3d> caution_pos_vec_;
    std::vector<Eigen::Vector3d> dangerous_pos_vec_;

    Eigen::Vector3d core_point_;

 private:
    void analysis_disparity(CollisionStatus &status);
};

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_COLLISIONDETECTOR_H
