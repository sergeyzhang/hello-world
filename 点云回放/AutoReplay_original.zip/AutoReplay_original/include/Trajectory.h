//
// Created by electricsoul on 18-12-24.
//

#include <iostream>
#include <zconf.h>
#include <sys/shm.h>
#include <fstream>
#include <string>
#include <map>
#include <sys/time.h>
#include <hash_map>

#include <opencv2/opencv.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/calib3d/calib3d.hpp"

#include <Eigen/Core>
#include <Eigen/Dense>

using namespace std;
using namespace cv;
using namespace Eigen;

// test of trajectroy optimizer
Vector3d startVel;
Vector3d startAcc;

int m=3; // number of segments in the trajectory

std::vector<double> qp_cost;
Eigen::MatrixXd _A; // Mapping matrix
Eigen::MatrixXd _Q; // Hessian matrix
Eigen::MatrixXd _C; // Selection matrix
Eigen::MatrixXd _L; // A.inv() * C.transpose()

Eigen::MatrixXd _R;
Eigen::MatrixXd _Rff;
Eigen::MatrixXd _Rpp;
Eigen::MatrixXd _Rpf;
Eigen::MatrixXd _Rfp;

Eigen::VectorXd _Pxi;
Eigen::VectorXd _Pyi;
Eigen::VectorXd _Pzi;

Eigen::VectorXd _Dx;
Eigen::VectorXd _Dy;
Eigen::VectorXd _Dz;

Eigen::MatrixXd _Path;
Eigen::VectorXd _Time;

int way_point_n=0;
//double v_mean=4;
//double acc_limit=10;
//double omi_limit=10;

/*
 * 轨迹规划平均速度
 */
double v_mean=0.5;

double acc_limit=10;
double omi_limit=10;

bool simulate=1;
//bool simulate=0;

bool trajectory_optimization_and_simulation=1;
//bool trajectory_optimization_and_simulation=0;

bool disturb=false;

//bool random_disturb=1;
bool random_disturb=0;

Eigen::Vector3d old_start(3);


Eigen::MatrixXd PolyQPGeneration1(
        const Eigen::MatrixXd &Path,
        const Eigen::VectorXd &Time,
        const double length_weight,
        const int &type,
        Eigen::Vector3d Vel_Start=Eigen::Vector3d(0,0,0),
        Eigen::Vector3d Acc_Start=Eigen::Vector3d(0,0,0),
        Eigen::Vector3d Omi_Start=Eigen::Vector3d(0,0,0),
        Eigen::Vector3d Vel_End=Eigen::Vector3d(0,0,0),
        Eigen::Vector3d Acc_End=Eigen::Vector3d(0,0,0),
        Eigen::Vector3d Omi_End=Eigen::Vector3d(0,0,0)
)
{
    startVel = Vel_Start;
    startAcc = Acc_Start;
    m = Time.size();
    MatrixXd PolyCoeff(m, 3 * 8);
    VectorXd Px(8 * m), Py(8 * m), Pz(8 * m);

    int num_f, num_p; // number of fixed and free variables
    int num_d;        // number of all segments' derivatives
    const static auto Factorial = [](int x){
        int fac = 1;

        for(int i = x; i > 0; i--)
            fac = fac * i;

        return fac;
    };

    /*   Produce Mapping Matrix A to the entire trajectory.   */
    MatrixXd Ab;
    MatrixXd A = MatrixXd::Zero(m * 8, m * 8);
    for(int k = 0; k < m; k++){
        Ab = Eigen::MatrixXd::Zero(8, 8);
        for(int i = 0; i < 4; i++){
            Ab(2 * i, i) = Factorial(i);
            for(int j = i; j < 8; j++)
                Ab( 2 * i + 1, j ) = Factorial(j) / Factorial( j - i ) * pow( Time(k), j - i );
        }
        A.block(k * 8, k * 8, 8, 8) = Ab;
    }
    _A = A;

    /*   Produce the dereivatives in X, Y and Z axis directly.  */
    VectorXd Dx = VectorXd::Zero(m * 8);
    VectorXd Dy = VectorXd::Zero(m * 8);
    VectorXd Dz = VectorXd::Zero(m * 8);

    for(int k = 1; k < (m + 1); k ++ ){
        Dx((k-1)*8 + 0) = Path(k - 1, 0); Dx((k-1)*8 + 1) = Path(k, 0);
        Dy((k-1)*8 + 0) = Path(k - 1, 1); Dy((k-1)*8 + 1) = Path(k, 1);
        Dz((k-1)*8 + 0) = Path(k - 1, 2); Dz((k-1)*8 + 1) = Path(k, 2);

        if( k == 1 ){
            Dx((k-1)*8 + 2) = Vel_Start(0);
            Dy((k-1)*8 + 2) = Vel_Start(1);
            Dz((k-1)*8 + 2) = Vel_Start(2);

            Dx((k-1)*8 + 4) = Acc_Start(0);
            Dy((k-1)*8 + 4) = Acc_Start(1);
            Dz((k-1)*8 + 4) = Acc_Start(2);

            Dx((k-1)*8 + 6) = Omi_Start(0);
            Dy((k-1)*8 + 6) = Omi_Start(1);
            Dz((k-1)*8 + 6) = Omi_Start(2);
        }

        if( k == m ){
            Dx((k-1)*8 + 3) = Vel_End(0);
            Dy((k-1)*8 + 3) = Vel_End(1);
            Dz((k-1)*8 + 3) = Vel_End(2);

            Dx((k-1)*8 + 5) = Acc_End(0);
            Dy((k-1)*8 + 5) = Acc_End(1);
            Dz((k-1)*8 + 5) = Acc_End(2);

            Dx((k-1)*8 + 7) = Omi_End(0);
            Dy((k-1)*8 + 7) = Omi_End(1);
            Dz((k-1)*8 + 7) = Omi_End(2);
        }
    }


    /*   Produce the Minimum Snap cost function, the Hessian Matrix   */
    MatrixXd H = MatrixXd::Zero( m * 8, m * 8 );

    double y=0.1;

    for(double k = 0; k < m; k ++){
        for(double i = 4; i < 8; i ++){
            for(double j = 4; j < 8; j ++){
                H( int(k*8 + i), int(k*8 + j )) = y * i * (i - 1) * (i - 2)* (i - 3) * j * (j - 1) * (j - 2) * (j - 3) / (i + j - 7) * pow( Time((int)k), (i + j - 7) );
            }
        }
    }

    for(double k = 0; k < m; k ++){
        for(double i = 1; i < 8; i ++){
            for(double j = 1; j < 8; j ++){
                H( (int)(k*8 + i), (int)(k*8 + j )) +=  length_weight * i * j/ (i + j - 1) * pow( Time((int)k), (i + j - 1) );
            }
        }
    }

    _Q = H; // Only minumum snap term is considered here inf the Hessian matrix

    /*   Produce Selection Matrix C'   */
    MatrixXd Ct; // The transpose of selection matrix C
    MatrixXd C;  // The selection matrix C

    MatrixXd At=A.transpose();
    MatrixXd Ati=At.inverse();
    MatrixXd Ai=Ati.transpose();

    if(type == 1){

        /*
         * 当 m=2 时 , C :

            1 0 0 0 0 0 0 0 0 0 0 0     p1     p1  // 起点位置
            0 0 1 0 0 0 0 0 0 0 0 0     p2     v1  // 起点速度
            0 0 0 0 1 0 0 0 0 0 0 0     v1     a1  // 起点加速度
            0 1 0 0 0 0 0 0 0 0 0 0     v2     p2  // 中间点位置
            0 0 0 0 0 0 1 0 0 0 0 0     a1     p2  // 中间点位置
            0 0 0 0 0 0 0 1 0 0 0 0  *  a2  =  p3  // 终点位置
            0 0 0 0 0 0 0 0 0 1 0 0     p2     v3  // 终点速度
            0 0 0 0 0 0 0 0 0 0 0 1     p3     a3  // 终点加速度
            0 0 0 1 0 0 0 0 1 0 0 0     v2     2*v2  // unknown
            0 0 0 0 0 1 0 0 0 0 1 0     v3     2*a2  // unknown
                                        a2
                                        a3
         */

        // generating minumum snap curve
        num_f = 2 * m + 6; //确定量：起点和终点的位置、速度、加速度，以及中间曲线段的起点、终点  4 + 4 + (m - 1) * 2 = 2m + 4
        num_p = 3 * m - 3; //不确定量：中间节点的速度和加速度  (m - 1) * 3 = 3m - 3
        num_d = 8 * m;
        Ct = MatrixXd::Zero(num_d, num_f + num_p);

        Ct( 0, 0 ) = 1;
        Ct( 2, 1 ) = 1;
        Ct( 4, 2 ) = 1; // 第一段曲线的起点状态
        Ct( 6, 3 ) = 1; // 第一段曲线的起点状态
        Ct( 1, 4 ) = 1; // 第一段曲线的终点状态(位置)

        Ct( 3, 2 * m + 6 ) = 1;
        Ct( 5, 2 * m + 7 ) = 1;
        Ct( 7, 2 * m + 8 ) = 1;

        Ct(8 * (m - 1) + 0, 2 * m + 1) = 1; // Stack the end point
        Ct(8 * (m - 1) + 1, 2 * m + 2) = 1; // Stack the end point

        Ct(8 * (m - 1) + 2, 5 * m + 0) = 1;
        Ct(8 * (m - 1) + 3, 2 * m + 3) = 1; // Stack the end point
        Ct(8 * (m - 1) + 4, 5 * m + 1) = 1;
        Ct(8 * (m - 1) + 5, 2 * m + 4) = 1; // Stack the end point
        Ct(8 * (m - 1) + 6, 5 * m + 2) = 1; // Stack the end point
        Ct(8 * (m - 1) + 7, 2 * m + 5) = 1; // Stack the end point

        // 添加中间段路径点位置，以及未知项后缀
        for(int j = 2; j < m; j ++ ){
            Ct( 8 * (j - 1) + 0, 2*j + 1 ) = 1;
            Ct( 8 * (j - 1) + 1, 2*j + 2 ) = 1;

            Ct( 8 * (j - 1) + 2, 2 * m + 5 + 3 * (j - 2) + 1 ) = 1;
            Ct( 8 * (j - 1) + 3, 2 * m + 5 + 3 * (j - 1) + 1 ) = 1;
            Ct( 8 * (j - 1) + 4, 2 * m + 5 + 3 * (j - 2) + 2 ) = 1;
            Ct( 8 * (j - 1) + 5, 2 * m + 5 + 3 * (j - 1) + 2 ) = 1;
            Ct( 8 * (j - 1) + 6, 2 * m + 5 + 3 * (j - 2) + 3 ) = 1;
            Ct( 8 * (j - 1) + 7, 2 * m + 5 + 3 * (j - 1) + 3 ) = 1;
        }

        C = Ct.transpose();

        Eigen::VectorXd Dx1 = C * Dx;
        Eigen::VectorXd Dy1 = C * Dy;
        Eigen::VectorXd Dz1 = C * Dz;

//        cout<<"Dx : -------------"<<endl<<Dx<<endl;
//        cout<<"Dx1 : -------------"<<endl<<Dx1<<endl<<"*****************"<<endl;
//        cout<<C<<endl;

//        cout<<endl<<Dx1<<endl;

        MatrixXd Q; // The Hessian of the total cost function
        Q = H;      // Now only minumum snap is used in the cost
        MatrixXd R   = C * Ati * Q * Ai * Ct;
        VectorXd Dxf(num_f), Dyf(num_f), Dzf(num_f);

        Dxf = Dx1.segment( 0, num_f );
        Dyf = Dy1.segment( 0, num_f );
        Dzf = Dz1.segment( 0, num_f );

        MatrixXd Rff(num_f, num_f);
        MatrixXd Rfp(num_f, num_p);
        MatrixXd Rpf(num_p, num_f);
        MatrixXd Rpp(num_p, num_p);

        Rff = R.block(0, 0, num_f, num_f);
        Rfp = R.block(0, num_f, num_f, num_p);
        Rpf = R.block(num_f, 0,num_p, num_f);
        Rpp = R.block(num_f, num_f, num_p, num_p);

        VectorXd Dxp(num_p), Dyp(num_p), Dzp(num_p);

        MatrixXd Rppi=Rpp.inverse();
        MatrixXd Rfpt=Rfp.transpose();

//        cout<<Rpp<<endl;

        MatrixXd RR= - (Rppi * Rfpt);

        Dxp = RR * Dxf;
        Dyp = RR * Dyf;
        Dzp = RR * Dzf;

        Dx1.segment(num_f, num_p) = Dxp;
        Dy1.segment(num_f, num_p) = Dyp;
        Dz1.segment(num_f, num_p) = Dzp;

//        cout<<"-----------------"<<endl<<Dx1<<endl<<"****************"<<endl;

//        cout<<A<<endl;

//        timeval start_time,end_time;
//        gettimeofday(&start_time,NULL);

        MatrixXd AiCt=(Ai * Ct);

        Px = AiCt * Dx1;
        Py = AiCt * Dy1;
        Pz = AiCt * Dz1;

//        gettimeofday(&end_time,NULL);
//        double fTimeuse = (end_time.tv_sec - start_time.tv_sec) + 0.000001*(end_time.tv_usec - start_time.tv_usec);
//        cout<<"Part time : "<<fTimeuse<<endl;

    }

    for(int i = 0; i < m; i ++){
        PolyCoeff.block(i, 0,  1, 8) = Px.segment( i * 8, 8 ).transpose();
        PolyCoeff.block(i, 8,  1, 8) = Py.segment( i * 8, 8 ).transpose();
        PolyCoeff.block(i, 16, 1, 8) = Pz.segment( i * 8, 8 ).transpose();
    }



    return PolyCoeff;
}

void getPositionFromCoeff(Eigen::Vector3d &pos, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = coeff(s, 0) + coeff(s, 1) * t + coeff(s, 2) * pow(t, 2) + coeff(s, 3) * pow(t, 3) +
              coeff(s, 4) * pow(t, 4) + coeff(s, 5) * pow(t, 5);
    float y = coeff(s, 6) + coeff(s, 7) * t + coeff(s, 8) * pow(t, 2) + coeff(s, 9) * pow(t, 3) +
              coeff(s, 10) * pow(t, 4) + coeff(s, 11) * pow(t, 5);
    float z = coeff(s, 12) + coeff(s, 13) * t + coeff(s, 14) * pow(t, 2) + coeff(s, 15) * pow(t, 3) +
              coeff(s, 16) * pow(t, 4) + coeff(s, 17) * pow(t, 5);

    pos(0) = x;
    pos(1) = y;
    pos(2) = z;
}

void get_1_DerivativeFromCoeff(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = coeff(s, 1) + 2*coeff(s, 2) * pow(t, 1) + 3*coeff(s, 3) * pow(t, 2) +
              4*coeff(s, 4) * pow(t, 3) + 5*coeff(s, 5) * pow(t, 4);
    float y = coeff(s, 7) + 2*coeff(s, 8) * pow(t, 1) + 3*coeff(s, 9) * pow(t, 2) +
              4*coeff(s, 10) * pow(t, 3) + 5*coeff(s, 11) * pow(t, 4);
    float z = coeff(s, 13) + 2*coeff(s, 14) * pow(t, 1) + 3*coeff(s, 15) * pow(t, 2) +
              4*coeff(s, 16) * pow(t, 3) + 5*coeff(s, 17) * pow(t, 4);

    der(0) = x;
    der(1) = y;
    der(2) = z;
}

void get_2_DerivativeFromCoeff(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = 2*coeff(s, 2)+ 2*3*coeff(s, 3) * pow(t, 1) +
              3*4*coeff(s, 4) * pow(t, 2) + 4*5*coeff(s, 5) * pow(t, 3);
    float y = 2*coeff(s, 8)+ 2*3*coeff(s, 9) * pow(t, 1) +
              3*4*coeff(s, 10) * pow(t, 2) + 4*5*coeff(s, 11) * pow(t, 3);
    float z = 2*coeff(s, 14)+ 2*3*coeff(s, 15) * pow(t, 1) +
              3*4*coeff(s, 16) * pow(t, 2) + 4*5*coeff(s, 17) * pow(t, 3);

    der(0) = x;
    der(1) = y;
    der(2) = z;
}

void get_3_DerivativeFromCoeff(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = 2*3*coeff(s, 3)+ 2*3*4*coeff(s, 4) * pow(t, 1) + 3*4*5*coeff(s, 5) * pow(t, 2);
    float y = 2*3*coeff(s, 9)+ 2*3*4*coeff(s, 10) * pow(t, 1) + 3*4*5*coeff(s, 11) * pow(t, 2);
    float z = 2*3*coeff(s, 15)+ 2*3*4*coeff(s, 16) * pow(t, 1) + 3*4*5*coeff(s, 17) * pow(t, 2);

    der(0) = x;
    der(1) = y;
    der(2) = z;
}

void get_4_DerivativeFromCoeff(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = 2*3*4*coeff(s, 4)+ 2*3*4*5*coeff(s, 5) * t;
    float y = 2*3*4*coeff(s, 10)+ 2*3*4*5*coeff(s, 11) * t;
    float z = 2*3*4*coeff(s, 16)+ 2*3*4*5*coeff(s, 17) * t;

    der(0) = x;
    der(1) = y;
    der(2) = z;
}


void getPositionFromCoeff1(Eigen::Vector3d &pos, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = coeff(s, 0) + coeff(s, 1) * t + coeff(s, 2) * pow(t, 2) + coeff(s, 3) * pow(t, 3) +
              coeff(s, 4) * pow(t, 4) + coeff(s, 5) * pow(t, 5)+ coeff(s, 6) * pow(t, 6)+ coeff(s, 7) * pow(t, 7);
    float y = coeff(s, 8) + coeff(s, 9) * t + coeff(s, 10) * pow(t, 2) + coeff(s, 11) * pow(t, 3) +
              coeff(s, 12) * pow(t, 4) + coeff(s, 13) * pow(t, 5)+ coeff(s, 14) * pow(t, 6)+ coeff(s, 15) * pow(t, 7);
    float z = coeff(s, 16) + coeff(s, 17) * t + coeff(s, 18) * pow(t, 2) + coeff(s, 19) * pow(t, 3) +
              coeff(s, 20) * pow(t, 4) + coeff(s, 21) * pow(t, 5)+ coeff(s, 22) * pow(t, 6)+ coeff(s, 23) * pow(t, 7);

    pos(0) = x;
    pos(1) = y;
    pos(2) = z;
}
void get_1_DerivativeFromCoeff1(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = coeff(s, 1)+ coeff(s, 2) * pow(t, 1)*2 + coeff(s, 3) * pow(t, 2)*3 +
              coeff(s, 4) * pow(t, 3)*4 + coeff(s, 5) * pow(t, 4)*5+ coeff(s, 6) * pow(t, 5)*6+ coeff(s, 7) * pow(t, 6)*7;
    float y = coeff(s, 9) + coeff(s, 10) * pow(t, 1)*2 + coeff(s, 11) * pow(t, 2)*3 +
              coeff(s, 12) * pow(t, 3)*4 + coeff(s, 13) * pow(t, 4)*5+ coeff(s, 14) * pow(t, 5)*6+ coeff(s, 15) * pow(t, 6)*7;
    float z = coeff(s, 17)+ coeff(s, 18) * pow(t, 1)*2 + coeff(s, 19) * pow(t, 2)*3 +
              coeff(s, 20) * pow(t, 3)*4 + coeff(s, 21) * pow(t, 4)*5+ coeff(s, 22) * pow(t, 5)*6+ coeff(s, 23) * pow(t, 6)*7;

    der(0) = x;
    der(1) = y;
    der(2) = z;
}
void get_2_DerivativeFromCoeff1(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = coeff(s, 2) * 2 + coeff(s, 3) * pow(t, 1)*2*3 +
              coeff(s, 4) * pow(t, 2)*3*4 + coeff(s, 5) * pow(t, 3)*4*5+ coeff(s, 6) * pow(t, 4)*5*6+ coeff(s, 7) * pow(t, 5)*6*7;
    float y = coeff(s, 10) *2 + coeff(s, 11) * pow(t, 1)*2*3 +
              coeff(s, 12) * pow(t, 2)*3*4 + coeff(s, 13) * pow(t, 3)*4*5+ coeff(s, 14) * pow(t, 4)*5*6+ coeff(s, 15) * pow(t, 5)*6*7;
    float z = coeff(s, 18) *2 + coeff(s, 19) * pow(t, 1)*2*3 +
              coeff(s, 20) * pow(t, 2)*3*4 + coeff(s, 21) * pow(t, 3)*4*5+ coeff(s, 22) * pow(t, 4)*5*6+ coeff(s, 23) * pow(t, 5)*6*7;

    der(0) = x;
    der(1) = y;
    der(2) = z;
}
void get_3_DerivativeFromCoeff1(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = coeff(s, 3) *2*3 +
              coeff(s, 4) * pow(t, 1)*2*3*4 + coeff(s, 5) * pow(t, 2)*3*4*5+ coeff(s, 6) * pow(t, 3)*4*5*6+ coeff(s, 7) * pow(t, 4)*5*6*7;
    float y = coeff(s, 11) *2*3 +
              coeff(s, 12) * pow(t, 1)*2*3*4 + coeff(s, 13) * pow(t, 2)*3*4*5+ coeff(s, 14) * pow(t, 3)*4*5*6+ coeff(s, 15) * pow(t, 4)*5*6*7;
    float z = coeff(s, 19) *2*3 +
              coeff(s, 20) * pow(t, 1)*2*3*4 + coeff(s, 21) * pow(t, 2)*3*4*5+ coeff(s, 22) * pow(t, 3)*4*5*6+ coeff(s, 23) * pow(t, 4)*5*6*7;

    der(0) = x;
    der(1) = y;
    der(2) = z;
}

void get_4_DerivativeFromCoeff1(Eigen::Vector3d &der, Eigen::MatrixXd coeff, int index, double time)
{
    int s = index;
    double t = time;
    float x = coeff(s, 4) *2*3*4 + coeff(s, 5) * pow(t, 1)*2*3*4*5+ coeff(s, 6) * pow(t, 2)*3*4*5*6+ coeff(s, 7) * pow(t, 3)*4*5*6*7;
    float y = coeff(s, 12)*2*3*4 + coeff(s, 13) * pow(t, 1)*2*3*4*5+ coeff(s, 14) * pow(t, 2)*3*4*5*6+ coeff(s, 15) * pow(t, 3)*4*5*6*7;
    float z = coeff(s, 20)*2*3*4 + coeff(s, 21) * pow(t, 1)*2*3*4*5+ coeff(s, 22) * pow(t, 2)*3*4*5*6+ coeff(s, 23) * pow(t, 3)*4*5*6*7;

    der(0) = x;
    der(1) = y;
    der(2) = z;
}


/*
 * 整合的路径优化模块
 * 输入：
 *  1. 所有路径点
 *  2. 起始点高阶导数约束
 * 输出：
 *  1. 新的路径点序列
 *  2. 新的时间序列
 *  3. 每段路径的曲线参数
 */
void find_trajectory(
        vector<Eigen::Vector3d> way_points,
        /*
         * 起点终点高阶导约束
         */
        Eigen::Vector3d start_vel,
        Eigen::Vector3d start_acc,
        Eigen::Vector3d start_acc_d,
        Eigen::Vector3d end_vel,
        Eigen::Vector3d end_acc,
        Eigen::Vector3d end_acc_d,
        /*
         * 输出
         */
        Eigen::VectorXd &new_Time,
        Eigen::MatrixXd &polynomial_coefficients
)
{
    // 初始化端点约束
    Eigen::Vector3d vel, acc, omi;
    Eigen::Vector3d vel_end, acc_end, omi_end;
    vel.setZero();
    acc.setZero();
    omi.setZero();
    vel_end.setZero();
    acc_end.setZero();
    omi_end.setZero();

    // set initial states
    vel    =start_vel;
    acc    =start_acc;
    omi    =start_acc_d;
    vel_end=end_vel;
    acc_end=end_acc;
    omi_end=end_acc_d;

    /** coefficient of polynomials*/
    Eigen::MatrixXd coeff1;
    Eigen::VectorXd Time1;
    /** coefficient of polynomials*/
    Eigen::MatrixXd coeff;
    Eigen::VectorXd Time;

    Eigen::Vector3d vel2,acc2,omi2;
    vel2.setZero();
    acc2.setZero();
    omi2.setZero();

    int tct=0;
    double d_scale=1;

    int sub1_size=0;

//    double l_weight1=1000000;
//    double l_weight2=1000000;
    double l_weight1=100;
    double l_weight2=10;

    double near_ratio=0.008;

    if(way_points.size()>=2&&way_points.size()<5)
    {
        // piece-1
        {
            vector<Eigen::Vector3d> way_points_sub;
            for(int i=0;i<way_points.size();i++)way_points_sub.push_back(way_points[i]);

            sub1_size=way_points_sub.size();

            Eigen::MatrixXd path;

            int type = 1;
            double mean_v=v_mean;

            // way_point allocation

            // 通过已经计算出的轨迹，计算新的“临近控制点”，重新计算轨迹
            Eigen::Vector3d dest=(way_points[1] - way_points[0]);
            double dlen=dest.norm();
            dest/=max(2.0d,dlen);
            Eigen::Vector3d new_cp;
            new_cp= way_points[0]+ dest;

            // 计算矫正控制点，确保行进路径始终收敛于原始精简路径附近
            Eigen::Vector3d td=(way_points[1]-old_start);
            td=(td/td.norm());
            Eigen::Vector3d td2=(new_cp-old_start);
            double td2pl=td2.dot(td);
            td=td*td2pl;
            Eigen::Vector3d fcp=(near_ratio*td+(1-near_ratio)*(new_cp-old_start))+old_start;

            way_points_sub.clear();
            way_points_sub.push_back(way_points[0]);
            // 如果控制点距离够远，加入控制点
            if(!(way_points.size()>2&&(fcp-way_points[0]).norm()<0.4))
                way_points_sub.push_back(fcp);
            for(int i=1;i<way_points.size();i++)way_points_sub.push_back(way_points[i]);

            // way_point allocation
            path = Eigen::MatrixXd::Zero(way_points_sub.size(), 3);
            for(int i = 0; i < way_points_sub.size(); i++)
                path.row(i) = way_points_sub[i].transpose();
            // time allocation
            Time1 = Eigen::VectorXd::Zero(way_points_sub.size() - 1);
            for(int i = 0; i < (way_points_sub.size() - 1); i++)
            {
                double len=0;
                len = (path.row(i+1) - path.row(i)).norm();

                // 计算时间惩罚量
                Eigen::Vector3d dest=(way_points_sub[i+1] - way_points_sub[i]);
                dest/=len;
                Eigen::Vector3d veln=vel/vel.norm();
                double weight_=1;
                if(dest.dot(veln)<=0)
                {
                    weight_=1/(1+2*pow(2.71828,-1*(dest.dot(veln)+4)));
                }
                else if(dest.dot(veln)>0)
                {
                    double prj=(vel.dot(dest));
                    double prjl=prj/(vel.norm());
                    weight_=1/(1+pow(8,-prjl-1));
                }
//                        if((new_cp-way_points[0]).norm()>0.5)
                {
//                        if(i==0||i==1){
//                            double min_v=max(vel.norm(),mean_v);
//                            Time1(i) = weight_*2*len / (mean_v+min_v);
//                        }
//                        else
//                    Time1(i)=weight_* len / (mean_v);
                    Time1(i)= len / (mean_v);
                }
            }
            coeff1 = PolyQPGeneration1(path,Time1,l_weight1, type, vel, acc, omi, vel_end, acc_end, omi_end);

            // 合并两段曲线和时间片
            new_Time = Eigen::VectorXd::Zero(Time1.rows(),1);
            for(int i=0;i<Time1.rows();i++)
            {
                new_Time(i)=Time1(i);
            }

            int dimx=coeff1.rows();
            int dimy=coeff1.cols();
            polynomial_coefficients = Eigen::MatrixXd::Zero(dimx,dimy);
            for(int i=0;i<coeff1.rows();i++)
            {
                for(int ii=0;ii<coeff1.cols();ii++)
                {
                    polynomial_coefficients(i,ii)=coeff1(i,ii);
                }
            }
        }
    }
    else if(way_points.size()>=5)
    {
        // piece-1
        {
            vector<Eigen::Vector3d> way_points_sub;
            way_points_sub.push_back(way_points[0]);
            way_points_sub.push_back(way_points[1]);
            way_points_sub.push_back(way_points[2]);

            sub1_size=way_points_sub.size();

            Eigen::MatrixXd path;
            // set end point velocity
            double end_v_mean=0.5*v_mean;     // [m/s]
            Eigen::Vector3d end_v=((way_points[way_points_sub.size()]-way_points_sub[way_points_sub.size()-1])
                                   +(way_points[way_points_sub.size()-1]-way_points_sub[way_points_sub.size()-2]))/2.0f;
            Eigen::Vector3d end_v0=end_v;
            end_v(0)/=end_v0.norm();
            end_v(1)/=end_v0.norm();
            end_v(2)/=end_v0.norm();
            end_v(0)*=end_v_mean;
            end_v(1)*=end_v_mean;
            end_v(2)*=end_v_mean;

            vel_end=end_v;
            acc_end(0)=0;
            acc_end(1)=0;
            omi_end(0)=0;
            omi_end(1)=0;

            vel2=vel_end;

            int type = 1;
            double mean_v=v_mean;

            // way_point allocation

            // 通过已经计算出的轨迹，计算新的“临近控制点”，重新计算轨迹
            Eigen::Vector3d dest=(way_points[1] - way_points[0]);
            double dlen=dest.norm();
            dest/=max(2.0d,dlen);
            Eigen::Vector3d new_cp;
            new_cp= way_points[0]+ dest;

            // 计算矫正控制点，确保行进路径始终收敛于原始精简路径附近
            Eigen::Vector3d td=(way_points[1]-old_start);
            td=(td/td.norm());
            Eigen::Vector3d td2=(new_cp-old_start);
            double td2pl=td2.dot(td);
            td=td*td2pl;
            Eigen::Vector3d fcp=(near_ratio*td+(1-near_ratio)*(new_cp-old_start))+old_start;

            way_points_sub.clear();
            way_points_sub.push_back(way_points[0]);
            // 如果控制点距离够远，加入控制点
            if((fcp-way_points[0]).norm()>0.25)
//            way_points_sub.push_back(new_cp);
                way_points_sub.push_back(fcp);
            way_points_sub.push_back(way_points[1]);
            way_points_sub.push_back(way_points[2]);
            sub1_size=3;

            // way_point allocation
            path = Eigen::MatrixXd::Zero(way_points_sub.size(), 3);
            for(int i = 0; i < way_points_sub.size(); i++)
                path.row(i) = way_points_sub[i].transpose();
            // time allocation
            Time1 = Eigen::VectorXd::Zero(way_points_sub.size() - 1);
            for(int i = 0; i < (way_points_sub.size() - 1); i++)
            {
                double len=0;
                len = (path.row(i+1) - path.row(i)).norm();

                // 计算时间惩罚量
                Eigen::Vector3d dest=(way_points_sub[i+1] - way_points_sub[i]);
                dest/=len;
                Eigen::Vector3d veln=vel/vel.norm();
                double weight_=1;
                if(dest.dot(veln)<=0)
                {
                    weight_=1/(1+2*pow(2.71828,-1*(dest.dot(veln)+4)));
                }
                else if(dest.dot(veln)>0)
                {
                    double prj=(vel.dot(dest));
                    double prjl=prj/(vel.norm());
                    weight_=1/(1+pow(8,-prjl-1));
                }
//                        if((new_cp-way_points[0]).norm()>0.5)
                {
                    if(i==0||i==1){
                        double min_v=max(vel.norm(),mean_v);
                        Time1(i) = weight_*2*len / (mean_v+min_v);
                    }
                    else
                        Time1(i)=weight_* len / (mean_v);
                }
            }

            coeff1 = PolyQPGeneration1(path,Time1,l_weight1, type, vel, acc, omi, vel_end, acc_end, omi_end);
        }

        // piece-2
        {
            vector<Eigen::Vector3d> way_points_sub;
            for (int i = sub1_size - 1; i < way_points.size(); i++) {
                way_points_sub.push_back(way_points[i]);
            }

            Eigen::MatrixXd path;
            Eigen::Vector3d vel, acc, omi;
            Eigen::Vector3d vel_end, acc_end, omi_end;
            vel.setZero();
            acc.setZero();
            omi.setZero();
            vel_end.setZero();
            acc_end.setZero();
            omi_end.setZero();

            // set arbitrary initial states

            int type = 1;
            double sgm_time = 0.1;
            double mean_v = v_mean;


            // way_point allocation
            path = Eigen::MatrixXd::Zero(way_points_sub.size(), 3);
//                    cout<<"path_length : "<<path.rows()<<endl;
            for (int i = 0; i < way_points_sub.size(); ++i)
                path.row(i) = way_points_sub[i].transpose();
            // time allocation
            double traj_full_len = 0;
            for (int i = 0; i < (way_points_sub.size() - 1); ++i) {
                traj_full_len += (path.row(i) - path.row(i + 1)).norm();
            }
            Time = Eigen::VectorXd::Zero(way_points_sub.size() - 1);
            for (int i = 0; i < (way_points_sub.size() - 1); ++i) {
                double len = 0;
                len = (path.row(i) - path.row(i + 1)).norm();

                Time(i) = max(len / mean_v, sgm_time);
            }

            timeval start_time, end_time;
            gettimeofday(&start_time, NULL);

            coeff = PolyQPGeneration1(path, Time, l_weight2, type, vel2, acc2, omi2, vel_end, acc_end, omi_end);

            // 合并两段曲线和时间片
            new_Time = Eigen::VectorXd::Zero(Time1.rows()+Time.rows(),1);
            for(int i=0;i<Time1.rows();i++)
            {
                new_Time(i)=Time1(i);
            }
            for(int i=0;i<Time.rows();i++)
            {
                new_Time(i+Time1.rows())=Time(i);
            }

            int dimx=coeff.rows()+coeff1.rows();
            int dimy=coeff1.cols();
            polynomial_coefficients = Eigen::MatrixXd::Zero(dimx,dimy);
            for(int i=0;i<coeff1.rows();i++)
            {
                for(int ii=0;ii<coeff1.cols();ii++)
                {
                    polynomial_coefficients(i,ii)=coeff1(i,ii);
                }
            }

            for(int i=0;i<coeff.rows();i++)
            {
                for(int ii=0;ii<coeff.cols();ii++)
                {
                    polynomial_coefficients(i+coeff1.rows(),ii)=coeff(i,ii);
                }
            }
        }
    }

}
