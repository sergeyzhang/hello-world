//
// Created by ZZ_AI_Team on 18-6-21.
//

#ifndef ZZ_PATH_PLANNING_CAMERA_H
#define ZZ_PATH_PLANNING_CAMERA_H

#include <Eigen/Core>
#include "../depends/sophus/include/sophus/se3.hpp"
#include "opencv2/opencv.hpp"
#include "Config.h"

namespace PathPlanning {

class Camera {
 public:
    Camera() {
        fx_ = Config::fx_;
        fy_ = Config::fy_;
        cx_ = Config::cx_;
        cy_ = Config::cy_;

        K_ = Config::K_;
    }

    static Camera &instance() {
        static Camera camera;
        return camera;
    }

    // 空间点投影到图像像素坐标系, 得到在图像上的像素坐标
    inline Eigen::Vector2d reproject_3d_point_2_px(const Eigen::Vector3d &point_pos, const Sophus::SE3d &T_cw) {
        Eigen::Vector3d p_c = T_cw * point_pos;
        Eigen::Vector3d px = K_ * p_c;
        return Eigen::Vector2d(px(0) / px(2), px(1) / px(2));
    }

    inline Eigen::Vector2d reproject_3d_point_2_px(const Eigen::Vector3d &point_pos) {
        Eigen::Vector3d px = K_ * point_pos;
        return Eigen::Vector2d(px(0) / px(2), px(1) / px(2));
    }

    // 图像像素坐标反投影得到空间点坐标
    inline Eigen::Vector3d reproject_px_2_3d_point(const int u, const int v, const Sophus::SE3d &T_wc, double z, double map_scale = 1.0) {
        Eigen::Vector3d point;
        point[0] = (u - cx_) * z / fx_;
        point[1] = (v - cy_) * z / fy_;
        point[2] = z;
        point *= map_scale;

        return T_wc * point;
    }

    // 输入视差, 求解得到物理空间真实深度
    inline float get_depth_from_disparity(const float d) {
        return 3.5 * Config::baseline_f_ / d;
    }

    // 输入像素宽度信息, 求解得到物理空间真实距离信息
    inline float get_distance_from_px(const float px, const float z) {
        return z * px / fx_;
    }

    // 输入物理空间真实距离信息, 转化求解得到图像上的像素宽度信息
    inline float get_px_from_distance(const float distance, const float z) {
        return distance * fx_ / z;
    }

 private:
    float fx_, fy_, cx_, cy_;  // camera intrinsic parameters
    Eigen::Matrix3d K_;
};

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_CAMERA_H
