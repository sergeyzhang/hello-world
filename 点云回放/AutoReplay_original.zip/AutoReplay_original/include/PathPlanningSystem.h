//
// Created by ZZ_AI_Team on 18-5-14.
//

#ifndef ZZ_PATH_PLANNING_PATHPLANNINGSYSTEM_H
#define ZZ_PATH_PLANNING_PATHPLANNINGSYSTEM_H

#include "opencv2/opencv.hpp"
#include "Eigen/Core"

#include "GlobalPlanner.h"

namespace PathPlanning {

class VoxelMap;
class PathFinder;
class CollisionDetector;
class FastPathFinder;

struct collision_info_t {
    int collision_status;
    float mean_depth;
    Eigen::Vector3d fast_core_point;

    float caution_distance;
    float dangerous_distance;
    float emergency_distance;
    Eigen::Vector3d mov_dir;

    float collision_point_depth;
    float collision_distance;
    float collision_width;
    float collision_height;

    Eigen::Vector3d collision_3d_point;
};

class PathPlanningSystem {
 public:
    PathPlanningSystem();
    PathPlanningSystem(const std::string cam_config_file);
    ~PathPlanningSystem();

    void renew_disparity_and_angle(cv::Mat &disparity, const double angle, const double t);
    void renew_pose(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t);
    void collision_detection();  // TODO: finish the collision detector !
    void update_voxel_map();

    void add_angle(const Eigen::Vector2d &angle);
    void add_disparity_map(const cv::Mat &disparity, const double t);
    void set_velocity(const Eigen::Vector3d &v_w);
    bool add_pose(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t);

    void add_disparity_map_for_fast(const cv::Mat &disparity, const double t);
    Eigen::Vector3d add_pose_for_fast(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t);

    int RethinkPath(const Eigen::Vector3d &start_point,
                    const Eigen::Vector3d &target_point,
                    std::vector<Eigen::Vector3d> &path);

    void reset_system();

    /** 0->safe 1->caution 2->dangerous 3->emergency **/
    int get_collision_detector_result();
    void get_collision_info(collision_info_t &collision_info);

    bool has_obstacle_at_pos(const Eigen::Vector3d &position);

    void get_fast_path_finder_resultes(int &collision_status, float &collision_depth);

    inline VoxelMap *get_voxel_map() {
        return voxel_map_;
    }

    inline CollisionDetector *get_collision_detector() {
        return collision_detector_;
    }

    inline PathFinder *get_path_finder() {
        return path_finder_;
    }

 public:
    VoxelMap          *voxel_map_;
    CollisionDetector *collision_detector_;
    PathFinder        *path_finder_;

    FastPathFinder    *fast_path_finder;

    GlobalPlanner *Scout;
};

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_PATHPLANNINGSYSTEM_H
