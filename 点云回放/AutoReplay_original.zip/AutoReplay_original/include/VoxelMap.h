//
// Created by ZZ_AI_Team on 18-4-28.
//

#ifndef ZZ_PATH_PLANNING_VOXELMAP_H
#define ZZ_PATH_PLANNING_VOXELMAP_H

#include "opencv2/opencv.hpp"
#include "ChunkVoxel.h"
#include <mutex>
#include <queue>
#include "../depends/sophus/include/sophus/sophus.hpp"
#include "Global.h"
#include "RingBuffer.h"

namespace PathPlanning {

enum MapType {
    GLOBAL_MAP = 0,
    LOCAL_MAP  = 1,
    SINGLE_MAP = 2
};

class VoxelMap {
 public:
    VoxelMap(std::string setting_file);
    ~VoxelMap();

    void renew_disparity_and_angle(cv::Mat &disparity, const double angle, const double t);
    void renew_pose(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t);
    void collision_detection();  // TODO: finish the collision detector !
    void update_voxel_map();


    void add_angle_T(const Eigen::Vector2d &angle);
    void add_disparity_T(const cv::Mat &disparity, const double t);
    bool add_pose_T(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t);

    bool process_depth_data(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t,
                            const cv::Mat &disparity, const double angle);

    void set_map_type(MapType t);

    void reset();
    void reset_voxel_level();

    std::vector<Chunk_ptr> get_chunk_vector();
    std::vector<Voxel_ptr> get_voxel_vector();

    inline std::map<int, Chunk_ptr> get_chunk_map() {
        return chunk_map_;
    };
    inline cv::Mat get_disparity() {
        return disparity_map_;
    }
    inline Sophus::SE3d get_T_cw() {
        return T_cw_;
    }
    inline Sophus::SE3d get_T_wc() {
        return T_wc_;
    }
    inline RtTime get_curr_T_t() {
        return curr_T_t_;
    }

    bool has_obstacle(const Eigen::Vector3d &start, const Eigen::Vector3d &end);
    bool has_obstacle(const Eigen::Vector3d &pos, Eigen::Vector3i &voxel_grid_num);
    bool has_obstacle(const Eigen::Vector3d &pos);

    static long unsigned int chunk_next_id_;

public:

    PDMatcher PDM;
    int P_index = 0;
    int I_index = 0;

    /*
     * 同步之后的 pose-disparity-angle 数据
     */
    DISP_A Synchronized_disparity_angle;
    POSE Synchronized_POSE;
    bool SynchronizationLock = false;   // 同步数据互斥锁
    bool PDM_Lock = false;  // 匹配互斥锁


    std::map<int, Chunk_ptr> chunk_map_;

    std::vector<RtTime> Rt_time_vec_;
    std::vector<DisparityTime> depth_data_vec_;
    Eigen::Vector2d curr_angle;

    MapType map_type_;

    Eigen::Vector3i chunk_grid_num_;
    Eigen::Vector3i voxel_grid_num_;
    Eigen::Vector3i voxel_index_num_;
    int voxel_index_in_chunk_;
    int chunk_id_;

    cv::Mat disparity_map_;

    cv::Mat Q;   // 双目参数

    Sophus::SE3d T_cw_;
    Sophus::SE3d T_wc_;
    RtTime curr_T_t_;

    Eigen::Vector3d test_target_point;

    std::vector<Eigen::Vector3d> view_voxels;
    std::vector<Eigen::Vector3d> view_point_cloud;

public:
    bool calc_world_pos(const float disparity_value,
                        const int u, const int v,
                        Eigen::Vector3d &point_3d);

    void update_voxel_map(const Eigen::Vector3d &pos, int level = 0);
    void update_voxel_in_chunk(Chunk_ptr chunk, const Eigen::Vector3d &voxel_pos, int level = 0);

    void remove_redundant_chunk_voxel();

    void erase_voxel_at(const Eigen::Vector3d &pos);
};

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_VOXELMAP_H
