//
// Created by ZZ_AI_Team on 18-5-4.
//

#ifndef ZZ_PATH_PLANNING_UTILIES_H
#define ZZ_PATH_PLANNING_UTILIES_H

#include <fstream>
#include "opencv2/opencv.hpp"
#include <Eigen/Core>
#include <Eigen/Eigen>

#include "../depends/sophus/include/sophus/se3.hpp"
#include "Camera.h"
#include "Config.h"
#include "ChunkVoxel.h"

namespace PathPlanning {

#define random(a, b) (rand() % (b - a + 1) + a)

enum CollisionStatus {
    COLLISION_SAFE               = 0,
    COLLISION_CAUTION            = 1,
    COLLISION_DANGEROUS          = 2,
    COLLISION_EMERGENCY          = 3,
    COLLISION_POOR_DISPARITY     = 4,
    COLLISION_POOR_DIS_EMERGENCY = 5
};

enum PathFinderState {
    PATH_FOUND                        = 0,
    PATH_TARGET_IN_OBSTACLE           = 1,
    PATH_NO_COLLISION_POINTS          = 2,
    PATH_COLLISION_INVALID            = 3,
    PATH_GRID_TOO_SHORT               = 4,
    PATH_CORE_POINT_OUT_OF_BOUND      = 5,
    PATH_CORE_POINT_DEPTH_UNNORMAL    = 6,
    PATH_CORE_POINT_NOT_SAFE_AROUND   = 7,
    PATH_HAS_COLLISION_TO_CORE_POINT  = 8,
    PATH_BIG_AREA_OBSTACLE            = 9
};

enum PathDirection {
    GO_LEFT   = 0,
    GO_RIGHT  = 1,
    GO_UP     = 2,
    GO_DOWN   = 3
};

struct RtTime {
    Sophus::SE3d T_wc;
    double t;
};

struct DisparityTime {
    cv::Mat disparity;
    double t;
};

typedef struct ImageList {
    double timeStamp=0;
    std::string imgName;
    double angle=0;
} ImgCell;

typedef struct GtList {
    double timeStamp;
    Eigen::Matrix4d pose;
} GtCell;

struct POSE {
    double timeStamp=0;
    Eigen::Matrix3d r;
    Eigen::Vector3d t;
    Eigen::Vector2d angle;
    double score = 0;
};
struct STEREO_A{
    double timeStamp=0;
    double angle=0;
    cv::Mat left_img;
    cv::Mat right_img;
    bool mark=false;
};

struct DISP_A{
    double timeStamp=0;
    double angle=0;
    cv::Mat disparity;
    bool mark=false;
};

static void load_rt_list(const char *rtPath, std::vector<POSE> &iListData) {
    std::ifstream inf;
    inf.open(rtPath, std::ifstream::in);

    std::string line;

    long long unsigned int t;

    while (std::getline(inf,line) && !line.empty()) {
        cv::Mat rt = cv::Mat(3, 4, CV_32F);;
        POSE rtCell;
        std::sscanf(line.c_str(), "%llu,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f",
                    &t,
                    &rt.at<float>(0, 0), &rt.at<float>(0, 1), &rt.at<float>(0, 2), &rt.at<float>(0, 3),
                    &rt.at<float>(1, 0), &rt.at<float>(1, 1), &rt.at<float>(1, 2), &rt.at<float>(1, 3),
                    &rt.at<float>(2, 0), &rt.at<float>(2, 1), &rt.at<float>(2, 2), &rt.at<float>(2, 3));

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                rtCell.r(i, j) = rt.at<float>(i, j);
            }
            rtCell.t(i) = rt.at<float>(i, 3);
        }
        rtCell.timeStamp = (double)t / 1e9;
        iListData.push_back(rtCell);
    }
    inf.close();
}

static void load_image_list(const char *imagePath, std::vector<ImgCell> &iListData) {
    std::ifstream inf;
    inf.open(imagePath, std::ifstream::in);

    std::string line;
    std::string timestamp;

    //std::getline(inf,line);//Skip the first title line
    while (std::getline(inf,line) && !line.empty()) {
        std::istringstream iss(line);
        std::getline(iss, timestamp, ',');
        ImgCell temp;
        temp.timeStamp = 1e-9 * std::stod(timestamp);
        iss >> temp.imgName;
        iListData.push_back(temp);
    }
    iListData.pop_back();
    inf.close();
}

static void load_GT_poses(const std::string gt_file, std::vector<GtCell> &gt_poses) {
    std::ifstream ifs(gt_file);

    std::string line;
    Eigen::Quaterniond q;
    while (std::getline(ifs, line)) {
        GtCell gtCell;
        double t;
        std::sscanf(line.c_str(), "%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf", &t,
                    &gtCell.pose(0, 3), &gtCell.pose(1, 3), &gtCell.pose(0, 3),
                    &q.w(), &q.x(), &q.y(), &q.z());

        gtCell.timeStamp = t / 1e9;
        Eigen::Matrix3d pose_33 = q.toRotationMatrix();
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                gtCell.pose(i, j) = pose_33(i, j);
            }
        }
        gtCell.pose(3, 0) = 0; gtCell.pose(3, 1) = 0; gtCell.pose(3, 2) = 0; gtCell.pose(3, 3) = 1;

        gt_poses.push_back(gtCell);
    }
}

static std::vector<Eigen::Vector3i> create_random_3d_map(int p_num = 20) {
    std::vector<Eigen::Vector3d> map;

    std::vector<Eigen::Vector3d> pillar;
    for (double i = -0.1; i < 0.1; i += 0.1) {
        for (double j = -0.1; j < 0.1; j += 0.1) {
            for (double k = 0; k < 5; k += 0.15) {
                pillar.push_back(Eigen::Vector3d(i, j, k));
            }
        }
    }

    std::vector<Eigen::Vector3d> plane;
    for (double i = -5; i < 5; i += 0.15) {
        for (double j = -5; j < 5; j += 0.15) {
            plane.push_back(Eigen::Vector3d(i, j, 0));
        }
    }

    for (int l = 0; l < plane.size(); ++l) {
        map.push_back(plane[l]);
    }

    srand((unsigned)time(NULL));
    std::vector<Eigen::Vector3d> random_mov;
    for (int m = 0; m < p_num; ++m) {
        random_mov.push_back(Eigen::Vector3d(random(-2, 1), random(-3, 3), 0));
    }

    for (int n = 0; n < p_num; ++n) {
        for (int i = 0; i < pillar.size(); ++i) {
            map.push_back(pillar[i] + random_mov[n]);
        }
    }

    std::vector<Eigen::Vector3i> grid_map;
    for (int k = 0; k < map.size(); ++k) {
        Eigen::Vector3i v;
        grid_world_position(map[k], v);
        grid_map.push_back(v);
    }

    return grid_map;
}

/**                M
 *                *|
 *            a *  |
 *            *    |dist
 *          *      |
 *       A***********************B
 *             c      b
 * */
static double get_point_2_line_dist(const Eigen::Vector3d &line_A, const Eigen::Vector3d &line_B, const Eigen::Vector3d &point) {
    Eigen::Vector3d AM_a = point - line_A;
    Eigen::Vector3d AB_b = line_B - line_A;
    double b_norm = AB_b.norm();

    // |c| = |a| * cos(theta) = |a| * |b| * cos(theta) / |b| = a * b / |b|
    double c_dist = AM_a.dot(AB_b) / b_norm;
    Eigen::Vector3d b_v = AB_b / b_norm;
    Eigen::Vector3d c = c_dist * b_v;

    return (AM_a - c).norm();
}

static Eigen::Vector3d get_point_2_line_v(const Eigen::Vector3d &line_A, const Eigen::Vector3d &line_B, const Eigen::Vector3d &point) {
    Eigen::Vector3d AM_a = point - line_A;
    Eigen::Vector3d AB_b = line_B - line_A;
    double b_norm = AB_b.norm();

    // |c| = |a| * cos(theta) = |a| * |b| * cos(theta) / |b| = a * b / |b|
    double c_dist = AM_a.dot(AB_b) / b_norm;
    Eigen::Vector3d b_v = AB_b / b_norm;
    Eigen::Vector3d c = c_dist * b_v;

    return AM_a - c;
}

static float constrain_f(float val, float min, float max) {
    return (val < min) ? min : ((val > max) ? max : val);
}

static float abs_constrain_f(float val, float max) {
    return constrain_f(val, -max, max);
}

static void quat_to_euler(const float q[4], float euler[3]) {
    euler[0] = atan2f(2.0f * (q[0] * q[1] + q[2] * q[3]), 1.0f - 2.0f * (q[1] * q[1] + q[2] * q[2]));
    euler[1] = asinf(abs_constrain_f(2.0f * (q[0] * q[2] - q[3] * q[1]), 1.0f));
    euler[2] = atan2f(2.0f * (q[0] * q[3] + q[1] * q[2]), 1.0f - 2.0f * (q[2] * q[2] + q[3] * q[3]));
}

static Eigen::Matrix3d euler_to_rotation_matrxi(const float theta_x, const float theta_y, const float theta_z) {
    Eigen::Matrix3d r_x;
    r_x << 1, 0, 0,
            0, cos(theta_x), -sin(theta_x),
            0, sin(theta_x), cos(theta_x);

    Eigen::Matrix3d r_y;
    r_y << cos(theta_y), 0, sin(theta_y),
            0, 1, 0,
            -sin(theta_y), 0, cos(theta_y);

    Eigen::Matrix3d r_z;
    r_z << cos(theta_z), -sin(theta_z), 0,
            sin(theta_z), cos(theta_z), 0,
            0, 0, 1;

    return r_z * r_y * r_x;
}

static Sophus::SE3d get_rotating_camera_pose(const float angle) {
    Eigen::Matrix3d r = euler_to_rotation_matrxi(M_PI / 12, angle, 0);
    float radii = Config::base_line_ / 2;
    Eigen::Vector3d t(radii * sin(angle - M_PI_2) + radii, 0, radii * cos(angle - M_PI_2));

    return Sophus::SE3d(r, t);
}

static float read_disparity(const cv::Mat &disparity, const int u, const int v) {
    if (disparity.type() == CV_8U) {
        return static_cast<float>(disparity.at<uchar>(v, u)) / 8;
    } else {
        return static_cast<float>(disparity.at<short>(v, u)) / 16;
    }
}


static void add_intermediate_waypoints(std::vector<Eigen::Vector3d> &core_points, double intermediate_pose_separation_ = 0.5) {
    for (size_t i = 1; i < core_points.size(); ++i) {
        Eigen::Vector3d wpa = core_points[i - 1];
        Eigen::Vector3d wpb = core_points[i];
        double dist = (wpa - wpb).norm();

        // Minimum tolerance between points set to avoid subsequent numerical errors
        // in trajectory optimization.
        while (dist > intermediate_pose_separation_ &&
               dist > 0.2) {
            Eigen::Vector3d iwp;
            iwp(0) = wpa(0) + (intermediate_pose_separation_ / dist) * (wpb(0) - wpa(0));
            iwp(1) = wpa(1) + (intermediate_pose_separation_ / dist) * (wpb(1) - wpa(1));
            iwp(2) = wpa(2) + (intermediate_pose_separation_ / dist) * (wpb(2) - wpa(2));
            core_points.insert(core_points.begin() + i, iwp);
            wpa = iwp;
            dist = (wpa - wpb).norm();
            i++;
        }
    }
}

static bool export_to_ply(const std::vector<cv::Point3i> &vec_points_color,
                          const std::vector<cv::Point3d> &vec_points,
                          const std::string &sFileName) {
    std::ofstream outfile;
    outfile.open(sFileName.c_str(), std::ios_base::out);

    outfile << "ply"
            << '\n' << "format ascii 1.0"
            << '\n' << "element vertex " << vec_points.size()
            << '\n' << "property float x"
            << '\n' << "property float y"
            << '\n' << "property float z"
            << '\n' << "property uchar red"
            << '\n' << "property uchar green"
            << '\n' << "property uchar blue"
            << '\n' << "end_header" << std::endl;

    for (size_t i=0; i < vec_points.size(); ++i)  {
        outfile << vec_points[i].x << " "
                << vec_points[i].y << " "
                << vec_points[i].z << " "
                << vec_points_color[i].x << " "
                << vec_points_color[i].y << " "
                << vec_points_color[i].z << "\n";
    }

    outfile.flush();
    bool bOk = outfile.good();
    outfile.close();
    return bOk;
}

static void gray2color(cv::Mat &grayMap, cv::Mat &colorMap, unsigned char maxVal) {
    if (grayMap.type() != CV_8UC1) {
        printf("gray2color only support 8bit gray map. \n");
        return;
    }

    colorMap = cv::Mat(grayMap.rows, grayMap.cols, CV_8UC3);

    float ratio;
    if (maxVal == 0)
        ratio = 1.0f;
    else
        ratio = 255.0f / maxVal;

    int redVal, greenVal, blueVal, grayVal;

    for (int rowIdx = 0; rowIdx < grayMap.rows; rowIdx++) {
        uchar *grayMapPtr = grayMap.ptr<uchar>(rowIdx);
        cv::Vec3b *colorMapPtr = colorMap.ptr<cv::Vec3b>(rowIdx);
        for (int colIdx = 0; colIdx < grayMap.cols; colIdx++) {
            grayVal = grayMapPtr[colIdx];
            grayVal *= ratio;
            grayVal = (grayVal > 255) ? 255 : grayVal;

            redVal = grayVal;
            blueVal = 255 - grayVal;

            if (grayVal == 0) {
                redVal = greenVal = blueVal = 0;
            } else if (grayVal <= 51) {
                blueVal = 255; greenVal = grayVal * 5; redVal = 0;
            } else if (grayVal <= 102) {
                grayVal -= 51;
                blueVal = 255 - grayVal * 5; greenVal = 255; redVal = 0;
            } else if (grayVal <= 153) {
                grayVal -= 102;
                blueVal = 0; greenVal = 255; redVal = grayVal * 5;
            } else if (grayVal <= 204) {
                grayVal -= 153;
                blueVal = 0; greenVal = 255 - uchar(128.0 * grayVal / 51.0 + 0.5); redVal = 255;
            } else {
                grayVal -= 204;
                blueVal = 0; greenVal = 127 - uchar(127.0 * grayVal / 51.0 + 0.5); redVal = 255;
            }

            colorMapPtr[colIdx] = cv::Vec3b(blueVal, greenVal, redVal);
        }
    }
}

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_UTILIES_H
