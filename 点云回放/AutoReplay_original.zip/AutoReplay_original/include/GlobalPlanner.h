//
// Created by electricsoul on 18-12-5.
//
//
//  Hermes ____ 路径规划模块
//
//

#ifndef PROJECT_HERMES_H
#define PROJECT_HERMES_H

#include <iostream>
#include <map>
#include <sys/time.h>

#include "ChunkVoxel.h"
#include "VoxelMap.h"

#include "CollisionDetector.h"

using namespace cv;
using namespace std;

using namespace PathPlanning;

#define snapshot_x  100
#define snapshot_z  20
#define snapshot_y  snapshot_x

//#define debug_planning

struct cost_voxel
{
    cv::Point3i father;
    // 从此位置回溯路径到起始点的距离
    float g_score=0;
    // 从此位置无遮挡的情况下到达目的地的距离
    float h_score=0;
    // 上面两者加起来的距离
    float f_score=0;

    /*
     * 0 --none
     * 1 --open
     * 2 --close
     */
    int open_close=0;

    bool value=0;

    void mark_none()
    {
        open_close=0;
    }
    void mark_open()
    {
        open_close=1;
    }
    void mark_close()
    {
        open_close=2;
    }
};

class GlobalPlanner {

public:

    int search_area_x_chunk = 10;
    int search_area_y_chunk = 10;
    int search_area_z_chunk = 2;

    int inflation_range = 1;

    bool use_inflation = false;

    /*******************************************************/
    /*
     *  A* 操作内存
     */
    // d-score 快速查找表
    float* d_score_table;
    // 路径搜索结构体
    cost_voxel* cost_map_;
    // open-set 使用map进行f_score排序
    std::map<double,cv::Point3i> open_set;
    std::list<cv::Point3i> close_set;
    // 整个离散路径
    std::vector<cv::Point3d> final_path;
    std::vector<cv::Point3d> final_path_d;
    // 所有关键点
    std::vector<cv::Point3d> turning_points;
    // 核心路径点
    std::vector<cv::Point3d> essential_way_points;
    std::vector<cv::Point3d> core_way_points;
    std::vector<bool> turning_points_mark;
    std::vector<bool> essential_points_mark;

    /*
     * 重规划
     */
    bool do_planning = true;
    cv::Point3d end_point_of_last_planning;
    cv::Point3d start_point_of_last_planning;
    cv::Point3d first_wp_of_last_planning;
    double replanning_counter=0;

    double control_time_period=0.1;

    /*
     * 路径规划内存
     */
    bool space_snapshot[snapshot_x][snapshot_y][snapshot_z];
    bool space_snapshot_2[snapshot_x][snapshot_y][snapshot_z];
    int act_size=snapshot_x;
    int act_size_z=snapshot_z;
    int disp_size=900;
    int act_size2=act_size*act_size;

    cv::Point3d snapshot_start_point;

    int obstacle_h=8;
    // 高度损失权值
    double h_w=4;

    // 路径重规划阈值
    double far_point_dist=2;
    double abc_ratio=2;

    bool do_path_search=true;

    Eigen::Vector3i searching_start_voxel;    // 用于在快照空间中搜索路径的起点终点
    Eigen::Vector3i searching_end_voxel;
    cv::Point3i start_;
    cv::Point3i end_;

    bool target_found=false;

    /*******************************************************/

    /*
     * 当前规划路径
     * planning way points
     */
    std::vector<Eigen::Vector3d> essential_way_points_core;
    /*
     * action start | action end
     */
    Eigen::Vector3d action_start;
    Eigen::Vector3d action_end;


public:

    VoxelMap *voxel_map_;
    CollisionDetector *collision_detector_;


public:

    GlobalPlanner();

    void voxel_map_2_3d_gird_map();

    inline double get_d_score_fast(int x,int y,float* d_score_table);
    inline double get_d_score_fast3(int x,int y,int z,float* d_score_table);
    inline int get_h_score(int x,int y,int dx,int dy);
    inline double get_h_score3(int x,int y,int z,int dx,int dy,int dz);
    inline double get_h_score31(int x,int y,int z,int dx,int dy,int dz);
    inline int get_g_score_father(cost_voxel* path_map,int x,int y);
    inline int get_g_score_father3(cost_voxel* path_map,int x,int y,int z);
    inline int get_dist(int x,int y,int fx,int fy);
    inline double get_dist3(int x,int y,int z,int fx,int fy,int fz);
    inline int get_g_score(cost_voxel* path_map,int x,int y);
    inline double get_g_score3(cost_voxel* path_map,int x,int y,int z);




    /*
     * 根据需求的起点和终点，计算关键路径
     */
    std::vector<Eigen::Vector3d> find_path(const Eigen::Vector3d start_point,
                                           const Eigen::Vector3d target_point,
                                           VoxelMap *Map_);

    /*
     * A-Star
     */
    std::vector<Eigen::Vector3d> FindEssentialPath();
    /*
     * re-planning
     */
    bool EvaluatePlanningNecessity(const Eigen::Vector3d start_point,
                                   const Eigen::Vector3d target_point);
    /*
     * progress_control
     */
    bool MaintainProgress(const Eigen::Vector3d start_point,
                          const Eigen::Vector3d target_point);

    int get_path_finder_state() {
        return 0;
    }

};


#endif //PROJECT_HERMES_H
