//
// Created by electricsoul on 19-1-21.
//

#ifndef PROJECT_RINGBUFFER_H
#define PROJECT_RINGBUFFER_H

#include "Global.h"

using namespace PathPlanning;
using namespace std;

class PoseRingBuffer {

public:

    int front = -1;
    int future = 0;
    int size = 0;

    vector<POSE> pose_fifo;

    PoseRingBuffer()
    {
        front = -1;
        future = 0;
        size = 0;
    }

    PoseRingBuffer(int size_)
    {
        pose_fifo.resize(size_);
        size = size_;
        front = -1;
        future = 0;
    }

    void init(int size_)
    {
        pose_fifo.resize(size_);
        size = size_;
        front = -1;
        future = 0;
    }

    void clear()
    {
        pose_fifo.clear();
        front = -1;
        future = 0;
        size = 0;
    }

    bool push_back(POSE pose_t)
    {
        if(pose_fifo.size() == 0)return false;

        pose_fifo[future] = pose_t;

        front++;
        future++;
        if(future >= pose_fifo.size())future = 0;
        if(front >= pose_fifo.size())front = 0;

        return true;
    }

    POSE get_element(int n)
    {
        if(n>=size)
        {
            POSE pt;
            return pt;
        }

        int index_n=0;
        if((future+n)<=(size-1))
        {
            index_n = future+n;
        }
        else
        {
            index_n = future+n-size;
        }

        return pose_fifo[index_n];
    }

    int get_back_index()
    {
        if(front == -1)return 0;
        else return front;
    }
    int get_front_index()
    {
        return future;
    }

    POSE get_back_element()
    {
        if(front == -1){
            POSE pt;
            return pt;
        } else{
            return pose_fifo[front];
        }
    }
    POSE get_front_element()
    {
        return pose_fifo[future];
    }

};


class StereoRingBuffer {

public:

    int front = -1;
    int future = 0;
    int size = 0;

    vector<STEREO_A> sa_fifo;

    StereoRingBuffer()
    {
        front = -1;
        future = 0;
        size = 0;
    }

    StereoRingBuffer(int size_)
    {
        sa_fifo.resize(size_);
        size = size_;
        front = -1;
        future = 0;
    }

    void init(int size_)
    {
        sa_fifo.resize(size_);
        size = size_;
        front = -1;
        future = 0;
    }

    void clear()
    {
        sa_fifo.clear();
        front = -1;
        future = 0;
        size = 0;
    }

    bool push_back_new_element(cv::Mat &leftImg,cv::Mat &rightImg,double _angle,double _timestamp)
    {
        if(sa_fifo.size() == 0)return false;

        /*
         * 拷贝数据
         */
        sa_fifo[future].timeStamp = _timestamp;
        sa_fifo[future].angle = _angle;
        sa_fifo[future].left_img = leftImg.clone();
        sa_fifo[future].right_img = rightImg.clone();

        front++;
        future++;
        if(future >= sa_fifo.size())future = 0;
        if(front >= sa_fifo.size())front = 0;

        return true;
    }

    bool push_back(STEREO_A &sa_t)
    {
        if(sa_fifo.size() == 0)return false;

        /*
         * 拷贝数据
         */
        sa_fifo[future].timeStamp = sa_t.timeStamp;
        sa_fifo[future].angle = sa_t.angle;
        sa_fifo[future].left_img = sa_t.left_img.clone();
        sa_fifo[future].right_img = sa_t.right_img.clone();

        front++;
        future++;
        if(future >= sa_fifo.size())future = 0;
        if(front >= sa_fifo.size())front = 0;

        return true;
    }

    int get_element_index(int n)
    {
        if(n>=size)
        {
            return 0;
        }

        int index_n=0;
        if((future+n)<=(size-1))
        {
            index_n = future+n;
        }
        else
        {
            index_n = future+n-size;
        }
        return index_n;
    }

    int get_back_index()
    {
        if(front == -1)return 0;
        else return front;
    }
    int get_front_index()
    {
        return future;
    }
};

class DispRingBuffer {

public:

    int front = -1;
    int future = 0;
    int size = 0;

    vector<DISP_A> da_fifo;

    DispRingBuffer()
    {
        front = -1;
        future = 0;
        size = 0;
    }

    DispRingBuffer(int size_)
    {
        da_fifo.resize(size_);
        size = size_;
        front = -1;
        future = 0;
    }

    void init(int size_)
    {
        da_fifo.resize(size_);
        size = size_;
        front = -1;
        future = 0;
    }

    void clear()
    {
        da_fifo.clear();
        front = -1;
        future = 0;
        size = 0;
    }

    bool push_back_new_element(cv::Mat &disparity_i,double _angle,double _timestamp)
    {
        if(da_fifo.size() == 0)return false;

        /*
         * 拷贝数据
         */
        da_fifo[future].timeStamp = _timestamp;
        da_fifo[future].angle = _angle;
        da_fifo[future].disparity = disparity_i.clone();

        front++;
        future++;
        if(future >= da_fifo.size())future = 0;
        if(front >= da_fifo.size())front = 0;

        return true;
    }

    bool push_back(DISP_A &sa_t)
    {
        if(da_fifo.size() == 0)return false;

        /*
         * 拷贝数据
         */
        da_fifo[future].timeStamp = sa_t.timeStamp;
        da_fifo[future].angle = sa_t.angle;
        da_fifo[future].disparity = sa_t.disparity.clone();

        front++;
        future++;
        if(future >= da_fifo.size())future = 0;
        if(front >= da_fifo.size())front = 0;

        return true;
    }

    int get_element_index(int n)
    {
        if(n>=size)
        {
            return 0;
        }

        int index_n=0;
        if((future+n)<=(size-1))
        {
            index_n = future+n;
        }
        else
        {
            index_n = future+n-size;
        }
        return index_n;
    }

    int get_back_index()
    {
        if(front == -1)return 0;
        else return front;
    }
    int get_front_index()
    {
        return future;
    }
};

class PSMatcher{

public:
    int RB_length = 60;
    PoseRingBuffer PRB;
    StereoRingBuffer SRB;

    PSMatcher()
    {
        RB_length = 60;
        PRB = PoseRingBuffer(RB_length);
        SRB = StereoRingBuffer(RB_length);
    }

    PSMatcher(int fifo_size)
    {
        RB_length = fifo_size;
        PRB = PoseRingBuffer(RB_length);
        SRB = StereoRingBuffer(RB_length);
    }

    void clear()
    {
        PRB.clear();
        SRB.clear();
    }

    bool feed_pose_data(POSE pose_t)
    {
        PRB.push_back(pose_t);
    }

    bool feed_stereo_data(cv::Mat &leftImg,cv::Mat &rightImg,double _angle,double _timestamp)
    {
        SRB.push_back_new_element(leftImg,rightImg,_angle,_timestamp);
    }

    POSE get_lastest_pose()
    {
        return PRB.get_back_element();
    }

    bool get_matched_data(int &P_index , int &I_index)
    {
        /*
         * 1. 判断延迟分类,决定分配给谁缓存
         * 2. 求j/k
         * 3. 直接输出front元素
         * 4. 对于每一帧图像,匹配一个最佳的R|T然后输出
         */
        int delay_type=0;
        static int k_ = 0;  // pose RB
        static int j_ = 0;  // stereo RB
        int best_k = 0;
        int best_j = -1;
        if(SRB.sa_fifo[SRB.get_back_index()].timeStamp>PRB.get_back_element().timeStamp)
        {
            delay_type = 2;
            double min_t_err = 1000000;
            bool found_best_match = false;
            double pose_t = PRB.get_back_element().timeStamp;
            // 1. 先找到时间戳小于当前pose时间戳的stereo元素
            int init_k = RB_length-1;
            for(;init_k>=0 && SRB.sa_fifo[SRB.get_element_index(init_k)].timeStamp>pose_t;init_k--);
            // 2. 反向查找:第一个与pose时间戳之间具有"最优匹配特征"的stereo元素
            // 停止条件: stereo 和 pose的时间戳差别大于1s | 向后查找pose的长度小于20
            for(int ii=init_k;ii>=0;ii--)
            {
                bool found_minimum_match = false;
                int minimun_match_j = 0;
                double stereo_t = SRB.sa_fifo[SRB.get_element_index(ii)].timeStamp;
                // 反向遍历pose 队列,寻找当前stereo数据是否存在最佳匹配pose
                for(int iii=RB_length-2;iii>=1;iii--)
                {
                    double t_ = abs(stereo_t-PRB.get_element(iii).timeStamp);
                    double t_a = abs(stereo_t-PRB.get_element(iii-1).timeStamp);
                    double t_b = abs(stereo_t-PRB.get_element(iii+1).timeStamp);
                    if(
                            t_<=0.02        // 时间差小于20ms
                            && t_<=t_a && t_<=t_b)
                    {
                        found_minimum_match = true;
                        minimun_match_j = iii;
                        min_t_err = t_;
                        break;
                    }
                }
                // 如果存在最佳匹配 pose
                if(found_minimum_match)
                {
                    if(abs(SRB.sa_fifo[SRB.get_element_index(ii)].timeStamp-SRB.sa_fifo[SRB.get_back_index()].timeStamp)>=4)
                    {
                        // 如果数据距离最新的时间戳太远,放弃
                        found_minimum_match = false;
                        continue;
                    }
                    if(abs(PRB.get_element(minimun_match_j).timeStamp-SRB.sa_fifo[SRB.get_element_index(ii)].timeStamp)>=1
                       || PRB.get_element(minimun_match_j).timeStamp == 0
                       || SRB.sa_fifo[SRB.get_element_index(ii)].timeStamp == 0)
                    {
                        // 如果输出的最佳匹配是错的,放弃
                        found_minimum_match = false;
                        continue;
                    }
                    // 找到首个最佳匹配
                    best_k = ii;
                    best_j = minimun_match_j;
                    found_best_match = true;
                    // 将最佳匹配标记为"已找到"
                    SRB.sa_fifo[SRB.get_element_index(ii)].mark = true;
                    break;
                }
            }

            // 3. 如果该元素没有被标记,则标记然后输出

            if(found_best_match)
            {
                P_index = best_j;
                I_index = best_k;
                return true;
            }
        }
        else
        {
            delay_type = 1;
            bool found_best_match = true;
            // pose先到
            double img_t = SRB.sa_fifo[SRB.get_back_index()].timeStamp;    // 获取最新的stereo时间戳

            // 在 stereo RB 中寻找和最新pose时间戳对齐的数据位置 j_
            for(int ii=0;ii<RB_length;ii++)
            {
                if(img_t <= PRB.get_element(ii).timeStamp)
                {
                    j_ = ii;
                    break;
                }
            }
            // 在 j_ 附近找最佳匹配
            double min_t_err = 1000000;
            for(int ii = max(j_-10,0);ii<min(j_+10,RB_length);ii++)
            {
                if(min_t_err >= abs(img_t-PRB.get_element(ii).timeStamp))
                {
                    min_t_err = abs(img_t-PRB.get_element(ii).timeStamp);
                    best_j = ii;
                }
            }
            if(found_best_match) {
                if (abs(PRB.get_element(best_j).timeStamp -SRB.sa_fifo[SRB.get_back_index()].timeStamp) >= 1
                    || PRB.get_element(best_j).timeStamp == 0
                    || SRB.sa_fifo[SRB.get_back_index()].timeStamp == 0) {
                    // 如果输出的最佳匹配是错的,放弃
                    found_best_match = false;
                    return false;
                }
            }
            if(found_best_match)
            {
                P_index = best_j;
                I_index = RB_length - 1;

                return true;
            }
        }

        return false;
    }

};

class PDMatcher{

public:
    int RB_length = 60;
    PoseRingBuffer PRB;
    DispRingBuffer DRB;

    double last_D_time = 0;

    PDMatcher()
    {
        RB_length = 60;
        PRB = PoseRingBuffer(RB_length);
        DRB = DispRingBuffer(RB_length);
    }

    PDMatcher(int fifo_size)
    {
        RB_length = fifo_size;
        PRB = PoseRingBuffer(RB_length);
        DRB = DispRingBuffer(RB_length);
    }

    void init(int fifo_size)
    {
        RB_length = fifo_size;
        PRB = PoseRingBuffer(RB_length);
        DRB = DispRingBuffer(RB_length);
    }

    void clear()
    {
        PRB.clear();
        DRB.clear();
    }

    bool feed_pose_data(POSE pose_t)
    {
        PRB.push_back(pose_t);
    }

    bool feed_stereo_data(cv::Mat &disparity_i,double _angle,double _timestamp)
    {
        DRB.push_back_new_element(disparity_i,_angle,_timestamp);
    }

    POSE get_lastest_pose()
    {
        return PRB.get_back_element();
    }

    bool get_matched_data(int &P_index , int &I_index)
    {


        /*
         * 1. 判断延迟分类,决定分配给谁缓存
         * 2. 求j/k
         * 3. 直接输出front元素
         * 4. 对于每一帧图像,匹配一个最佳的R|T然后输出
         */
        int delay_type=0;
        static int k_ = 0;  // pose RB
        static int j_ = 0;  // stereo RB
        int best_k = 0;
        int best_j = -1;
        if(DRB.da_fifo[DRB.get_back_index()].timeStamp>PRB.get_back_element().timeStamp)
        {
            delay_type = 2;
            double min_t_err = 1000000;
            bool found_best_match = false;
            double pose_t = PRB.get_back_element().timeStamp;
            // 1. 先找到时间戳小于当前pose时间戳的stereo元素
            int init_k = RB_length-1;
            for(;init_k>=0 && DRB.da_fifo[DRB.get_element_index(init_k)].timeStamp>pose_t;init_k--);
            // 2. 反向查找:第一个与pose时间戳之间具有"最优匹配特征"的stereo元素
            // 停止条件: stereo 和 pose的时间戳差别大于1s | 向后查找pose的长度小于20
            for(int ii=init_k;ii>=0;ii--)
            {
                bool found_minimum_match = false;
                int minimun_match_j = 0;
                double stereo_t = DRB.da_fifo[DRB.get_element_index(ii)].timeStamp;
                // 反向遍历pose 队列,寻找当前stereo数据是否存在最佳匹配pose
                for(int iii=RB_length-2;iii>=1;iii--)
                {
                    double t_ = abs(stereo_t-PRB.get_element(iii).timeStamp);
                    double t_a = abs(stereo_t-PRB.get_element(iii-1).timeStamp);
                    double t_b = abs(stereo_t-PRB.get_element(iii+1).timeStamp);
                    if(
                            t_<=0.015        // 时间差小于20ms
                            && t_<=t_a && t_<=t_b)
                    {
                        found_minimum_match = true;
                        minimun_match_j = iii;
                        min_t_err = t_;
                        break;
                    }
                }
                // 如果存在最佳匹配 pose
                if(found_minimum_match)
                {
                    if(abs(DRB.da_fifo[DRB.get_element_index(ii)].timeStamp-DRB.da_fifo[DRB.get_back_index()].timeStamp)>=4)
                    {
                        // 如果数据距离最新的时间戳太远,放弃
                        found_minimum_match = false;
                        continue;
                    }
                    if(abs(PRB.get_element(minimun_match_j).timeStamp-DRB.da_fifo[DRB.get_element_index(ii)].timeStamp)>=1
                       || PRB.get_element(minimun_match_j).timeStamp == 0
                       || DRB.da_fifo[DRB.get_element_index(ii)].timeStamp == 0)
                    {
                        // 如果输出的最佳匹配是错的,放弃
                        found_minimum_match = false;
                        continue;
                    }
                    // 找到首个最佳匹配
                    best_k = ii;
                    best_j = minimun_match_j;
                    found_best_match = true;
                    // 将最佳匹配标记为"已找到"
                    DRB.da_fifo[DRB.get_element_index(ii)].mark = true;
                    break;
                }
            }

            // 3. 如果该元素没有被标记,则标记然后输出

            if(found_best_match)
            {
                P_index = best_j;
                I_index = best_k;

                // 检查是否有重复输出
//                if(last_D_time != DRB.da_fifo[DRB.get_element_index(I_index)].timeStamp){
//                    last_D_time = DRB.da_fifo[DRB.get_element_index(I_index)].timeStamp;
                    return true;
//                } else{
//
//                    found_best_match = false;
//                    return false;
//                }
            }
        }
        else
        {
            delay_type = 1;
            bool found_best_match = true;
            // pose先到
            double img_t = DRB.da_fifo[DRB.get_back_index()].timeStamp;    // 获取最新的stereo时间戳

            // 在 stereo RB 中寻找和最新pose时间戳对齐的数据位置 j_
            for(int ii=0;ii<RB_length;ii++)
            {
                if(img_t <= PRB.get_element(ii).timeStamp)
                {
                    j_ = ii;
                    break;
                }
            }
            // 在 j_ 附近找最佳匹配
            double min_t_err = 1000000;
            for(int ii = max(j_-10,0);ii<min(j_+10,RB_length);ii++)
            {
                if(min_t_err >= abs(img_t-PRB.get_element(ii).timeStamp))
                {
                    min_t_err = abs(img_t-PRB.get_element(ii).timeStamp);
                    best_j = ii;
                }
            }
            if(found_best_match) {
                if (abs(PRB.get_element(best_j).timeStamp -DRB.da_fifo[DRB.get_back_index()].timeStamp) >= 1
                    || PRB.get_element(best_j).timeStamp == 0
                    || DRB.da_fifo[DRB.get_back_index()].timeStamp == 0) {
                    // 如果输出的最佳匹配是错的,放弃
                    found_best_match = false;
                    return false;
                }
            }
            if(found_best_match)
            {
                P_index = best_j;
                I_index = RB_length - 1;

                // 检查是否有重复输出
//                if(last_D_time != DRB.da_fifo[DRB.get_element_index(I_index)].timeStamp){
//                    last_D_time = DRB.da_fifo[DRB.get_element_index(I_index)].timeStamp;
                    return true;
//                } else{
//
//                    found_best_match = false;
//                    return false;
//                }
            }
        }

        return false;
    }

};



#endif //PROJECT_RINGBUFFER_H




