//
// Created by ZZ_AI_Team on 18-6-4.
//

#ifndef ZZ_PATH_PLANNING_TRAJECTORYGENERATOR_H
#define ZZ_PATH_PLANNING_TRAJECTORYGENERATOR_H

#include <Eigen/Core>

#include <mav_trajectory_generation/trajectory.h>
#include <mav_trajectory_generation/eigen_mav_msgs.h>

namespace PathPlanning {

class Trajectory {
 public:

    static int derivative_to_optimize_;

    static mav_trajectory_generation::Trajectory trajectory_;
    static mav_msgs::EigenTrajectoryPoint::Vector flat_states_;
    static mav_trajectory_generation::Segment::Vector segments_;

    bool static linear_generate_trajectory(const std::vector<Eigen::Vector3d> &positions,
                                           const std::vector<Eigen::Vector3d> &velocities,
                                           const Eigen::Vector3d &start_acceleration = Eigen::Vector3d::Zero(),
                                           double v_max = 2.0,
                                           double a_max = 1.0,
                                           double t_ratio = 1.0,
                                           bool fabian_time = true);

    bool static nonlinear_generate_trajectory(const std::vector<Eigen::Vector3d> &positions,
                                              const std::vector<Eigen::Vector3d> &velocities,
                                              const Eigen::Vector3d &start_acceleration = Eigen::Vector3d::Zero(),
                                              double v_max = 2.0,
                                              double a_max = 1.0,
                                              double t_ratio = 1.0);

    void static set_max_derivatiov_to_optimize(int order) {
        derivative_to_optimize_ = order;
    }

    // get trajectory results
    void static get_trajectory_position(std::vector<Eigen::Vector3d> &trajectory_positions,
                                        std::vector<Eigen::Vector3d> &trajectory_velocities,
                                        std::vector<Eigen::Matrix4d> &trajectory_poses,
                                        const double sampling_t);

    void static sample_trajectory_at_time(const double t,
                                          Eigen::Vector3d &position,
                                          Eigen::Vector3d &velocity,
                                          Eigen::Vector3d &acc);
};

} // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_TRAJECTORYGENERATOR_H
