//
// Created by ZZ_AI_Team on 7/4/18.
//

#ifndef ZZ_PATH_PLANNING_CONFIG_H
#define ZZ_PATH_PLANNING_CONFIG_H

#include <string>
#include <Eigen/Core>

namespace PathPlanning {

class Config {
 public:
    Config(const std::string setting_file);

    static void load_param(const std::string setting_file) {
        Config config(setting_file);
    }

    static int use_fast_path_finder;

    static int is_fc_ned_;            // 是否是北东地坐标系

    static float base_line_;          // Stereo baseline (m)
    static float baseline_f_;         // Stereo baseline multiplied by fx.

    // camera intrinsic parameters
    static float fx_;
    static float fy_;
    static float cx_;
    static float cy_;
    static Eigen::Matrix3d K_;

    static int img_width_;
    static int img_height_;

    // VoxelMap
    static float map_scale_;                 // 地图的尺度
    static int   map_type_;                  // 地图的类型

    static float point_max_distance_;        // 最远的空间点
    static float front_max_distance_;        // 摄像机前方最远chunk距离
    static float back_max_distance_;         // 摄像机后方最远chunk距离

    static float visable_voxel_theta_;       // 摄像机前方与voxel的夹角
    static int voxel_max_life_time_;         // voxel不被更新的最大时间, 否则删除

    // CollisionDetector
    static float init_caution_distance_;     // 碰撞检测预警距离
    static float init_dangerous_distance_;   // 碰撞检测危险距离
    static float init_emergency_distance_;   // 碰撞检测紧急距离

    static float caution_velocity_ratio_;
    static float dangerous_velocity_ratio_;
    static float emergency_velocity_ratio_;

    static int caution_voxel_num_;
    static int dangerous_voxel_num_;
    static int emergency_voxel_num_;

    static float emergency_ratio_threshold_;
    static float caution_ratio_threshold_;
    static float valid_ratio_threshold_;

    static float safe_radii_;                 // 碰撞检测的安全通道半径

    // PathFinder
    static float safe_offset_distance_;       // 与碰撞体的安全偏移距离
};

}  // namespace PathPlanning

#endif  // ZZ_PATH_PLANNING_CONFIG_H
