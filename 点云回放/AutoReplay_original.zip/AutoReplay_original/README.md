log记录

+ 4： 只有前后
+ 5：改善刹车距离的提交
+ 6：同上
+ 160: 前进时误刹
+ 162：同上
+ 170 ：只有刹车时的图片
+ 171: 同上
+ 173： 只有刹车时的图片，数据好
+ 182：打印刹车的near_ponts
+ 184: 去掉光板
+ 187: 光斑+刹车和正常流+缩小检测区域+数据好，误刹
+ 190: 同上，但改变brake_filter_signal = 5，有减速问题
+ 194：光斑+缩小检测区域+刹车正常刘+体素图vox_max_life_time_ =2 （原来是5）
+ 196： 同194， vox_max_life_time_ 改为原来，然后 hallway_length = 1; hallway_raidus = 0.5; brake_length= 1;
+ 198： 恢复到原来圆柱尺寸，改变CD_params.ymli的brake_fitler_threshold = 5和修改autopliot.cpp里的kalman_d 中，hallway_length*2即可；
+ 构建的121版本：只改两处，brake_filter_threshold和hallway_length*2
+ 62：飞不出困境，数据集不好
+ 69：灯光困境，点云正确，体素图有问题，因调整了体素图参数
+ 70：铅笔圆锥撞人；
+ 77：倒圆锥撞人；
+ 82：回复到最初的圆柱，使用最初的参数，使用raw_voxels，不是用膨胀后的；
+ 





飞机里的CD_params: 

+ brake_obj_threshould  = 200;
+ vox_eq_pt: 200;

Repo Autopilot.cpp打印:

```
cout<<"time ： "<<nanomsg_img_timestamp
                <<"|"<<loop_ct
                <<"|"<<pathPlanningSystem->voxel_map_->Synchronized_POSE.t(0)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.t(1)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.t(2)
                <<"|"<<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(0,0)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(0,1)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(0,2)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(1,0)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(1,1)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(1,2)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(2,0)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(2,1)<<","
                <<pathPlanningSystem->voxel_map_->Synchronized_POSE.r(2,2)
                <<"|"<<nanomsg_angle
                <<"|"<<emergency_break
                <<"|"<<near_ptc
                <<"|"<<near_vox
                <<"|"<<Probe_Vector(0)<<","<<Probe_Vector(1)<<","<<Probe_Vector(2)
                <<"|"<<brake_filter_fifo_ct
                <<"|"<<cv_w(0)<<","<<cv_w(1)<<","<<cv_w(2)
                <<"|"<<DroneVelocity(0)<<","<<DroneVelocity(1)<<","<<DroneVelocity(2)
                <<"|"<<nanomsg_pose.score
                <<"|"<<human_pos(0)<<","<<human_pos(1)<<","<<human_pos(2)
                <<"|"<<near_vox*vox_eq_pt
                <<"|"<<near_ptc
                <<endl;
            cout<<"captain_mode : "<<captain_mode<<endl;
            cout<<"gps_position_accuracy : "<<gps_position_accuracy<<endl;
            cout<<"gps_speed_accuracy : "<<gps_speed_accuracy<<endl;
            cout<<"V_max : "<<V_max<<endl;
            cout<<"min_max_v : "<<min_max_v<<endl;
            cout<<"kalman_d : "<<g_kalman_d<<endl;
            cout<<"emergency_brake : "<<emergency_break<<endl;
            loop_ct++;
```

