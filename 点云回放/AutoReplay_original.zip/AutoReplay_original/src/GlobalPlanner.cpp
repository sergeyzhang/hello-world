//
// Created by electricsoul on 18-12-5.
//

#include "../include/GlobalPlanner.h"
#include "../include/Global.h"
#include "../include/Camera.h"
#include "../include/ChunkVoxel.h"

#include "../timer.h"

GlobalPlanner::GlobalPlanner() {
    /*
     *  A* 内存初始化
     */
    d_score_table=new float[act_size2*act_size_z];
    cost_map_=new cost_voxel[act_size2*act_size_z];
    for(int i=0;i<act_size2*act_size_z;i++)d_score_table[i]=0;
    for(int i=0;i<act_size2*act_size_z;i++)
    {
        cost_map_[i].mark_none();
        cost_map_[i].father.x=0;
        cost_map_[i].father.y=0;
        cost_map_[i].father.z=0;
    }

    for(int i=0;i<snapshot_x;i++)
        for(int ii=0;ii<snapshot_y;ii++)
            for(int iii=0;iii<snapshot_z;iii++)space_snapshot[i][ii][iii]=0;

    core_way_points.clear();

    search_area_x_chunk = 10;
    search_area_y_chunk = 10;
    search_area_z_chunk = 2;
}

/*
     * 新定义cost：d_score 距离场
     *
     * 定义为当前点到起点-终点连线线段的垂直距离
     */

inline double GlobalPlanner::get_d_score_fast(int x,int y,float* d_score_table)
{
    return d_score_table[y*act_size+x];
}
inline double GlobalPlanner::get_d_score_fast3(int x,int y,int z,float* d_score_table)
{
    return d_score_table[z*(act_size2)+y*act_size+x];
}

inline int GlobalPlanner::get_h_score(int x,int y,int dx,int dy)
{
    int hs=(abs(dx-x)+abs(dy-y));
    return hs;
}
/*
 * 使用当前点到目标点的欧氏距离平方作为h_score
 */
inline double GlobalPlanner::get_h_score3(int x,int y,int z,int dx,int dy,int dz)
{
    double hs=((dx-x)*(dx-x)+(dy-y)*(dy-y)+(dz-z)*(dz-z));
    return hs;
}
/*
 * 使用当前点到目标点的欧氏距离作为h_score
 * 最终效果最为理想，但是会显著增加遍历区域，降低实时性
 */
inline double GlobalPlanner::get_h_score31(int x,int y,int z,int dx,int dy,int dz)
{
    double hs=sqrt((dx-x)*(dx-x)+(dy-y)*(dy-y)+(dz-z)*(dz-z));
    return hs;
}

inline int GlobalPlanner::get_g_score_father(cost_voxel* path_map,int x,int y)
{
    // 此处有障碍物，或者无父节点，返回无效值
    if(path_map[y*act_size+x].value==1)return -1;
    if(path_map[y*act_size+x].father.x==0&&path_map[y*act_size+x].father.y==0)return -1;

    int fx=path_map[y*act_size+x].father.x;
    int fy=path_map[y*act_size+x].father.y;

    double dist=10*(((fx-x)*(fx-x)+(fy-y)*(fy-y)));
//    double dist=10*sqrt((double)((fx-x)*(fx-x)+(fy-y)*(fy-y)));

    int fd=dist;
    return fd;
}
inline int GlobalPlanner::get_g_score_father3(cost_voxel* path_map,int x,int y,int z)
{
    cost_voxel* tp=&path_map[z*(act_size2)+y*act_size+x];
    // 此处有障碍物，或者无父节点，返回无效值
    if(tp->value==1)return -1;
    if(tp->father.x==0
       &&tp->father.y==0
       &&tp->father.z==0)return -1;

    int fx=tp->father.x;
    int fy=tp->father.y;
    int fz=tp->father.z;

    double dist=10*(((fx-x)*(fx-x)+(fy-y)*(fy-y)+(fz-z)*(fz-z)));

    int fd=dist;
    return fd;
}

inline int GlobalPlanner::get_dist(int x,int y,int fx,int fy)
{
    double dist=10*(((fx-x)*(fx-x)+(fy-y)*(fy-y)));
    return (int)dist;
}
inline double GlobalPlanner::get_dist3(int x,int y,int z,int fx,int fy,int fz)
{
    double dist=10*(((fx-x)*(fx-x)+(fy-y)*(fy-y)+(fz-z)*(fz-z)));
    return dist;
}

inline int GlobalPlanner::get_g_score(cost_voxel* path_map,int x,int y)
{
    // 此处有障碍物，或者无父节点，返回无效值
    if(path_map[y*act_size+x].value==1)return -1;
    if(path_map[y*act_size+x].father.x==0&&path_map[y*act_size+x].father.y==0)return -1;

    // 计算此节点和父节点的距离，然后累加父节点的g_score得到自身的g_score
    int fx=path_map[y*act_size+x].father.x;
    int fy=path_map[y*act_size+x].father.y;
    int fd=get_g_score_father(path_map,x,y);
    int fg=path_map[fy*act_size+fx].g_score;

    return (fd+fg);
}
inline double GlobalPlanner::get_g_score3(cost_voxel* path_map,int x,int y,int z)
{
    cost_voxel* tp=&path_map[z*(act_size2)+y*act_size+x];

    // 此处有障碍物，或者无父节点，返回无效值
    if(tp->value==1)return -1;
    if(tp->father.x==0
       &&tp->father.y==0
       &&tp->father.z==0)return -1;

    // 计算此节点和父节点的距离，然后累加父节点的g_score得到自身的g_score
    int fx=tp->father.x;
    int fy=tp->father.y;
    int fz=tp->father.z;
    int fd=get_g_score_father3(path_map,x,y,z);
    double fg=path_map[fz*(act_size2)+fy*act_size+fx].g_score;

    return (fd+fg);
}

/*
 * 根据需求的起点和终点，计算关键路径
 */
std::vector<Eigen::Vector3d> GlobalPlanner::find_path(const Eigen::Vector3d start_point,
                                               const Eigen::Vector3d target_point,
                                               VoxelMap *Map_)
{

    Timer timer;
    timer.tic();

    std::vector<Eigen::Vector3d> essential_way_points_core_full;

    // 清空A*地图
    memset(cost_map_,0,act_size2*act_size_z*sizeof(cost_voxel));
    memset(space_snapshot,0,act_size2*act_size_z*sizeof(bool));
    memset(space_snapshot_2,0,act_size2*act_size_z*sizeof(bool));

    /*
     * 1. 转化起点终点的坐标
     * 2. 从Map_中拿出飞机附近的体素，转换坐标，录入A*搜索地图
     * 3. 执行搜索，得到路径
     * 4. 在路径上搜索关键路径点
     */
#ifdef debug_planning
    cout<<"start_point ------------------------ "<<start_point<<endl;
    cout<<"target_point ------------------------ "<<target_point<<endl;
#endif

    Eigen::Vector3d map_start = start_point;
    Eigen::Vector3d map_target = target_point;
    map_start(0) += CENTRE_OFFSET_M;
    map_start(1) += CENTRE_OFFSET_M;
    map_start(2) += CENTRE_OFFSET_M;

    map_target(0) += CENTRE_OFFSET_M;
    map_target(1) += CENTRE_OFFSET_M;
    map_target(2) += CENTRE_OFFSET_M;

    int start_chunk_x = floor(map_start(0)/CHUNK_SIDE_SIZE_M);
    int start_chunk_y = floor(map_start(1)/CHUNK_SIDE_SIZE_M);
    int start_chunk_z = floor(map_start(2)/CHUNK_SIDE_SIZE_M);

    /*
     * 将起点位置附近的chunk提取出来，更新A*地图
     */
    int ct = 0;
    Eigen::Vector3d local_position;
    Eigen::Vector3i local_position_grid;

    for(int x=start_chunk_x-5;x<=start_chunk_x+search_area_x_chunk/2;x++)
    {
        for(int y=start_chunk_y-5;y<=start_chunk_y+search_area_y_chunk/2;y++)
        {
            for(int z=start_chunk_z-1;z<=start_chunk_z+search_area_z_chunk/2;z++)
            {
                int chunk_id = chunk_grid_num_2_id(Eigen::Vector3i(x,y,z));
                if(Map_->chunk_map_.count(chunk_id))
                {
                    Chunk_ptr chunk = Map_->chunk_map_[chunk_id];
                    /*
                     * 遍历chunk中的每一个体素
                     */
                    for (int i = 0; i < chunk->voxels.size(); ++i) {
                        Voxel_ptr voxel_ptr = chunk->voxels[i];

                        if(voxel_ptr && voxel_ptr->is_valid)
                        {
                            // 转化为局部坐标
                            local_position = voxel_ptr->world_pos-start_point;

                            // 转化为网格坐标
                            local_position_grid(0) = floor(local_position(0)/VOXEL_SIZE_M)+(search_area_x_chunk/2)*CHUNK_SIDE_SIZE_VOXEL;
                            local_position_grid(1) = floor(local_position(1)/VOXEL_SIZE_M)+(search_area_y_chunk/2)*CHUNK_SIDE_SIZE_VOXEL;
                            local_position_grid(2) = floor(local_position(2)/VOXEL_SIZE_M)+(search_area_z_chunk/2)*CHUNK_SIDE_SIZE_VOXEL;

                            if(local_position_grid(0)>=snapshot_x||local_position_grid(0)<0
                                    ||local_position_grid(1)>=snapshot_y||local_position_grid(1)<0
                                    ||local_position_grid(2)>=snapshot_z||local_position_grid(2)<0
                                    )
                                continue;

                            space_snapshot_2[local_position_grid(0)][local_position_grid(1)][local_position_grid(2)] = 1;

                            // 录入A*地图
                            for(int dz = max(0,local_position_grid(2)-inflation_range);dz<=min(act_size_z-1,local_position_grid(2)+inflation_range);dz++)
                            for(int dy = max(0,local_position_grid(1)-inflation_range);dy<=min(act_size-1,local_position_grid(1)+inflation_range);dy++)
                            for(int dx = max(0,local_position_grid(0)-inflation_range);dx<=min(act_size-1,local_position_grid(0)+inflation_range);dx++)
                            {
                                cost_map_[dz*act_size2+dy*act_size+dx].value=1;
                                space_snapshot[dx][dy][dz] = 1;
                            }
                        }
                    }
                }
            }
        }
    }
    /*
     * 计算起点终点的网格坐标
     */
    searching_end_voxel(0) = floor(((target_point-start_point)(0))/VOXEL_SIZE_M)+CHUNK_SIDE_SIZE_VOXEL*search_area_x_chunk/2;
    searching_end_voxel(1) = floor(((target_point-start_point)(1))/VOXEL_SIZE_M)+CHUNK_SIDE_SIZE_VOXEL*search_area_y_chunk/2;
    searching_end_voxel(2) = floor(((target_point-start_point)(2))/VOXEL_SIZE_M)+CHUNK_SIDE_SIZE_VOXEL*search_area_z_chunk/2;

    searching_start_voxel(0) = CHUNK_SIDE_SIZE_VOXEL*search_area_x_chunk/2;
    searching_start_voxel(1) = CHUNK_SIDE_SIZE_VOXEL*search_area_y_chunk/2;
    searching_start_voxel(2) = CHUNK_SIDE_SIZE_VOXEL*search_area_z_chunk/2;

//    timer.toc("    path searching prepare");

    /*
     * 执行 A* , 计算核心路径点
     */
    bool go = EvaluatePlanningNecessity(start_point, target_point);


    if(go)
    {
        timer.tic();
        essential_way_points_core = FindEssentialPath();
//        timer.toc("    ++++++++++++++++++++ FindEssentialPath ");

        cout<<"debug 4"<<endl;


        // 变换为世界坐标
        for(int i=0;i<essential_way_points_core.size();i++)
        {
            essential_way_points_core[i]+=Eigen::Vector3d(-VOXEL_SIZE_M*CHUNK_SIDE_SIZE_VOXEL*(search_area_x_chunk/2),
                                            -VOXEL_SIZE_M*CHUNK_SIDE_SIZE_VOXEL*(search_area_y_chunk/2),
                                            -VOXEL_SIZE_M*CHUNK_SIDE_SIZE_VOXEL*search_area_z_chunk/2)+start_point;
        }
    }


    return essential_way_points_core;
}
bool GlobalPlanner::MaintainProgress(const Eigen::Vector3d start_point, const Eigen::Vector3d target_point) {

    /*
     * 判断当前的路径执行进度
     * 根据当前所在位置来判断已经到达的路径点
     * 根据路径点到达情况对路径数据进行相应的维护操作
     */

    if(essential_way_points_core.size()<=1)
        return true;

    // 每检测到到达一个路径点，删除此路径点前的所有路径点
    double wp_aprox_threshold = 0.5;

    int progress = -1;

    /*
     * 从后往前遍历
     */
    for(int i=1;i<essential_way_points_core.size()-1;i++)
    {
        Eigen::Vector3d wp = essential_way_points_core[i];
        if((wp-start_point).norm()<=wp_aprox_threshold)
        {
            progress = i;
            break;
        }
    }

    if(progress!=-1)
    {
        vector<Eigen::Vector3d> tmp_path;
        for(int i=0;i<essential_way_points_core.size();i++)
        {
            if(i<=progress)tmp_path.push_back(essential_way_points_core[i]);
        }
        essential_way_points_core.clear();
        for(int i=0;i<tmp_path.size();i++)
        {
            essential_way_points_core.push_back(tmp_path[i]);
        }
    }
}

bool GlobalPlanner::EvaluatePlanningNecessity(const Eigen::Vector3d start_point,
                                              const Eigen::Vector3d target_point)
{
    Timer timer;
    timer.tic();
    /*
     * 重规划判定
     */

    if(essential_way_points_core.size()<2){
        return true;
    }

    /*
     * 1. 将起点终点强制改为世界坐标的起点终点
     */
    action_start = start_point;
    action_end = target_point;

    Eigen::Vector3d c_loc = action_start;

    /*
     * condition 1
     * 计算飞机到当前整条路径的距离
     * 飞机当前位置距离[整段路径的最小距离]太远
     */
    double min_PPD_threshold = 1;
    double min_PPD=10000000;
    for(int i=0;i<essential_way_points_core.size()-1;i++)
    {
        Eigen::Vector3d piece_start;
        Eigen::Vector3d piece_end;

        piece_start=essential_way_points_core[i];
        piece_end=essential_way_points_core[i+1];

        // 计算：当前位置到此线段的两个端点的距离之和减去此线段长度
        double point_piece_dist=0;
        double piece_len=(piece_start-piece_end).norm();
        double l1=(c_loc-piece_start).norm();
        double l2=(c_loc-piece_end).norm();
        point_piece_dist=(l1+l2)-piece_len;
        if(min_PPD>=point_piece_dist)min_PPD=point_piece_dist;
    }
    // 根据到所有线段的距离中最小的值，来判断是否需要重规划
    if(min_PPD>=min_PPD_threshold){

        return true;
    }

    /*
     * condition 2
     * 目标位置和之前规划的位置不一样而且发生了太大的变化
     */
    double target_move_threshold = 1;
    if((action_end-essential_way_points_core[0]).norm()>=target_move_threshold)
    {
        return true;
    }

    /*
     * condition 3
     * 当前路径上有障碍物
     */
    for(int i=0;i<=essential_way_points_core.size()-2;i++)
    {
        Eigen::Vector3d piece_start;
        Eigen::Vector3d piece_end;
        Eigen::Vector3d piece_unit;

        piece_start=essential_way_points_core[i];
        piece_end=essential_way_points_core[i+1];

        double f_step = 0.2;
        double f_ = 0;
        double piece_len = (piece_start-piece_end).norm();
        piece_unit = (piece_end-piece_start)/piece_len;

        for(;f_<=piece_len;f_+=f_step)
        {
            Eigen::Vector3d piece_test = f_ * piece_unit + piece_start - start_point;
            int ix = floor(piece_test(0)/VOXEL_SIZE_M)+(search_area_x_chunk/2)*CHUNK_SIDE_SIZE_VOXEL;
            int iy = floor(piece_test(1)/VOXEL_SIZE_M)+(search_area_y_chunk/2)*CHUNK_SIDE_SIZE_VOXEL;
            int iz = floor(piece_test(2)/VOXEL_SIZE_M)+(search_area_z_chunk/2)*CHUNK_SIDE_SIZE_VOXEL;
            if(space_snapshot_2[ix][iy][iz]==1)
            {
                // 碰到了障碍物,重新规划
                return true;
            }
        }

    }

    return false;
}

std::vector<Eigen::Vector3d> GlobalPlanner::FindEssentialPath() {

    std::vector<Eigen::Vector3d> essential_way_points_core_full;

    // 约束在搜索空间内
    searching_end_voxel(0) = max(0,int(searching_end_voxel(0)));
    searching_end_voxel(0) = min(int(CHUNK_SIDE_SIZE_VOXEL*search_area_x_chunk) , (searching_end_voxel(0)));
    searching_end_voxel(1) = max(0,int(searching_end_voxel(1)));
    searching_end_voxel(1) = min(int(CHUNK_SIDE_SIZE_VOXEL*search_area_y_chunk) , (searching_end_voxel(1)));
    searching_end_voxel(2) = max(0,int(searching_end_voxel(2)));
    searching_end_voxel(2) = min(int(CHUNK_SIDE_SIZE_VOXEL*search_area_z_chunk) , (searching_end_voxel(2)));

    start_=cv::Point3i(searching_start_voxel(0),searching_start_voxel(1),searching_start_voxel(2));
    end_=cv::Point3i(searching_end_voxel(0),searching_end_voxel(1),searching_end_voxel(2));

    /*
     *   A-Star Path Searching
     */
    open_set.clear();
    close_set.clear();

    // 检测start或者end在不在障碍物上，如果在，进行微调
    if(cost_map_[start_.z*act_size2+start_.y*act_size+start_.x].value==1)
    {
        int min_dist=100000;
        Point3i close_start;
        for(int z=start_.z-10;z<=start_.z+10;z++)
            for(int y=start_.y-10;y<=start_.y+10;y++)
            {
                for(int x=start_.x-10;x<=start_.x+10;x++)
                {
                    if(!(z>=0&&z<act_size_z&&x>=0&&x<act_size&&y>=0&&y<act_size))continue;
                    if(cost_map_[z*act_size2+y*act_size+x].value == 0)
                    {
                        double dist=sqrt((x-start_.x)*(x-start_.x)+(y-start_.y)*(y-start_.y)+(z-start_.z)*(z-start_.z));
                        if(min_dist>=dist)
                        {
                            min_dist=dist;
                            close_start.x=x;
                            close_start.y=y;
                            close_start.z=z;
                        }
                    }

                }
            }

        start_.x=close_start.x;
        start_.y=close_start.y;
        start_.z=close_start.z;
    }
    if(cost_map_[end_.z*act_size2+end_.y*act_size+end_.x].value==1)
    {
        int min_dist=100000;
        Point3i close_end;
        for(int z=end_.z-10;z<=end_.z+10;z++)
            for(int x=end_.x-10;x<=end_.x+10;x++)
            {
                for(int y=end_.y-10;y<=end_.y+10;y++)
                {
                    if(!(z>=0&&z<act_size_z&&x>=0&&x<act_size&&y>=0&&y<act_size))continue;
                    if(cost_map_[z*act_size2+y*act_size+x].value == 0)
                    {
                        double dist=sqrt((x-end_.x)*(x-end_.x)+(y-end_.y)*(y-end_.y)+(z-end_.z)*(z-end_.z));
                        if(min_dist>=dist)
                        {
                            min_dist=dist;
                            close_end.x=x;
                            close_end.y=y;
                            close_end.z=z;
                        }
                    }
                }
            }
        end_.x=close_end.x;
        end_.y=close_end.y;
        end_.z=close_end.z;
    }

//    path_map[start_.z*act_size2+start_.y*act_size+start_.x].value=1;
//    path_map[end_.z*act_size2+end_.y*act_size+end_.x].value=1;

    // 构建 d-score 快速查找表

    double start_x=start_.x;
    double start_y=start_.y;
    double start_z=start_.z;
    double end_x=end_.x;
    double end_y=end_.y;
    double end_z=end_.z;
    Point3d start_to_end(end_x-start_x,end_y-start_y,end_z-start_z);
    Point3d middle_point((end_x+start_x)/2,(end_y+start_y)/2,(end_z+start_z)/2);
    double ste_len=sqrt(start_to_end.x*start_to_end.x+start_to_end.y*start_to_end.y+start_to_end.z*start_to_end.z);
    Point3d start_to_end_norm(start_to_end.x/ste_len,start_to_end.y/ste_len,start_to_end.z/ste_len);
    for(float z=0;z<act_size_z;z++)
        for(float y=0;y<act_size;y++)
        {
            for(float x=0;x<act_size;x++)
            {
                Point3d to_start(x-start_x,y-start_y,z-start_z);
                float dist=0;
                float prj=to_start.dot(start_to_end_norm);
                Point3d dist_v=to_start-start_to_end_norm*prj;
                dist=(dist_v.x*dist_v.x+dist_v.y*dist_v.y+dist_v.z*dist_v.z);
                // 当前搜索位置在起点之前或者终点之后
                if(prj<0)
                {
                    int dd=(to_start.x*to_start.x+to_start.y*to_start.y+to_start.z*to_start.z);
                    dist+=dd;
                }
                else if(prj>ste_len)
                {
                    Point3d to_end(x-end_.x,y-end_.y,z-end_.z);
                    dist+=(to_end.x*to_end.x+to_end.y*to_end.y+to_end.z*to_end.z);
                }

                // 高度加权
                float h=2*abs(z-middle_point.z);
                // 使用 pow 会造成严重耗时，建议使用整数幂
                float h_weight=h*h*h*h;//pow(h,h_w);

                d_score_table[(int)(z*act_size2+y*act_size+x)]=dist+h_weight;
            }
        }

    // 初始化start点周围的节点
    cost_map_[start_.z*act_size2+start_.y*act_size+start_.x].mark_close();
    close_set.push_back(start_);

    for(int z=start_.z-1;z<=start_.z+1;z++)
        for(int y=start_.y-1;y<=start_.y+1;y++)
        {
            for(int x=start_.x-1;x<=start_.x+1;x++)
            {
                if(!(z>=0&&z<act_size_z&&x>=0&&x<act_size&&y>=0&&y<act_size))continue;
                if(x==start_.x&&y==start_.y&&z==start_.z)continue;

                if(cost_map_[z*act_size2+y*act_size+x].value == 0&&cost_map_[z*act_size2+y*act_size+x].open_close==0)
                {
                    // Link father
                    cost_map_[z*act_size2+y*act_size+x].father.x=start_.x;
                    cost_map_[z*act_size2+y*act_size+x].father.y=start_.y;
                    cost_map_[z*act_size2+y*act_size+x].father.z=start_.z;
                    // 计算g_score
                    int gs=get_g_score_father3(cost_map_,x,y,z);
                    cost_map_[z*act_size2+y*act_size+x].g_score=gs;
                    // 计算h_score
                    int hs=get_h_score3(x,y,z,end_.x,end_.y,end_.z);
                    cost_map_[z*act_size2+y*act_size+x].h_score=hs;

                    // 计算f_score
                    int fs=gs+hs;
                    cost_map_[z*act_size2+y*act_size+x].f_score=fs;

                    // 加入open set
                    cost_map_[z*act_size2+y*act_size+x].mark_open();
                    open_set[fs]=Point3i(x,y,z);
                }

            }
        }

    int openset_ct=0;
    for(;!open_set.empty();openset_ct++)
    {
        // 选取open集里面f_score最小值的节点

        double min_fs=100000000;
        map<double,Point3i>::iterator min_it=open_set.begin();

        if(!(min_it->second.z>=0&&min_it->second.z<act_size_z&&min_it->second.x>=0
             &&min_it->second.x<act_size&&min_it->second.y>=0&&min_it->second.y<act_size))continue;
        // 将最优节点加入close集，并且标记close
        int min_x=min_it->second.x;
        int min_y=min_it->second.y;
        int min_z=min_it->second.z;
        close_set.push_back(Point3i(min_it->second.x,min_it->second.y,min_it->second.z));
        cost_map_[min_it->second.z*act_size2+min_it->second.y*act_size+min_it->second.x].mark_close();
        // 移出open集
        open_set.erase(min_it);

        // 对于此节点搜索3*3邻域
        // 对于不在open set中的节点，加入open set并且计算三个score
        // 对于已经在open set中的节点，执行g_score|f_score|father更新
        for(int z=min_z-1;z<=min_z+1;z++)
            for(int y=min_y-1;y<=min_y+1;y++)
            {
                for(int x=min_x-1;x<=min_x+1;x++)
                {
                    if(!(z>=0&&z<act_size_z&&x>=0&&x<act_size&&y>=0&&y<act_size))continue;
                    if(x==min_x&&y==min_y&&z==min_z)continue;

                    cost_voxel* tp=&cost_map_[z*act_size2+y*act_size+x];
                    if(tp->value == 0 && tp->open_close==0)
                    {
                        // Link father
                        tp->father.x=min_x;
                        tp->father.y=min_y;
                        tp->father.z=min_z;
                        // 计算g_score
                        double gs=get_g_score3(cost_map_,x,y,z);
                        tp->g_score=gs;
                        // 计算h_score
                        double hs=get_h_score3(x,y,z,end_.x,end_.y,end_.z);
                        tp->h_score=hs;
                        // d_score
                        double ds=get_d_score_fast3(x,y,z,d_score_table);
                        // 计算f_score
                        double fs=(gs+hs)*ds;
//                        double fs=(gs+hs);
                        tp->f_score=fs;

                        // 加入open set
                        tp->mark_open();
                        open_set[fs]=Point3i(x,y,z);
                    }
                    else if(tp->value == 0 && tp->open_close==1)   // 无障碍物且已经包含在open set中
                    {
                        // 计算此节点以当前关注中心为父节点的情况下的 g_score
                        int vgs=get_dist3(x,y,z,min_x,min_y,min_z)+cost_map_[min_z*act_size2+min_y*act_size+min_x].g_score;
                        // 如果新得到的g_score更小，则更新此节点的所有数据
                        if(vgs<tp->g_score)
                        {
                            tp->g_score=vgs;
                            tp->f_score=vgs+tp->h_score;
                            tp->father.x=min_x;
                            tp->father.y=min_y;
                            tp->father.z=min_z;
                        }
                        else
                        {
                            // do-nothing
                        }
                    }
                }
            }

        if(open_set.empty())
        {
            // open set 已经为空
#ifdef debug_planning
            cout<<"open_set ran out "<<endl;
#endif
            target_found=false;
            break;
        }
        if(cost_map_[end_.z*act_size2+end_.y*act_size+end_.x].open_close==1)
        {
#ifdef debug_planning
            cout<<" TARGET FOUND !! "<<endl;
            cout<<" close_set size : "<<close_set.size()<<endl;
            Point3d lenv=start_-end_;
            double len=0.2*sqrt(lenv.x*lenv.x+lenv.y*lenv.y+lenv.z*lenv.z);
            cout<<"strait distance : "<<len<<endl<<endl;
#endif
            target_found=true;
            break;
        }
    }

    if(target_found)
    {
#ifdef debug_planning
        cout<<"openset_ct : "<<openset_ct<<endl;
#endif

        final_path.clear();
        final_path_d.clear();

        // 回溯路径
        int tb_x=end_.x;
        int tb_y=end_.y;
        int tb_z=end_.z;
        for(;tb_z!=start_.z||tb_x!=start_.x||tb_y!=start_.y;)
        {
            final_path.push_back(Point3i(tb_x,tb_y,tb_z));
            essential_way_points_core_full.push_back(Eigen::Vector3d(VOXEL_SIZE_M*tb_x,
                                                                     VOXEL_SIZE_M*tb_y,
                                                                     VOXEL_SIZE_M*(-15+tb_z)));
            int bx=cost_map_[tb_z*act_size2+tb_y*act_size+tb_x].father.x;
            int by=cost_map_[tb_z*act_size2+tb_y*act_size+tb_x].father.y;
            int bz=cost_map_[tb_z*act_size2+tb_y*act_size+tb_x].father.z;
            tb_x=bx;
            tb_y=by;
            tb_z=bz;
        }

        /*
         * 提取关键路径点
         * 1. 根据方向变化筛选出所有的转向点
         * 2. 对每个转向点进行"剔除影响"模拟，计算剔除评价
         * 3. 如果剔除之后的新路径上没有障碍物，从 final_path 中剔除
         * 4. 最后剩下的就是关键路径点
         */
        // 筛选转向点
        turning_points.clear();
        turning_points_mark.clear();
        turning_points.push_back(final_path[0]);
        turning_points_mark.push_back(true);
        if(final_path.size()>2){
            for(int i=1;i<final_path.size()-1;i++){

                Eigen::Vector3d prev_p;prev_p.setZero();
                Eigen::Vector3d curr_p;curr_p.setZero();
                Eigen::Vector3d next_p;next_p.setZero();
                prev_p(0)=final_path[i-1].x;
                prev_p(1)=final_path[i-1].y;
                prev_p(2)=final_path[i-1].z;
                curr_p(0)=final_path[i].x;
                curr_p(1)=final_path[i].y;
                curr_p(2)=final_path[i].z;
                next_p(0)=final_path[i+1].x;
                next_p(1)=final_path[i+1].y;
                next_p(2)=final_path[i+1].z;
                Eigen::Vector3d prev_direction=curr_p-prev_p;
                Eigen::Vector3d next_direction=next_p-curr_p;

                prev_direction/=prev_direction.norm();
                next_direction/=next_direction.norm();
                if(prev_direction!=next_direction)
                {
                    turning_points.push_back(final_path[i]);
                    turning_points_mark.push_back(true);
                }
            }
        }
        turning_points.push_back(final_path[final_path.size()-1]);
        turning_points_mark.push_back(true);

//        cout<<"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@turning_points : "<<turning_points.size()<<endl;

        /*
         * 第一步，双向临近剔除
         * 迭代的进行"剔除影响"测试，生成用于计算最终最短路径的候选集合
         */
        for(int k=0;k<2;k++)
        {
            double sens_range=0;
            essential_way_points.clear();
            essential_way_points.push_back(0.2*final_path[0]);
            for(int i=1;turning_points.size()>2 && i<turning_points.size()-1;i++)
            {
                Eigen::Vector3d prev_p;prev_p.setZero();
                Eigen::Vector3d next_p;next_p.setZero();

                int prev=i,next=i;
                for(int ii=i-1;ii>=0;ii--)
                {
                    if(turning_points_mark[ii]){
                        prev=ii;
                        break;
                    }
                }
                for(int ii=i+1;ii<turning_points.size();ii++)
                {
                    if(turning_points_mark[ii]){
                        next=ii;
                        break;
                    }
                }

                prev_p(0)=turning_points[prev].x;
                prev_p(1)=turning_points[prev].y;
                prev_p(2)=turning_points[prev].z;
                next_p(0)=turning_points[next].x;
                next_p(1)=turning_points[next].y;
                next_p(2)=turning_points[next].z;
                Eigen::Vector3d direction=next_p-prev_p;
                double len=direction.norm();
                direction/=len;
                double step=1;
                bool path_ok=true;
                for(double forward=0;forward<len;forward+=step)
                {
                    Eigen::Vector3d pos=prev_p+forward*direction;
                    double x=pos(0),y=pos(1),z=pos(2);
                    bool sens_block=false;
                    for(int zz=z-sens_range;!sens_block && zz<=z+sens_range;zz++)
                        for(int yy=y-sens_range;!sens_block && yy<=y+sens_range;yy++)
                        {
                            for(int xx=x-sens_range;!sens_block && xx<=x+sens_range;xx++)
                            {
                                if(!(zz>=0&&zz<act_size_z&&xx>=0&&xx<act_size&&yy>=0&&yy<act_size))continue;
                                if(space_snapshot[xx][yy][zz]==1)
                                {
                                    sens_block=true;
                                }
                            }
                        }
                    if(sens_block)
                    {
                        // 有障碍物
                        path_ok=false;
                        break;
                    }
                    else path_ok=true;
                }
                if(!path_ok)
                {
                    // 有障碍物
                    turning_points_mark[i]=true;    // 保留
                    essential_way_points.push_back(0.2*turning_points[i]);
                }
                else
                {
                    turning_points_mark[i]=false;   // 剔除
                }
            }
            essential_way_points.push_back(0.2*final_path[final_path.size()-1]);

            turning_points.clear();
            turning_points_mark.clear();
            for(int i=0;i<essential_way_points.size();i++)
            {
                turning_points.push_back((1.0/0.2)*essential_way_points[i]);
                turning_points_mark.push_back(true);
            }
        }

//        cout<<"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@turning_points 2 : "<<turning_points.size()<<endl;


        /*
         * 第二步：简化单向连接图
         */

        /*
         * [传统方法：计算单向链接图中的单源最短路径]
         * 得到了初始路径，现在计算完整连接图，以及图中的最短路径:
         *      1. 遍历空间切片，计算完整连接图
         *      2. 生成基于路径长度加权的连接矩阵
         *      3. 深度优先遍历连接矩阵中的所有路径，找到最短路径
         *
         * [快速版本：使用简化单向连接图代替最短路径]
         * 在第一步"遍历空间切片，计算完整连接图" 的过程中直接选择跳过
         * 两点间的通路的中间点，即检测到新的通路直接删除两点间的所有路径点
         *      1. 从第一个路径点开始，计算每个节点的完整链接路径
         *      2. 对每个节点，选取最长的链接路径，删除中间的所有节点
         *      3. 在新的节点集合中重新开始执行第一步
         */
        essential_points_mark.clear();
        core_way_points.clear();
        for(int i=0;i<essential_way_points.size();i++)
        {
            essential_points_mark.push_back(true);
        }
        for(int i=0;essential_way_points.size()>=3&&i<essential_way_points.size();i++)
        {
            for(int ii=essential_way_points.size()-1;ii>=i+1;ii--)
            {
                // 检测[i]和[ii]之间能否连接，能的话就删掉中间的所有点，更改i指针位置
                Eigen::Vector3d prev_p;prev_p.setZero();
                Eigen::Vector3d next_p;next_p.setZero();
                prev_p(0)=(1.0/0.2)*essential_way_points[i].x;
                prev_p(1)=(1.0/0.2)*essential_way_points[i].y;
                prev_p(2)=(1.0/0.2)*essential_way_points[i].z;
                next_p(0)=(1.0/0.2)*essential_way_points[ii].x;
                next_p(1)=(1.0/0.2)*essential_way_points[ii].y;
                next_p(2)=(1.0/0.2)*essential_way_points[ii].z;
                double sens_range=0;
                Eigen::Vector3d direction=next_p-prev_p;
                double len=direction.norm();
                direction=(1.0d/len)*direction;
                double step=1;
                bool path_ok=true;
                for(double forward=0;forward<len;forward+=step)
                {
                    Eigen::Vector3d pos=prev_p+forward*direction;
                    double x=pos(0),y=pos(1),z=pos(2);
                    bool sens_block=false;
                    for(int zz=z-sens_range;!sens_block && zz<=z+sens_range;zz++)
                        for(int yy=y-sens_range;!sens_block && yy<=y+sens_range;yy++)
                        {
                            for(int xx=x-sens_range;!sens_block && xx<=x+sens_range;xx++)
                            {
                                if(!(zz>=0&&zz<act_size_z&&xx>=0&&xx<act_size&&yy>=0&&yy<act_size))continue;
                                if(use_inflation && space_snapshot[xx][yy][zz]==1)
                                {
                                    sens_block=true;
                                }
                                else if(!use_inflation && space_snapshot_2[xx][yy][zz]==1)
                                {
                                    sens_block=true;
                                }
                            }
                        }
                    if(sens_block)
                    {
                        // 有障碍物
                        path_ok=false;
                        break;
                    }
                    else path_ok=true;
                }
                if(!path_ok)
                {
                    // 有障碍物
                }
                else
                {
                    // 无障碍物，发现新的通路，删除i和ii之间的所有点
                    for(int u=i+1;u<ii;u++)essential_points_mark[u]=false;
                    i=ii-1;
                    break;
                }
            }
        }
        for(int i=0;i<essential_way_points.size();i++)
        {
            if(essential_points_mark[i]==true)core_way_points.push_back(essential_way_points[i]);
        }

//        cout<<"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@core_way_points : "<<core_way_points.size()<<endl;

    }
#ifdef debug_planning
    cout<<"core_way_points : "<<core_way_points.size()<<endl;
#endif

    std::vector<Eigen::Vector3d> essential_way_points_core;
    for(int i=0;i<core_way_points.size();i++)
    {
        essential_way_points_core.push_back(Eigen::Vector3d(core_way_points[i].x,
                                                            core_way_points[i].y,
                                                            core_way_points[i].z));
    }

    return essential_way_points_core;
}

