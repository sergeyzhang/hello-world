//
// Created by ZZ_AI_Team on 18-4-29.
//

#include "../include/PathFinder.h"
#include "../include/Global.h"
#include "../include/Camera.h"

namespace PathPlanning {

bool DistComapre::operator ()(const DistPosition &p0, const DistPosition &p1) const {
    return p0.dist < p1.dist;
}

PathFinder::PathFinder(VoxelMap *voxel_map, CollisionDetector *collision_detector) {
    voxel_map_ = voxel_map;
    collision_detector_ = collision_detector;
    grid_3d_map_ = new Square3DGrid(INT_MAX, INT_MAX, INT_MAX);
}

std::vector<Eigen::Vector3d> PathFinder::find_path(const Eigen::Vector3d &start_point,
                                                   const Eigen::Vector3d &target_point) {
    path_finder_state_ = PATH_FOUND;

//    std::cout<<" ++++++++++++++++++++++++++++++++++++++++++ path planning START "<<std::endl;

    Eigen::Vector3d safe_target_point = get_safe_target_point(start_point, target_point);
    Eigen::Vector3d safe_start_point = get_safe_target_point(safe_target_point, start_point);

    a_star_find_grid_path2(grid_3d_map_, safe_start_point, safe_target_point);
//    a_star_find_grid_path(grid_3d_map_, start_point, safe_target_point);

//    std::cout<<" ------------------------------------------ path planning DONE "<<std::endl;


    std::cout<<"path_grid_points_.size : "<<path_grid_points_.size()<<std::endl;

    std::vector<Eigen::Vector3d> world_pos;
    for(int i=0;i<path_grid_points_.size();i++)
    {
        Eigen::Vector3d pos_ = voxel_grid_num_2_pos(Eigen::Vector3i(path_grid_points_[i].x, path_grid_points_[i].y, path_grid_points_[i].z));
        world_pos.push_back(pos_);
    }


//    return find_safe_core_point(path_grid_points_, target_point);
    return world_pos;
}

Eigen::Vector3d PathFinder::get_safe_target_point(const Eigen::Vector3d &start_point,
                                                  const Eigen::Vector3d &target_point) {
    Eigen::Vector3d point = target_point;
    while (true) {
        // 检测设置的目标点是否为障碍物
        grid_world_position(point, chunk_grid_num_, voxel_grid_num_,voxel_index_num_, voxel_index_in_chunk_, chunk_id_);
        if (voxel_map_) {
            chunk_map_ = voxel_map_->get_chunk_map();
            if (chunk_map_.count(chunk_id_)) {
                Chunk_ptr c = chunk_map_[chunk_id_];
                Voxel_ptr v = c->voxels[voxel_index_in_chunk_];
                if (v && v->is_valid) {
                    printf("target in obstacle!!!\n");
                    point = point + (target_point - start_point).normalized();
                } else {
                    break;
                }
            } else {
                break;
            }
        }
    }
    return point;
}

/**
 *
 * @param graph
 * @param start_point
 * @param target_point
 */
void PathFinder::a_star_find_grid_path2(Square3DGrid *graph,
                                        const Eigen::Vector3d &start_point,
                                        const Eigen::Vector3d &target_point) {

//        std::cout<<" ++++++++++++++++++++++++++++++++++++++++++ path planning START "<<std::endl;

        path_grid_points_.clear();

    // Step 1: Search directly toward target and stop when found collisions
    Eigen::Vector3d dir = (target_point - start_point).normalized();
    float dist = (target_point - start_point).norm();
    int step_num = dist / VOXEL_SIZE_M;

    Eigen::Vector3i collision_voxel_grid_num;
    bool has_collision = false;
    for (int i = 1; i < step_num; ++i) {
        Eigen::Vector3d p = start_point + i * VOXEL_SIZE_M * dir;
        if (voxel_map_->has_obstacle(p, collision_voxel_grid_num)) {
            has_collision = true;
            break;
        } else {
            path_grid_points_.push_back(Grid3DLocation{collision_voxel_grid_num(0),
                                                       collision_voxel_grid_num(1),
                                                       collision_voxel_grid_num(2)});
        }
    }

//        std::cout<<" ------------------------------------------ path planning step2 "<<std::endl;
    // Step 2: use a star to search the path from the last free collision voxel
//    if (has_collision)
    {
        voxel_map_2_3d_gird_map();

//        std::cout<<" ------------------------------------------ path planning step3 "<<std::endl;

        Grid3DLocation start_l;
        if (path_grid_points_.size() > 2) {
            start_l = path_grid_points_[path_grid_points_.size() - 1];
        } else {
            grid_world_position(start_point, voxel_grid_num_);
            start_l = Grid3DLocation{voxel_grid_num_[0], voxel_grid_num_[1], voxel_grid_num_[2]};
        }

        grid_world_position(target_point, voxel_grid_num_);
        Grid3DLocation target_l{voxel_grid_num_[0], voxel_grid_num_[1], voxel_grid_num_[2]};

//        std::cout<<" ------------------------------------------ path planning step4 "<<std::endl;

        std::map<Grid3DLocation, Grid3DLocation> came_from;
        a_star_search(graph, start_l, target_l, came_from);

//        std::cout<<" ------------------------------------------ path planning step5 "<<std::endl;


        std::vector<Grid3DLocation> path = reconstruct_path(start_l, target_l, came_from);

//        std::cout<<" ------------------------------------------ path planning step6 "<<std::endl;


        path_grid_points_.insert(path_grid_points_.end(), path.begin(), path.end());

    }

//        std::cout<<" ------------------------------------------ path planning step7 "<<std::endl;

}

std::vector<Grid3DLocation> PathFinder::a_star_find_grid_path(Square3DGrid *graph,
                                                              const Grid3DLocation &start_point,
                                                              const Grid3DLocation &target_point) {
    voxel_map_2_3d_gird_map();

    std::map<Grid3DLocation, Grid3DLocation> came_from;
    a_star_search(graph, start_point, target_point, came_from);
    return reconstruct_path(start_point, target_point, came_from);
}

void PathFinder::voxel_map_2_3d_gird_map() {
    grid_3d_map_->walls.clear();
    std::map<int, Chunk_ptr>::iterator it = chunk_map_.begin(), end = chunk_map_.end();

    int ho_chunk = 0;

    while (it != end) {
        Chunk_ptr chunk = it->second;
        double chunk_or = chunk->get_active_percent();
        if(chunk_or >= 0.1)
        {
            ho_chunk++;
//            std::cout<<"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& "<<chunk->chunk_grid_num[0]<<std::endl;
//            for(int x=0;x<CHUNK_SIDE_SIZE_VOXEL;x++)
//            {
//                for(int y=0;y<CHUNK_SIDE_SIZE_VOXEL;y++)
//                {
////                    std::cout<<"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& "<<(((chunk->chunk_grid_num[1])*CHUNK_SIDE_SIZE_VOXEL)+y)<<std::endl;
//                    for(int z=0;z<CHUNK_SIDE_SIZE_VOXEL;z++)
//                    {
//                        int vx=((chunk->chunk_grid_num[0])*CHUNK_SIDE_SIZE_VOXEL)+x;
//                        int vy=((chunk->chunk_grid_num[1])*CHUNK_SIDE_SIZE_VOXEL)+y;
//                        int vz=((chunk->chunk_grid_num[2])*CHUNK_SIDE_SIZE_VOXEL)+z;
//
//                        grid_3d_map_->walls.insert(Grid3DLocation{vx,vy,vz});
//                    }
//                }
//            }
            for (int i = 0; i < chunk->voxels.size(); ++i) {
                Voxel_ptr v = chunk->voxels[i];
//                v->voxel_grid_num
                if (v && v->is_valid) {
//                    grid_3d_map_->walls.insert(Grid3DLocation{v->voxel_grid_num[0],v->voxel_grid_num[1],v->voxel_grid_num[2]});
//                    grid_3d_map_->walls.insert(Grid3DLocation{v->voxel_grid_num[0]-1,v->voxel_grid_num[1]-1,v->voxel_grid_num[2]-1});
//                    grid_3d_map_->walls.insert(Grid3DLocation{v->voxel_grid_num[0]+1,v->voxel_grid_num[1]+1,v->voxel_grid_num[2]+1});

                    for(int x=-2;x<=2;x++)
                        for(int y=-2;y<=2;y++)
                            for(int z=-2;z<=2;z++)
                            {
                                grid_3d_map_->walls.insert(Grid3DLocation{v->voxel_grid_num[0]+x,v->voxel_grid_num[1]+y,v->voxel_grid_num[2]+z});
                            }

//                    std::cout<<"+++++++++++++++++++++++++++++++++++++ "<<v->voxel_grid_num[1]<<std::endl;

//                    std::cout<<" &&&&&&&&&&&& "<<floor(double((v->world_pos[0]+CENTRE_OFFSET_M)/CHUNK_SIDE_SIZE_M))<<std::endl;
//                    std::cout<<" &&&&&&&&&&&&&&&&&& "<<v->voxel_grid_num[0] <<" &&&&&&&&&&&& "<<floor(double((v->world_pos[0]+CENTRE_OFFSET_M)/VOXEL_SIZE_M))<<std::endl;
                }
            }
        } else{
            for (int i = 0; i < chunk->voxels.size(); ++i) {
                Voxel_ptr v = chunk->voxels[i];
                if (v && v->is_valid) {
//                    grid_3d_map_->walls.insert(Grid3DLocation{(int)v->voxel_grid_num[0],
//                                                              (int)v->voxel_grid_num[1],
//                                                              (int)v->voxel_grid_num[2]});

                    grid_3d_map_->walls.insert(Grid3DLocation{v->voxel_grid_num[0],v->voxel_grid_num[1],v->voxel_grid_num[2]});
//                    grid_3d_map_->walls.insert(Grid3DLocation{v->voxel_grid_num[0]-1,v->voxel_grid_num[1]-1,v->voxel_grid_num[2]-1});
//                    grid_3d_map_->walls.insert(Grid3DLocation{v->voxel_grid_num[0]+1,v->voxel_grid_num[1]+1,v->voxel_grid_num[2]+1});


                }
            }
        }

        it++;
    }

//    std::cout<<"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& "<<ho_chunk<<std::endl;

    std::cout<<"grid_3d_map_->walls.size : "<<grid_3d_map_->walls.size()<<std::endl;
}

//std::vector<Grid3DLocation> PathFinder::d_star_find_grid_path(int start_x, int start_y, int end_x, int end_y) {
//    dstar.init(start_x, start_y, end_x, end_y);
//    path_grid_points_.clear();
//
//    std::vector<Eigen::Vector3d> collision_points = collision_detector_->get_collision_voxels_pos();
//    if (collision_points.size() < 1) {
//        return path_grid_points_;
//    }
//    Eigen::Vector3d collision_average_point = Eigen::Vector3d::Zero();
//    for (int i = 0; i < collision_points.size(); ++i) {
//        collision_average_point += collision_points[i];
//    }
//    collision_average_point /= collision_points.size();
//
//    Eigen::Vector3i average_voxel_grid_num;
//    grid_world_position(collision_average_point, average_voxel_grid_num);
//
//    // 切片3d grid map 生成一个 2d grid map
//    int up_index = average_voxel_grid_num(1) + 3;
//    int down_index = average_voxel_grid_num(1) - 3;
//    std::map<int, Chunk_ptr>::iterator it = chunk_map_.begin(), end = chunk_map_.end();
//    while (it != end) {
//        Chunk_ptr chunk = it->second;
//        for (int i = 0; i < chunk->voxels.size(); ++i) {
//            Voxel_ptr v = chunk->voxels[i];
//            if (v && v->is_valid) {
//                if (v->voxel_grid_num[1] < up_index &&
//                    v->voxel_grid_num[1] > down_index) {
//                    dstar.updateCell(v->voxel_grid_num[0], v->voxel_grid_num[2], -1);
//                }
//            }
//        }
//        it++;
//    }
//
//    dstar.replan();
//    std::list<state> dstar_path = dstar.getPath();
//
//    std::list<state>::iterator path_it = dstar_path.begin(), path_end = dstar_path.end();
//    while (path_it != path_end) {
//        path_grid_points_.push_back(Grid3DLocation{(*path_it).x, average_voxel_grid_num(1), (*path_it).y});
//        path_it++;
//    }
//
//    return path_grid_points_;
//}

std::vector<Eigen::Vector3d> PathFinder::find_safe_core_point(const std::vector<Grid3DLocation> &grid_path,
                                                              const Eigen::Vector3d &target) {
    collision_rect_ = cv::Rect(0, 0, 0, 0);
    average_collision_distance_ = -1;
    collision_point_depth_ = -1;
    core_points_w_.clear();

    if (grid_path.size() < 4 ) {
        path_finder_state_ = PATH_GRID_TOO_SHORT;
        std::cout<<"==================== grid_path.size() < 4 "<<std::endl;
        return core_points_w_;
    }

    std::vector<Eigen::Vector3d> collision_points = collision_detector_->get_collision_voxels_pos();
    if (collision_points.size() < 1) {
        printf("collision_points empty\n");
        path_finder_state_ = PATH_NO_COLLISION_POINTS;
        std::cout<<"==================== collision_points.size() < 1 "<<std::endl;
        return core_points_w_;
    }

    // 碰撞体平均位置
    Eigen::Vector3d collision_average_point = Eigen::Vector3d::Zero();
    for (int i = 0; i < collision_points.size(); ++i) {
        collision_average_point += collision_points[i];
    }
    collision_average_point /= collision_points.size();

    Eigen::Vector3d cam_pos = voxel_map_->get_T_wc().translation();

    // 如果检测到的碰撞体与摄像机距离过近, 不适合避障退出
    if (collision_average_point == Eigen::Vector3d::Zero() ||
        (collision_average_point - cam_pos).norm() < VOXEL_SIZE_M * 3) {
        printf("collision_average_point is zero !!! distace to collision: %f\n", (collision_average_point - cam_pos).norm());
        path_finder_state_ = PATH_COLLISION_INVALID;

        std::cout<<"==================== 不适合避障 "<<std::endl;

        return core_points_w_;
    }

    Eigen::Vector2d collision_uv = Camera::instance().reproject_3d_point_2_px(collision_average_point, voxel_map_->get_T_cw());

    cv::Mat disparity = voxel_map_->get_disparity();
    float disparity_value = Config::baseline_f_ / ((cam_pos - collision_average_point).norm() + 0.2);
    collision_rect_ = get_collision_rect(disparity, collision_uv, disparity_value);

    // 如果检测到的碰撞方框占整个图像画面过大比例, 不合理退出
    float collision_ratio = collision_rect_.area() * 1.0 / (disparity.rows * disparity.cols);
    if (collision_ratio > 0.8) {
        printf("collision_ratio %f\n", collision_ratio);
        path_finder_state_ = PATH_BIG_AREA_OBSTACLE;

        std::cout<<"==================== 不合理退出 "<<std::endl;

        return core_points_w_;
    }

    Eigen::Vector3d up(0, 1, 0);
    if (Config::is_fc_ned_) {
        up = Eigen::Vector3d(0, 0, -1);
    }

    Eigen::Vector3d mov_dir = collision_detector_->get_cam_mov_dir();
    Eigen::Vector3d search_dir = mov_dir.cross(up);    // <---

    // 找到到search_dir直线最近的astar路径点
    dist_pos_set_.clear();
    float dist = INT_MAX;
    for (int i = 1; i < grid_path.size() - 1; ++i) {
        DistPosition dist_pos;
        dist_pos.p = voxel_grid_num_2_pos(Eigen::Vector3i(grid_path[i].x, grid_path[i].y, grid_path[i].z));
        dist_pos.dist = get_point_2_line_dist(collision_average_point, collision_average_point + search_dir, dist_pos.p);
        dist_pos_set_.insert(dist_pos);
    }
    Eigen::Vector3d core_point = (*dist_pos_set_.begin()).p;   // 与平均碰撞体距离最小的路径点即为候选关键点

    // 找到关键点与所有碰撞体最近的距离
    Eigen::Vector3d min_voxel;
    float core_2_collision_min_dist = INT_MAX;
    for (int k = 0; k < collision_points.size(); ++k) {
        float dist = (core_point - collision_points[k]).norm();
        if (dist < core_2_collision_min_dist) {
            core_2_collision_min_dist = dist;
            min_voxel = collision_points[k];
        }
    }

    // 如果关键点离最近的碰撞体较近, 需要将关键点沿 dir_collision_2_core 方向推一个安全距离
    Eigen::Vector3d dir_collision_2_core = core_point - collision_average_point;
    if (core_2_collision_min_dist < VOXEL_SIZE_M * 3) {
        core_point += dir_collision_2_core.normalized() * (1 - core_2_collision_min_dist);
    }

    // 关键点在图像的上的像素投影点坐标
    Eigen::Vector2d core_uv = Camera::instance().reproject_3d_point_2_px(core_point, voxel_map_->get_T_cw());

#ifdef DEBUG_LOG
    printf("core_2_collision_min_dist: %f; dist_collision_2_core: %f\n", core_2_collision_min_dist, (core_point - collision_average_point).norm());
#endif

    // 平均碰撞体到摄像机z轴距离
    Eigen::Vector3d collision_point_c = voxel_map_->get_T_cw() * collision_average_point;
    average_collision_distance_ = collision_point_c(2);

    // check go direction
    PathDirection direction = check_path_direction(core_uv, collision_rect_);
    core_point = get_new_core_point_from_direction(direction, collision_uv);
    core_uv = Camera::instance().reproject_3d_point_2_px(core_point, voxel_map_->get_T_cw());

#ifdef DEBUG_LOG
    printf("init dir %d, uv(%f %f)\n", direction, core_uv(0), core_uv(1));
    printf("collision_rect_ %d %d %d %d\n", collision_rect_.x, collision_rect_.y, collision_rect_.width, collision_rect_.height);
    printf("disparity_value %f; mov_dir %f %f %f; collision_average_point %f %f %f\n", disparity_value, mov_dir(0), mov_dir(1), mov_dir(2),
           collision_average_point(0), collision_average_point(1), collision_average_point(2));
    printf("voxel map size %d\n", (int)voxel_map_->get_chunk_map().size());
    printf("before core point %f %f %f\n", core_point(0), core_point(1), core_point(2));
#endif

    bool found_safe_core_point = false;
    if (!check_core_point_valid(disparity, core_point, core_uv, disparity_value, collision_average_point, mov_dir, cam_pos)) {
        // 如果默认优先的方向不合适, 遍历检测其他方向是否可以用于避障
        for (int k = 0; k < 2; ++k) {
            if (k != direction) {
                printf("search dir %d\n", k);
                core_point = get_new_core_point_from_direction((PathDirection)k, collision_uv);
                core_uv = Camera::instance().reproject_3d_point_2_px(core_point, voxel_map_->get_T_cw());
                if (check_core_point_valid(disparity, core_point, core_uv, disparity_value, collision_average_point, mov_dir, cam_pos)) {
                    found_safe_core_point = true;
                    break;
                }
            }
        }
    } else {
        found_safe_core_point = true;
    }

    if (found_safe_core_point) {
        printf("found core point\n");
        collision_point_depth_ = Camera::instance().get_depth_from_disparity(read_disparity(disparity, (int)collision_uv(0), (int)collision_uv(1)));

        path_finder_state_ = PATH_FOUND;

        // 三个点, 避障waypoints, 用于后面进行路径规划
        core_points_w_.push_back(cam_pos);
        core_points_w_.push_back(core_point);
        core_points_w_.push_back(core_point + mov_dir.normalized());

        return core_points_w_;
    }

    return core_points_w_;
}

Eigen::Vector3d PathFinder::get_new_core_point_from_direction(const PathPlanning::PathDirection direction,
                                                              const Eigen::Vector2d &collision_uv) {
    // 根据关键点在碰撞方框的方位, 从新生成更加稳定的关键点
    Eigen::Vector3d core_point;
    float px = -1;
    switch (direction) {
        case GO_LEFT:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, average_collision_distance_);
            core_point = Camera::instance().reproject_px_2_3d_point(collision_rect_.x - px, (int)collision_uv(1),
                                                                    voxel_map_->get_T_wc(), average_collision_distance_);
            break;
        case GO_RIGHT:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, average_collision_distance_);
            core_point = Camera::instance().reproject_px_2_3d_point(collision_rect_.x + collision_rect_.width + px, (int)collision_uv(1),
                                                                    voxel_map_->get_T_wc(), average_collision_distance_);
            break;
        case GO_UP:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, average_collision_distance_);
            core_point = Camera::instance().reproject_px_2_3d_point((int)collision_uv(0), collision_rect_.y - px,
                                                                    voxel_map_->get_T_wc(), average_collision_distance_);
            break;
        case GO_DOWN:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, average_collision_distance_);
            core_point = Camera::instance().reproject_px_2_3d_point((int)collision_uv(0), collision_rect_.y + collision_rect_.height + px,
                                                                    voxel_map_->get_T_wc(), average_collision_distance_);
            break;
    }
    return core_point;
}

bool PathFinder::check_core_point_valid(const cv::Mat &disparity,
                                        const Eigen::Vector3d &core_point,
                                        const Eigen::Vector2d &core_uv,
                                        const float disparity_value,
                                        const Eigen::Vector3d &collision_average_point,
                                        const Eigen::Vector3d &mov_dir,
                                        const Eigen::Vector3d &cam_pos) {
    // 如果关键点不能投影到图像上，或者距离碰撞体过远，说明前方障碍物不适合路径规划
    if (core_uv(0) < 32 || core_uv(1) < 0 ||
        core_uv(0) > Config::img_width_ - 3 ||
        core_uv(1) > Config::img_height_ - 3) {
        path_finder_state_ = PATH_CORE_POINT_OUT_OF_BOUND;
        printf("reprojection uv out of bound %f; (%f %f) \n", (core_point - collision_average_point).norm(), core_uv(0), core_uv(1));
        return false;
    }

    if (check_disparity_valid(disparity, disparity_value, core_uv)) {
        path_finder_state_ = PATH_CORE_POINT_DEPTH_UNNORMAL;
        printf("check disparity invalid\n");
        return false;
    }

    // 检测关键点周边是否有碰撞体
    if (check_core_point_around_collision(core_point, (core_point - collision_average_point).normalized())) {
        path_finder_state_ = PATH_CORE_POINT_NOT_SAFE_AROUND;
        printf("check_core_point_around_collision\n");
        return false;
    }

    // 检测三个关键点连线上有没有碰撞体, 否则返回
    if (voxel_map_->has_obstacle(cam_pos, core_point) ||
        voxel_map_->has_obstacle(core_point, core_point + mov_dir.normalized() * 1.5)) {
        path_finder_state_ = PATH_HAS_COLLISION_TO_CORE_POINT;
        printf("has obstacle from cam_pos to core_point\n");
        return false;
    }

    return true;
}

bool PathFinder::check_disparity_valid(const cv::Mat &disparity, const float disparity_value, const Eigen::Vector2d &uv) {
    int invalid_num = 0;
    for (int i = -2; i < 3; ++i) {
        for (int j = -2; j < 3; ++j) {
            float d = read_disparity(disparity, (int)(uv(0) + i), (int)(uv(1) + j));
            if (d <= 0 || d > disparity_value) {
                invalid_num++;
            }
        }
    }

    if (invalid_num > 12) {
        return true;
    } else {
        return false;
    }
}

bool PathFinder::check_core_point_around_collision(const Eigen::Vector3d &core_point, const Eigen::Vector3d &main_dir) {
    Eigen::Vector3d check_point(0, 0, 0);
    for (int i = -1; i < 2; ++i) {
        for (int j = -1; j < 2; ++j) {
            for (int k = -1; k < 2; ++k) {
                if (i !=0 || j !=0 || k != 0) {
                    check_point(0) = core_point(0) + i * VOXEL_SIZE_M;
                    check_point(1) = core_point(1) + j * VOXEL_SIZE_M;
                    check_point(2) = core_point(2) + k * VOXEL_SIZE_M;
                    if (voxel_map_->has_obstacle(check_point)) {
                        printf("not safe passable distance; check_point:(%f %f %f)\n",
                               check_point(0), check_point(1), check_point(2));
                        return true;
                    }
                }
            }
        }
    }

    if (voxel_map_->has_obstacle(core_point, core_point + main_dir * 0.2)) {
        printf("core point main_dir has obstacle!\n");
        return true;
    }

    return false;
}

cv::Rect PathFinder::get_collision_rect(const cv::Mat &disparity, const Eigen::Vector2d &uv_collision, const float disparity_value) {
    // 找到碰撞点左右上下最大的点
    int left_p = 32, right_p = disparity.cols, up_p = 0, down_p = disparity.rows;

    // left
    for (int i = uv_collision(0); i > 32; --i) {
        float d = read_disparity(disparity, i, (int)uv_collision(1));
        if (d < disparity_value && d > 0) {
            left_p = i;
            break;
        }
    }

    // right
    for (int i = uv_collision(0); i < disparity.cols; ++i) {
        float d = read_disparity(disparity, i, (int)uv_collision(1));
        if (d < disparity_value && d > 0) {
            right_p = i;
            break;
        }
    }

    int new_u = (left_p + right_p) / 2;

    // up
    for (int i = uv_collision(1); i > 0; --i) {
        float d = read_disparity(disparity, new_u, i);
        if (d < disparity_value && d > 0) {
            up_p = i;
            break;
        }
    }

    // down
    for (int i = uv_collision(1); i < disparity.rows; ++i) {
        float d = read_disparity(disparity, new_u, i);
        if (d < disparity_value && d > 0) {
            down_p = i;
            break;
        }
    }

    return cv::Rect(cv::Point(left_p, up_p), cv::Point(right_p, down_p));
}

PathDirection PathFinder::check_path_direction(const Eigen::Vector2d &core_uv, const cv::Rect &collision_rect) {
    double left = collision_rect.x;
    double right = collision_rect.x + collision_rect.width;
    double up = collision_rect.y;
    double down = collision_rect.y + collision_rect.height;

    // left right
    double left_dist = fabs(left - core_uv(0));
    double right_dist = fabs(right - core_uv(0));
    if (left_dist < right_dist) {
        return GO_LEFT;
    } else {
        return GO_RIGHT;
    }

    // 先检测上下, 再检测左右
//    if (core_uv(1) < up || core_uv(1) > down) {
//        // up down
//        double up_dist = fabs(up - core_uv(1));
//        double down_dist = fabs(down - core_uv(1));
//        if (up_dist < down_dist) {
//            return GO_UP;
//        } else {
//            return GO_DOWN;
//        }
//    } else {
//        // left right
//        double left_dist = fabs(left - core_uv(0));
//        double right_dist = fabs(right - core_uv(0));
//        if (left_dist < right_dist) {
//            return GO_LEFT;
//        } else {
//            return GO_RIGHT;
//        }
//    }
}

std::vector<Eigen::Vector3d> PathFinder::simplify_grid_path(const std::vector<Grid3DLocation> &grid_path) {
    std::vector<Grid3DLocation> core_points;
    std::vector<Eigen::Vector3d> core_points_w;
    std::map<int, Grid3DLocation> core_points_map;

    // Step 1: find all the corner points
    if (grid_path.size() < 4 && grid_path.size() > 1) {
        core_points.push_back(grid_path[0]);
        core_points.push_back(grid_path[grid_path.size() - 1]);
    } else if (grid_path.size() < 1) {
        return core_points_w;
    } else {
        Grid3DLocation last_p = grid_path[0];
        core_points.push_back(last_p);
        core_points_map[0] = last_p;
        int id = 1;

        Grid3DLocation p = grid_path[1];
        Grid3DLocation dir = p - last_p;
        last_p = p;
        for (int i = 2; i < grid_path.size() - 1; ++i) {
            Grid3DLocation p = grid_path[i];
            if (dir != (p - last_p)) {
                core_points.push_back(last_p);
                core_points_map[id++] = last_p;
                dir = p - last_p;
            }
            last_p = p;
        }

        core_points.push_back(grid_path[grid_path.size() - 1]);
        core_points_map[id] = grid_path[grid_path.size() - 1];
    }

    if (!voxel_map_) {
        for (int i = 0; i < core_points.size(); ++i) {
            core_points_w.push_back(voxel_grid_num_2_pos(Eigen::Vector3i(core_points[i].x, core_points[i].y, core_points[i].z)));
        }
        return core_points_w;
    }

    // Step 2: find middle waypoint
    std::vector<uchar> status_no_occlusion(core_points.size(), 0);
    std::vector<Eigen::Vector2d> core_points_uv;
    cv::Mat disparity = voxel_map_->get_disparity();

#ifdef DEBUG_LOG
    cv::Mat draw_dis = disparity.clone();
    if (draw_dis.type() != CV_8U) {
        draw_dis.convertTo(draw_dis, CV_8U, 255 / (32 * 16.));
        cv::cvtColor(draw_dis, draw_dis, CV_GRAY2RGB);
    } else {
        cv::cvtColor(draw_dis, draw_dis, CV_GRAY2RGB);
    }
#endif

    std::queue<Eigen::Vector3d> view_last_two_points;

    for (int k = 1; k < core_points.size(); ++k) {
        Eigen::Vector3d v_pos = voxel_grid_num_2_pos(Eigen::Vector3i(core_points[k].x, core_points[k].y, core_points[k].z));
        Eigen::Vector2d uv = Camera::instance().reproject_3d_point_2_px(v_pos, voxel_map_->get_T_cw());
        Eigen::Vector3d v_pos_c = voxel_map_->get_T_cw() * v_pos;

        core_points_uv.push_back(uv);

        if (uv(0) > 0 && uv(0) < disparity.cols &&
            uv(1) > 0 && uv(1) < disparity.rows) {
            float d = read_disparity(disparity, uv(0), uv(1));
            if (d > 0) {
                float z = Camera::instance().get_depth_from_disparity(d);
                //printf("id: %d, %f %f; %d\n", k, z, v_pos_c(2), (int)core_points.size());
                if (z > v_pos_c(2)) {
                    view_last_two_points.push(v_pos);
                    if (view_last_two_points.size() > 2) {
                        view_last_two_points.pop();
                    }
                    status_no_occlusion[k] = 1;

#ifdef DEBUG_LOG
                    cv::circle(draw_dis, cv::Point(uv(0), uv(1)), 2, cv::Scalar(0, 255, 0), 1);
                    char t[10];
                    sprintf(t, "%d", k);
                    cv::putText(draw_dis, t, cv::Point(uv(0), uv(1)), CV_FONT_HERSHEY_PLAIN, 1, CV_RGB(0,0,250));
#endif
                }
            }
        }
    }

    Eigen::Vector3d cam_pos = voxel_map_->get_T_wc().translation();
    if (core_points.size() == 2) {
        core_points_w.push_back(cam_pos);
        core_points_w.push_back(voxel_grid_num_2_pos(Eigen::Vector3i(core_points[1].x, core_points[1].y, core_points[1].z)));
    } else if (core_points.size() == 3 && status_no_occlusion[2]) {
        if (!status_no_occlusion[1]) {
            core_points_w.push_back(cam_pos);
            core_points_w.push_back(voxel_grid_num_2_pos(Eigen::Vector3i(core_points[2].x, core_points[2].y, core_points[2].z)));
        } else {
            core_points_w.push_back(cam_pos);
            core_points_w.push_back(voxel_grid_num_2_pos(Eigen::Vector3i(core_points[2].x, core_points[2].y, core_points[2].z)));
        }
    } else {
        if (status_no_occlusion[status_no_occlusion.size() - 1]) {
            core_points_w.push_back(cam_pos);
            int size = core_points.size();
            core_points_w.push_back(voxel_grid_num_2_pos(Eigen::Vector3i(core_points[size - 1].x, core_points[size - 1].y, core_points[size - 1].z)));
            printf("many core points, but target can be seen without occlusion\n");
        } else if (view_last_two_points.size() == 0 && !status_no_occlusion[status_no_occlusion.size() - 1]) {
            float depth = collision_detector_->get_mean_depth();
            CollisionStatus status = collision_detector_->get_collision_status();
            printf("%d %f\n", status, depth);
            if (status == COLLISION_EMERGENCY) {
                return core_points_w;
            } else {
                core_points_w.push_back(cam_pos);

                int u = (int)core_points_uv[core_points_uv.size() - 1](0);
                int v = (int)core_points_uv[core_points_uv.size() - 1](1);
                for (int i = u + 1; i < disparity.cols; ++i) {
                    float d = read_disparity(disparity, u, v);
                    if (d > 0) {
                        float z = Camera::instance().get_depth_from_disparity(d);
                        if (z > depth) {
                            Eigen::Vector3d new_p = Camera::instance().reproject_px_2_3d_point(u + 10,
                                                                                               v,
                                                                                               voxel_map_->get_T_wc(),
                                                                                               depth,
                                                                                               Config::map_scale_);
                            core_points_w.push_back(new_p);
                            break;
                        }
                    }
                }

                int size = core_points.size();
                Eigen::Vector3d target_point = voxel_grid_num_2_pos(Eigen::Vector3i(core_points[size - 1].x, core_points[size - 1].y, core_points[size - 1].z));
                core_points_w.push_back(target_point);
            }
        } else {
            Eigen::Vector3d new_p = Eigen::Vector3d::Zero();
            int num = view_last_two_points.size();

            while (!view_last_two_points.empty()) {
                new_p += view_last_two_points.front();
                view_last_two_points.pop();
            }
            new_p /= num;

            int size = core_points.size();
            Eigen::Vector3d target_point = voxel_grid_num_2_pos(Eigen::Vector3i(core_points[size - 1].x, core_points[size - 1].y, core_points[size - 1].z));

            Eigen::Vector3d mov_v = get_point_2_line_v(cam_pos, target_point, new_p).normalized() / 5;
            new_p += Eigen::Vector3d(mov_v(0), mov_v(1), 0);
            //std::cout << "num: " << num << " mov v: " << mov_v << "\n*************\nnew_p: " << new_p << "\n";

#ifdef DEBUG_LOG
            Eigen::Vector2d uv = Camera::instance().reproject_3d_point_2_px(new_p, voxel_map_->get_T_cw());
            cv::circle(draw_dis, cv::Point(uv(0), uv(1)), 2, cv::Scalar(0, 255, 0), 1);
            cv::putText(draw_dis, "new", cv::Point(uv(0), uv(1)), CV_FONT_HERSHEY_PLAIN, 1, CV_RGB(0, 255, 0));
#endif

            core_points_w.push_back(cam_pos);
            core_points_w.push_back(new_p);
            core_points_w.push_back(target_point);
        }
    }

#ifdef DEBUG_LOG
    cv::imshow("uv", draw_dis);
#endif

    return core_points_w;
}

std::vector<Eigen::Vector3d> PathFinder::simplify_grid_path(const std::vector<Eigen::Vector3d> &grid_path,
                                                            int segment_num) {
    std::vector<Eigen::Vector3d> way_points_path;
    if (!voxel_map_) {
        return way_points_path;
    }

    int length = grid_path.size() - 1;
    int per_segment_num = length / segment_num;

    way_points_path.push_back(grid_path[0]);
    for (int i = 1; i < segment_num; ++i) {
        way_points_path.push_back(grid_path[i * per_segment_num]);
    }
    way_points_path.push_back(grid_path[length]);

    // check collision
    for (int k = 0; k < way_points_path.size() - 1; ++k) {
        Eigen::Vector3d start_p = way_points_path[k];
        Eigen::Vector3d end_p = way_points_path[k + 1];

        Eigen::Vector3d dir = (end_p - start_p).normalized();
        float dist = (end_p - start_p).norm();
        for (int i = 1; i < dist * 100 / (VOXEL_SIZE_CM * 1.5) + 1; ++i) {
            Eigen::Vector3d pos = start_p + dir * i * VOXEL_SIZE_CM * 1.5 / 100;

            int voxel_index_in_chunk;
            int chunk_id;
            grid_world_position(pos, voxel_index_in_chunk, chunk_id);

            if (chunk_map_.count(chunk_id) && chunk_map_[chunk_id]->voxels[voxel_index_in_chunk]->is_valid) {
                // 存在碰撞, 拿到该segment轨迹
                std::vector<Eigen::Vector3d> segment_path;
                for (int s = k * per_segment_num; s <= (k + 1) * per_segment_num; ++s) {
                    if (s > length) {
                        break;
                    } else {
                        segment_path.push_back(grid_path[s]);
                    }
                }
                std::vector<Eigen::Vector3d> new_path = simplify_grid_path(segment_path, 2);
                way_points_path.insert(way_points_path.begin() + 1, new_path[1]);
            }
        }
    }

    return way_points_path;
}

}  // namespace PathPlanning
