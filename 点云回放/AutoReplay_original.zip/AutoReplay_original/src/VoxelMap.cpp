//
// Created by ZZ_AI_Team on 18-4-28.
//

#include "../include/ChunkVoxel.h"
#include "../include/Global.h"
#include "../include/VoxelMap.h"
#include "../include/Camera.h"
#include "../include/Config.h"

#include <unistd.h>

#include "../timer.h"

using namespace std;

namespace PathPlanning {


// 互斥锁
inline void LockMutex(bool &mutex, int duration = 2000)
{
    while(mutex)usleep(duration);
    mutex = true;
}
inline void UnlockMutex(bool &mutex)
{
    mutex = false;
}

long unsigned int VoxelMap::chunk_next_id_ = 0;

VoxelMap::VoxelMap(std::string setting_file) {

    PDM.init(60);

    Config::load_param(setting_file);
    Camera::instance();
    map_type_ = (MapType)Config::map_type_;
    reset();
}

VoxelMap::~VoxelMap() {
    std::map<int, Chunk_ptr>::iterator it = chunk_map_.begin(), end = chunk_map_.end();
    while (it != end) {
        it->second->voxels.clear();
        it++;
    }
    chunk_map_.clear();
}

void VoxelMap::reset() {
    curr_angle = Eigen::Vector2d::Zero();
    chunk_map_.clear();
    depth_data_vec_.clear();
    Rt_time_vec_.clear();
}

void VoxelMap::set_map_type(MapType t) {
    map_type_ = t;
}

void VoxelMap::collision_detection() {



}

void VoxelMap::update_voxel_map() {

    static double last_timestamp = 0;

    if(last_timestamp == Synchronized_disparity_angle.timeStamp){

        // 如果同步数据没有更新,返回
        usleep(2000);
        return;
    }

    last_timestamp = Synchronized_disparity_angle.timeStamp;

    // 等待同步数据可用
    LockMutex(SynchronizationLock,1000);

    /*
     * 找到了时间戳匹配的 Pose-Disparity 配对,再进行体素图的更新
     */

    cout<<"----------------------------------------Matched ROVIO time : "<<Synchronized_POSE.timeStamp<<endl;
    cout<<"----------------------------------------Matched Stereo time : "<<Synchronized_disparity_angle.timeStamp<<endl;

    /*
     * 3. 使用匹配数据建图
     */
    Eigen::Matrix3d R_wc = Synchronized_POSE.r;
    Eigen::Vector3d t_wc = Synchronized_POSE.t;
    double t = Synchronized_POSE.timeStamp;

    // 转换点云到飞控坐标系
    Eigen::Quaterniond dq;
    Eigen::Matrix3d dqm;
    dq = Eigen::Quaterniond(0.5, 0.5, 0.5, 0.5);
#ifndef __ARM__
    dq = Eigen::Quaterniond(0.707, 0.707, 0, 0);
#endif
    dqm = dq.matrix();
    R_wc = R_wc*dqm;

    RtTime rt_t;
    rt_t.T_wc = Sophus::SE3d(R_wc, t_wc);
    rt_t.t = t;

    Sophus::SE3d T_cr = get_rotating_camera_pose(Synchronized_disparity_angle.angle);
    T_wc_ = rt_t.T_wc * T_cr;
    T_cw_ = T_wc_.inverse();
    rt_t.T_wc = T_wc_;

    cv::Mat pt_cloud;
    cv::reprojectImageTo3D(Synchronized_disparity_angle.disparity,pt_cloud,Q);

    // 用完同步数据,解锁
    UnlockMutex(SynchronizationLock);


    pt_cloud*=20;

    Eigen::Vector3d forward_point(0,1,7);
    test_target_point = T_wc_ * forward_point;
    test_target_point(2) = t_wc(2);

    /*
     * 栅格化
     */
    view_voxels.clear();
    view_point_cloud.clear();

    int ct =0;
    for (int y = 30; y < pt_cloud.rows*0.8; y+=2) {
        for (int x = 10; x < pt_cloud.cols-10; x += 2) {
            cv::Point3f real_pos = pt_cloud.at<cv::Point3f>(y,x);
            if(real_pos.z<0.1 || real_pos.z>5)continue;

            // 转换坐标系
            Eigen::Vector3d point_3d(real_pos.x,real_pos.y,real_pos.z);
            Eigen::Vector3d point(real_pos.x,real_pos.y,real_pos.z);
            point_3d = T_wc_ * point;

            // 栅格化：直接录入
            grid_world_position(point_3d,chunk_grid_num_,voxel_grid_num_,voxel_index_num_,voxel_index_in_chunk_,chunk_id_);
            update_voxel_map(point_3d,0);

            ct++;
        }
    }

    /*
     * 删除不需要的voxel
     */
//        if (map_type_ == LOCAL_MAP)
    {
        remove_redundant_chunk_voxel();
    }
    /*
     * 线段擦除voxel
     */
    Eigen::Vector3d camera_pos = t_wc;
    for(int i=0;i<view_voxels.size();i++)
    {
        /*
         * 1. 计算从视点发出的最小向量
         * 2. 逐步累加长度，消除线段上所有voxel
         */
        Eigen::Vector3d ray=(view_voxels[i]-camera_pos);
        double vec_norm = (ray.norm());
        Eigen::Vector3d min_vec = (VOXEL_SIZE_M/vec_norm)*(ray);
        Eigen::Vector3d min_vec_delta = (VOXEL_SIZE_M/vec_norm)*(ray);
        for(;min_vec.norm()<vec_norm*0.6;min_vec+=min_vec_delta)
        {
            erase_voxel_at(min_vec+camera_pos);
        }
    }

    /*
     * 更新当前的伪时间戳(fake time stamp)
     */
    chunk_next_id_++;
}


void VoxelMap::renew_disparity_and_angle(cv::Mat &disparity, const double _angle, const double _t) {


    /*
     * 1. 更新深度图+双目旋转角度到环形队列中
     */

    PDM.feed_stereo_data(disparity,_angle,_t);

    /*
     * 2. 找出匹配数据,用于建立体素图
     */

    LockMutex(PDM_Lock,1000);
    P_index = 0;
    I_index = 0;
    bool match_found = PDM.get_matched_data(P_index,I_index);
    UnlockMutex(PDM_Lock);

    if(match_found)
    {
        // 将同步数据更新到 buffer
        LockMutex(SynchronizationLock,1000);

        Synchronized_disparity_angle.disparity=PDM.DRB.da_fifo[PDM.DRB.get_element_index(I_index)].disparity.clone();
        Synchronized_disparity_angle.timeStamp=PDM.DRB.da_fifo[PDM.DRB.get_element_index(I_index)].timeStamp;
        Synchronized_disparity_angle.angle=PDM.DRB.da_fifo[PDM.DRB.get_element_index(I_index)].angle;
        Synchronized_disparity_angle.mark=PDM.DRB.da_fifo[PDM.DRB.get_element_index(I_index)].mark;

        Synchronized_POSE.angle = PDM.PRB.get_element(P_index).angle;
        Synchronized_POSE.t = PDM.PRB.get_element(P_index).t;
        Synchronized_POSE.r = PDM.PRB.get_element(P_index).r;
        Synchronized_POSE.timeStamp = PDM.PRB.get_element(P_index).timeStamp;

        UnlockMutex(SynchronizationLock);
    }

}

void VoxelMap::renew_pose(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t) {

    /*
     * 1. 更新位置姿态数据到环形队列中
     */
    POSE pt;
    pt.r = R_wc;
    pt.t = t_wc;
    pt.timeStamp = t;

    LockMutex(PDM_Lock,1000);
    PDM.feed_pose_data(pt);
    UnlockMutex(PDM_Lock);

    /*
     * 2. 更新最新位置姿态数据,用于碰撞检测等
     */
    RtTime rt_t;
    rt_t.T_wc = Sophus::SE3d(R_wc, t_wc);
    rt_t.t = t;
    curr_T_t_ = rt_t;

}

void VoxelMap::add_angle_T(const Eigen::Vector2d &angle) {
    curr_angle = angle;
}

void VoxelMap::add_disparity_T(const cv::Mat &disparity, const double t) {
    DisparityTime depthData;
    depthData.disparity = disparity;
    depthData.t = t;
    depth_data_vec_.push_back(depthData);
    if (depth_data_vec_.size() > 30) {
        depth_data_vec_.erase(depth_data_vec_.begin());
    }
}

bool VoxelMap::add_pose_T(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t) {

//    return true;

    RtTime rt_t;
    rt_t.T_wc = Sophus::SE3d(R_wc, t_wc);
    rt_t.t = t;
    Rt_time_vec_.push_back(rt_t);

    // 匹配视差图与姿态数据的时间戳
    DisparityTime disparity_data;
    for (int i = 0; i < Rt_time_vec_.size(); ++i) {
        std::vector<DisparityTime>::iterator it = depth_data_vec_.begin();
        while (it != depth_data_vec_.end()) {
            DisparityTime data = *it;
            double t_diff = data.t - Rt_time_vec_[i].t;
            if (t_diff < -0.02) {
                it = depth_data_vec_.erase(it);
            } else if (t_diff > 0.02) {
                it++;
                continue;
            } else {
                disparity_data = data;
                curr_T_t_ = Rt_time_vec_[i];
                depth_data_vec_.erase(it);
                Rt_time_vec_.erase(Rt_time_vec_.begin(), Rt_time_vec_.begin() + i + 1);
                break;
            }
        }
        if (!disparity_data.disparity.empty()) {
            break;
        }
    }

    static bool skip_tag = true;

//    skip_tag = !skip_tag;

    Timer timer;

    // 更新map
    if (skip_tag && !disparity_data.disparity.empty()) {

        Sophus::SE3d T_cr = get_rotating_camera_pose(curr_angle(1));
        T_wc_ = curr_T_t_.T_wc * T_cr;
        T_cw_ = T_wc_.inverse();
        curr_T_t_.T_wc = T_wc_;

        if (map_type_ == SINGLE_MAP) {
            chunk_map_.clear();
        }

#ifdef DEBUG_LOG
        printf("found disparity: dis_t:%f; pose_t:%f; angle_t: %f %f; diff: %f\n", disparity_data.t,
               curr_T_t_.t, curr_angle(0), curr_angle(1) * 180 / M_PI, disparity_data.t - curr_T_t_.t);
#endif

        timer.tic();

        cv::Mat pt_cloud;
        cv::reprojectImageTo3D(disparity_data.disparity,pt_cloud,Q);

        pt_cloud*=20;

        Eigen::Vector3d forward_point(0,1,7);
        test_target_point = T_wc_ * forward_point;

        test_target_point(2) = t_wc(2);

        /*
         * 栅格化
         */
        view_voxels.clear();
        view_point_cloud.clear();

        int ct =0;
        for (int y = 30; y < pt_cloud.rows*0.8; y+=2) {
            for (int x = 10; x < pt_cloud.cols-10; x += 2) {
                cv::Point3f real_pos = pt_cloud.at<cv::Point3f>(y,x);
                if(real_pos.z<0.5 || real_pos.z>5)continue;

                // 转换坐标系
                Eigen::Vector3d point_3d(real_pos.x,real_pos.y,real_pos.z);
                Eigen::Vector3d point(real_pos.x,real_pos.y,real_pos.z);
                point_3d = T_wc_ * point;

                // 栅格化：直接录入
                grid_world_position(point_3d,chunk_grid_num_,voxel_grid_num_,voxel_index_num_,voxel_index_in_chunk_,chunk_id_);
                update_voxel_map(point_3d,0);

                ct++;
            }
        }

        /*
         * 删除不需要的voxel
         */
        if (map_type_ == LOCAL_MAP) {
            remove_redundant_chunk_voxel();
        }
        /*
         * 线段擦除voxel
         */
        Eigen::Vector3d camera_pos = t_wc;
        for(int i=0;i<view_voxels.size();i++)
        {
            /*
             * 1. 计算从视点发出的最小向量
             * 2. 逐步累加长度，消除线段上所有voxel
             */
            Eigen::Vector3d ray=(view_voxels[i]-camera_pos);
            double vec_norm = (ray.norm());
            Eigen::Vector3d min_vec = (VOXEL_SIZE_M/vec_norm)*(ray);
            Eigen::Vector3d min_vec_delta = (VOXEL_SIZE_M/vec_norm)*(ray);
            for(;min_vec.norm()<vec_norm*0.6;min_vec+=min_vec_delta)
            {
                erase_voxel_at(min_vec+camera_pos);
            }
        }

        disparity_map_ = disparity_data.disparity;

        /*
         * 更新当前的伪时间戳(fake time stamp)
         */
        chunk_next_id_++;

        return true;
    } else {
        return false;
    }
}

void VoxelMap::remove_redundant_chunk_voxel() {

    Timer timer;
//    timer.tic();

//    Eigen::Matrix3d R_= T_wc_.rotationMatrix();
//
//    std::cout<<R_<<std::endl;

    Eigen::Vector3d cam_pos = T_wc_.translation();
    Eigen::Vector3d cam_look_dir(0, 0, 1);
    cam_look_dir = (T_wc_.rotationMatrix() * cam_look_dir).normalized();

    int chunk_itor_time = 0;

    std::map<int, Chunk_ptr>::iterator it = chunk_map_.begin();
    while (it != chunk_map_.end()) {

        chunk_itor_time++;

        Chunk_ptr c = it->second;

        /*
         * 1. 清除没有体素的chunk
         */
        if(c->active_voxels<=0){
            chunk_map_.erase(it++);
            continue;
        }
        /*
         * 2. 清除超时的chunk
         */
        if(chunk_next_id_ - c->time_id > Config::voxel_max_life_time_)
        {
            chunk_map_.erase(it++);
            continue;
        }

        Eigen::Vector3d dir_cam_2_chunk = c->chunk_pos - cam_pos;
        double dist = dir_cam_2_chunk.norm();
        float chunk_theta = cam_look_dir.dot(dir_cam_2_chunk.normalized());

        if ((chunk_theta > 0 && dist > Config::front_max_distance_) ||
            (chunk_theta < 0 && dist > Config::back_max_distance_)) {
            // 删除前方6m远外的chunk, 和后方3m外的chunk
            chunk_map_.erase(it++);
        }
        else if (chunk_theta > Config::visable_voxel_theta_) {
            // 检测前方一定角度范围内的chunk里面voxel是否很久没有被更新, 则删除
            for (int i = 0; i < c->voxels.size(); ++i) {

                Voxel_ptr voxel_ptr = c->voxels[i];

                if(!voxel_ptr)continue;

                if (voxel_ptr && voxel_ptr->is_valid &&
                    (chunk_next_id_ - voxel_ptr->time_id) > Config::voxel_max_life_time_) {

                    Eigen::Vector3d dir = voxel_ptr->world_pos - cam_pos;
                    float voxel_theta = cam_look_dir.dot(dir.normalized());

                    if (voxel_theta > Config::visable_voxel_theta_) {
                        // 落在摄像机的视锥里面才进行剔除
                        voxel_ptr->is_valid = false;
                        c->decrease_active_voxels();
                        voxel_ptr->obs = 0;
                    }
                }
            }
            it++;
        }
        else {
            it++;
        }
    }

//    timer.toc("remove_redundant_chunk_voxel ");
}

bool VoxelMap::calc_world_pos(const float disparity_value,
                              const int u, const int v,
                              Eigen::Vector3d &point_3d) {
    if (disparity_value > 0) {
        float z = Camera::instance().get_depth_from_disparity(disparity_value);
        if (z > Config::point_max_distance_) {
            return false;
        }
        point_3d = Camera::instance().reproject_px_2_3d_point(u, v, T_wc_, z, Config::map_scale_);
        return true;
    } else {
        return false;
    }
}

void VoxelMap::update_voxel_map(const Eigen::Vector3d &pos, int level) {
    if (chunk_map_.count(chunk_id_)) {
        Chunk_ptr chunk = chunk_map_[chunk_id_];
        chunk->time_id = chunk_next_id_;
        update_voxel_in_chunk(chunk, pos,level);
    } else {
        Chunk_ptr chunk(new Chunk(chunk_id_, chunk_grid_num_));
        update_voxel_in_chunk(chunk, pos,level);
        chunk->time_id = chunk_next_id_;
        chunk_map_[chunk_id_] = chunk;
    }
}

void VoxelMap::update_voxel_in_chunk(Chunk_ptr chunk, const Eigen::Vector3d &voxel_pos, int level) {

//    return;

    bool cur_grid_valid = false;
    int cur_grid_obs = 0;

    Voxel_ptr voxel_ptr = chunk->voxels[voxel_index_in_chunk_];
    if (voxel_ptr) {
        cur_grid_valid = chunk->voxels[voxel_index_in_chunk_]->is_valid;
        cur_grid_obs = chunk->voxels[voxel_index_in_chunk_]->obs;
    }

    if (!cur_grid_valid && cur_grid_obs < 1) {
        Voxel_ptr v(new Voxel(voxel_pos, chunk->chunk_id, voxel_index_in_chunk_, voxel_grid_num_));
        v->collision_level = level;
        v->time_id = chunk_next_id_;
        chunk->voxels[voxel_index_in_chunk_] = v;
    } else if (!cur_grid_valid && cur_grid_obs > 0) {
        chunk->voxels[voxel_index_in_chunk_]->world_pos = voxel_pos;
        chunk->voxels[voxel_index_in_chunk_]->obs++;
        chunk->voxels[voxel_index_in_chunk_]->time_id = chunk_next_id_;
        if (chunk->voxels[voxel_index_in_chunk_]->obs > VOXEL_OBS_THRESHOLD) {
            chunk->voxels[voxel_index_in_chunk_]->is_valid = true;
            chunk->increase_active_voxels();
        }
    } else if (cur_grid_valid) {
        voxel_ptr->time_id = chunk_next_id_;
    }

    if (voxel_ptr) {
        cur_grid_valid = chunk->voxels[voxel_index_in_chunk_]->is_valid;
        chunk->voxels[voxel_index_in_chunk_]->collision_level = level;

        if(cur_grid_valid && chunk->voxels[voxel_index_in_chunk_]->is_focus == false)
        {
            // 标记为可视体素
            view_voxels.push_back(voxel_pos);
            chunk->voxels[voxel_index_in_chunk_]->is_focus = true;
        }
    }
}

std::vector<Chunk_ptr> VoxelMap::get_chunk_vector() {
    std::vector<Chunk_ptr> chunk_map;
    std::map<int, Chunk_ptr>::iterator it = chunk_map_.begin(), end = chunk_map_.end();
    int chunk_size = 0;
    while (it != end) {
        chunk_map.push_back(it->second);
        it++;
        chunk_size++;
    }

//    cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$ chunk_size 1 $$$$$$$$$$$$$$$$$$$$$$$$$$$"<<chunk_size<<endl;

    return chunk_map;
}

std::vector<Voxel_ptr> VoxelMap::get_voxel_vector() {
    std::vector<Voxel_ptr> voxel_map;
    std::map<int, Chunk_ptr>::iterator it = chunk_map_.begin(), end = chunk_map_.end();
    int chunk_size = 0;

    while (it != end) {
        Chunk_ptr c = it->second;
        for (int i = 0; i < c->voxels.size(); ++i) {
            if (c->voxels[i] && c->voxels[i]->is_valid) {

//                std::shared_ptr<Voxel> vtp (new Voxel());
//                Eigen::Vector3d p;
//                p = chunk_grid_num_2_pos(c->chunk_grid_num);
//                vtp->voxel_grid_num(0)=c->voxels[i]->voxel_grid_num(0);
//                vtp->voxel_grid_num(1)=c->voxels[i]->voxel_grid_num(1);
//                vtp->voxel_grid_num(2)=c->voxels[i]->voxel_grid_num(2);
//                vtp->collision_level = chunk_size;
//                voxel_map.push_back(vtp);

                voxel_map.push_back(c->voxels[i]);
            }
        }
        it++;
        chunk_size++;

    }
//    cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$ chunk_size 2 $$$$$$$$$$$$$$$$$$$$$$$$$$$"<<chunk_size<<endl;

    return voxel_map;
}

void VoxelMap::reset_voxel_level() {
    std::map<int, Chunk_ptr>::iterator it = chunk_map_.begin(), end = chunk_map_.end();
    while (it != end) {
        Chunk_ptr c = it->second;
        for (int i = 0; i < c->voxels.size(); ++i) {
            if (c->voxels[i]) {
                c->voxels[i]->collision_level = 0;
                c->voxels[i]->is_focus = 0;
            }
        }
        it++;
    }
}

bool VoxelMap::has_obstacle(const Eigen::Vector3d &start, const Eigen::Vector3d &end) {
    Eigen::Vector3d diff = end - start;
    Eigen::Vector3d v = diff.normalized();
    double dist = diff.norm();

    for (int i = 1; i < dist / (VOXEL_SIZE_M * 0.7) + 1; ++i) {
        Eigen::Vector3d detect_pos = start + v * i * VOXEL_SIZE_M * 0.7;
        grid_world_position(detect_pos, chunk_grid_num_, voxel_grid_num_,voxel_index_num_, voxel_index_in_chunk_, chunk_id_);
        if (chunk_map_.count(chunk_id_)) {
            Chunk_ptr c = chunk_map_[chunk_id_];
            Voxel_ptr v = c->voxels[voxel_index_in_chunk_];
            if (v && v->is_valid) {
                return true;
            }
        }
    }
    return false;
}

bool VoxelMap::has_obstacle(const Eigen::Vector3d &pos, Eigen::Vector3i &voxel_grid_num) {
    grid_world_position(pos, chunk_grid_num_, voxel_grid_num,voxel_index_num_, voxel_index_in_chunk_, chunk_id_);
    if (chunk_map_.count(chunk_id_)) {
        Chunk_ptr c = chunk_map_[chunk_id_];
        Voxel_ptr v = c->voxels[voxel_index_in_chunk_];
        if (v && v->is_valid) {
            return true;
        }
    }
    return false;
}

bool VoxelMap::has_obstacle(const Eigen::Vector3d &pos) {
    grid_world_position(pos, chunk_grid_num_, voxel_grid_num_,voxel_index_num_, voxel_index_in_chunk_, chunk_id_);
    if (chunk_map_.count(chunk_id_)) {
        Chunk_ptr c = chunk_map_[chunk_id_];
        Voxel_ptr v = c->voxels[voxel_index_in_chunk_];
        if (v && v->is_valid) {
            return true;
        }
    }
    return false;
}

void VoxelMap::erase_voxel_at(const Eigen::Vector3d &pos){
    grid_world_position(pos, chunk_grid_num_, voxel_grid_num_,voxel_index_num_, voxel_index_in_chunk_, chunk_id_);
    if (chunk_map_.count(chunk_id_)) {
        Chunk_ptr c = chunk_map_[chunk_id_];
        Voxel_ptr v = c->voxels[voxel_index_in_chunk_];
        if (v) {
            v->is_valid = false;
            c->decrease_active_voxels();
        }
    }
}

}  // namespace PathPlanning
