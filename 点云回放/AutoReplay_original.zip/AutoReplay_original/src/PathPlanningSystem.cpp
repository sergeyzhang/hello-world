//
// Created by ZZ_AI_Team on 18-5-14.
//

//#include <mav_trajectory_generation/trajectory_sampling.h>
//#include "../include/TrajectoryGenerator.h"
#include "../include/PathPlanningSystem.h"
#include "../include/VoxelMap.h"
#include "../include/CollisionDetector.h"
#include "../include/PathFinder.h"
#include "../include/Camera.h"

#include "../include/GlobalPlanner.h"

namespace PathPlanning {

PathPlanningSystem::PathPlanningSystem() {
    voxel_map_ = NULL;
    collision_detector_ = NULL;
    path_finder_ = new PathFinder(voxel_map_, collision_detector_);

    Scout = new GlobalPlanner();
}

PathPlanningSystem::PathPlanningSystem(const std::string cam_config_file) {
    Config::load_param(cam_config_file);
    Camera::instance();

    if (Config::use_fast_path_finder) {
        fast_path_finder = new FastPathFinder(cam_config_file);
    } else {
        voxel_map_ = new VoxelMap(cam_config_file);
        collision_detector_ = new CollisionDetector(voxel_map_);
        path_finder_ = new PathFinder(voxel_map_, collision_detector_);
    }
    Scout = new GlobalPlanner();
}

PathPlanningSystem::~PathPlanningSystem() {
    delete path_finder_;
    delete collision_detector_;
    delete voxel_map_;
}

void PathPlanningSystem::update_voxel_map() {

    voxel_map_->update_voxel_map();
}

void PathPlanningSystem::renew_disparity_and_angle(cv::Mat &disparity, const double angle, const double t){
    voxel_map_->renew_disparity_and_angle(disparity,angle,t);
}

void PathPlanningSystem::renew_pose(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t){
    voxel_map_->renew_pose(R_wc,t_wc,t);
}


void PathPlanningSystem::add_angle(const Eigen::Vector2d &angle) {
voxel_map_->add_angle_T(angle);
}

void PathPlanningSystem::add_disparity_map(const cv::Mat &disparity, const double t) {
    voxel_map_->add_disparity_T(disparity, t);
}

void PathPlanningSystem::add_disparity_map_for_fast(const cv::Mat &disparity, const double t) {
    fast_path_finder->add_disparity_T(disparity, t);
}

bool PathPlanningSystem::add_pose(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t) {
    if (voxel_map_->add_pose_T(R_wc, t_wc, t)) {
//        collision_detector_->detect_collision();
        return true;
    } else {
        return false;
    }
}

Eigen::Vector3d PathPlanningSystem::add_pose_for_fast(const Eigen::Matrix3d &R_wc, const Eigen::Vector3d &t_wc, const double t) {
    return fast_path_finder->fast_find_safe_core_point(Sophus::SE3d(R_wc, t_wc), t);
}

int PathPlanningSystem::RethinkPath(const Eigen::Vector3d &start_point,
                                    const Eigen::Vector3d &target_point,
                                    std::vector<Eigen::Vector3d> &path) {

    /*
     * 路线进度维护
     */
    Scout->MaintainProgress(start_point, target_point);


    /*
     * 新的路径规划模块
     */
    std::vector<Eigen::Vector3d> essential_way_points;

    essential_way_points = Scout->find_path(start_point,target_point,voxel_map_);



    path.clear();
    for(int i=0;i<essential_way_points.size();i++)
        path.push_back(essential_way_points[i]);

    return path_finder_->get_path_finder_state();
}


void PathPlanningSystem::set_velocity(const Eigen::Vector3d &v_w) {
    collision_detector_->set_velocity(v_w);
}

void PathPlanningSystem::reset_system() {
    voxel_map_->reset();
}

void PathPlanningSystem::get_collision_info(collision_info_t &collision_info) {
    collision_info.collision_status = collision_detector_->get_collision_status();
    collision_info.collision_distance = collision_detector_->get_average_collision_dist();
    collision_info.fast_core_point = collision_detector_->get_core_point();

    collision_info.collision_width = -1;
    collision_info.collision_height = -1;

    collision_info.collision_3d_point = collision_detector_->get_collision_3d_point();

    collision_info.collision_point_depth = path_finder_->get_collision_point_depth();
    if (collision_info.collision_status > 0 && collision_info.collision_point_depth != -1) {
        cv::Rect collision_rect = path_finder_->get_collision_rect();
        if (collision_rect.width != 0 && collision_rect.height !=0) {
            collision_info.collision_width = Camera::instance().get_distance_from_px(collision_rect.width, collision_info.collision_distance);
            collision_info.collision_height = Camera::instance().get_distance_from_px(collision_rect.height, collision_info.collision_distance);
        }
    }

    collision_info.mean_depth = collision_detector_->get_mean_depth();
    collision_detector_->get_dist(collision_info.caution_distance,
                                 collision_info.dangerous_distance,
                                 collision_info.emergency_distance,
                                 collision_info.mov_dir);
}

void PathPlanningSystem::get_fast_path_finder_resultes(int &collision_status, float &collision_depth) {
    collision_status = fast_path_finder->get_collision_status();
    collision_depth = fast_path_finder->get_collision_depth();
}

int PathPlanningSystem::get_collision_detector_result() {
    return collision_detector_->get_collision_status();
}

//void PathPlanningSystem::get_trajectory_result_at_time(const double t,
//                                                       Eigen::Vector3d &position,
//                                                       Eigen::Vector3d &velocity,
//                                                       Eigen::Vector3d &acc) {
//    Trajectory::sample_trajectory_at_time(t, position, velocity, acc);
//}

//void PathPlanningSystem::get_whole_trajectory_result(const double t,
//                                                     std::vector<Eigen::Vector3d> &position,
//                                                     std::vector<double> &segment_times,
//                                                     double &max_time,
//                                                     double &min_time,
//                                                     double &max_velocity) {
//    position.clear();
//
//    mav_trajectory_generation::Trajectory trajectory = Trajectory::trajectory_;
//    max_time = trajectory.getMaxTime();
//    min_time = trajectory.getMinTime();
//
//    max_velocity = -1;
//    mav_msgs::EigenTrajectoryPoint::Vector flat_states;
//    mav_trajectory_generation::sampleWholeTrajectory(trajectory, t, &flat_states);
//    for (int i = 0; i < flat_states.size(); ++i) {
//        position.push_back(flat_states[i].position_W);
//        if (flat_states[i].velocity_W.norm() > max_velocity) {
//            max_velocity = flat_states[i].velocity_W.norm();
//        }
//    }
//
//    segment_times.clear();
//    for (int k = 0; k < Trajectory::segments_.size(); ++k) {
//        segment_times.push_back(Trajectory::segments_[k].getTime());
//    }
//}

bool PathPlanningSystem::has_obstacle_at_pos(const Eigen::Vector3d &position) {
    Eigen::Vector3i voxel_grid_num;
    return voxel_map_->has_obstacle(position, voxel_grid_num);
}

}  // namespace PathPlanning
