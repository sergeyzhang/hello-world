//
// Created by ZZ_AI_Team on 7/23/18.
//

#include "../include/FastPathFinder.h"
#include "../include/Config.h"
#include "../include/Camera.h"

namespace PathPlanning {

FastPathFinder::FastPathFinder() {
    init();
}

FastPathFinder::FastPathFinder(std::string setting_file) {
    Config::load_param(setting_file);
    Camera::instance();

    init();
}

void FastPathFinder::init() {
    caution_points_c.push_back(Eigen::Vector3d(Config::safe_radii_, 0, Config::init_caution_distance_));
    caution_points_c.push_back(Eigen::Vector3d(-Config::safe_radii_, 0, Config::init_caution_distance_));
    caution_points_c.push_back(Eigen::Vector3d(0, Config::safe_radii_, Config::init_caution_distance_));
    caution_points_c.push_back(Eigen::Vector3d(0, -Config::safe_radii_, Config::init_caution_distance_));

    dangerous_points_c.push_back(Eigen::Vector3d(Config::safe_radii_, 0, Config::init_dangerous_distance_));
    dangerous_points_c.push_back(Eigen::Vector3d(-Config::safe_radii_, 0, Config::init_dangerous_distance_));
    dangerous_points_c.push_back(Eigen::Vector3d(0, Config::safe_radii_, Config::init_dangerous_distance_));
    dangerous_points_c.push_back(Eigen::Vector3d(0, -Config::safe_radii_, Config::init_dangerous_distance_));

    emergency_points_c.push_back(Eigen::Vector3d(Config::safe_radii_, 0, Config::init_emergency_distance_));
    emergency_points_c.push_back(Eigen::Vector3d(-Config::safe_radii_, 0, Config::init_emergency_distance_));
    emergency_points_c.push_back(Eigen::Vector3d(0, Config::safe_radii_, Config::init_emergency_distance_));
    emergency_points_c.push_back(Eigen::Vector3d(0, -Config::safe_radii_, Config::init_emergency_distance_));

    for (int i = 0; i < caution_points_c.size(); ++i) {
        base_caution_points_uv.push_back(Camera::instance().reproject_3d_point_2_px(caution_points_c[i]));
    }

    for (int i = 0; i < dangerous_points_c.size(); ++i) {
        base_dangerous_points_uv.push_back(Camera::instance().reproject_3d_point_2_px(dangerous_points_c[i]));
    }

    for (int i = 0; i < emergency_points_c.size(); ++i) {
        base_emergency_points_uv.push_back(Camera::instance().reproject_3d_point_2_px(emergency_points_c[i]));
    }
}

void FastPathFinder::add_disparity_T(const cv::Mat &disparity, const double t) {
    DisparityTime depthData;
    depthData.disparity = disparity;
    depthData.t = t;
    depth_data_vec_.push_back(depthData);
    if (depth_data_vec_.size() > 10) {
        depth_data_vec_.erase(depth_data_vec_.begin());
    }
}

Eigen::Vector3d FastPathFinder::fast_find_safe_core_point(const Sophus::SE3d &T_wc, const double timestamp) {
    RtTime rt_t;
    rt_t.T_wc = T_wc;
    rt_t.t = timestamp;
    Rt_time_vec_.push_back(rt_t);

    // 匹配视差图与姿态数据的时间戳
    DisparityTime disparity_data;
    for (int i = 0; i < Rt_time_vec_.size(); ++i) {
        std::vector<DisparityTime>::iterator it = depth_data_vec_.begin();
        while (it != depth_data_vec_.end()) {
            DisparityTime data = *it;
            double t_diff = data.t - Rt_time_vec_[i].t;
            if (t_diff < -0.02) {
                it = depth_data_vec_.erase(it);
            } else if (t_diff > 0.02) {
                it++;
                continue;
            } else {
                disparity_data = data;
                curr_T_t_ = Rt_time_vec_[i];
                depth_data_vec_.erase(it);
                Rt_time_vec_.erase(Rt_time_vec_.begin(), Rt_time_vec_.begin() + i + 1);
                break;
            }
        }
        if (!disparity_data.disparity.empty()) {
            break;
        }
    }
    if (disparity_data.disparity.empty()) {
        return Eigen::Vector3d::Zero();
    }

    T_wc_ = curr_T_t_.T_wc;
    T_cw_ = T_wc_.inverse();

    printf("0********fast*****************0\n");
    caution_points_depth.clear();
    dangerous_points_depth.clear();
    emergency_points_depth.clear();

    caution_points_uv.clear();
    dangerous_points_uv.clear();
    emergency_points_uv.clear();

    collision_depth = -1;
    collision_uv = Eigen::Vector2d(-1, -1);
    collision_rect = cv::Rect(0, 0, 0, 0);
    safe_rect = cv::Rect(0, 0, 0, 0);

    Eigen::Vector3d dir = T_wc_.rotationMatrix() * Eigen::Vector3d(0, 0, 1);
    if (Config::is_fc_ned_) {
        dir(2) = 0;
    } else {
        dir(1) = 0;
    }
    dir = dir.normalized();
    look_dir = dir;

    centre_uv = Camera::instance().reproject_3d_point_2_px(T_wc_.translation() + dir, T_cw_);
    centre_depth = Camera::instance().get_depth_from_disparity(read_disparity(disparity_data.disparity, centre_uv(0), centre_uv(1)));

    Eigen::Vector2d dxy(centre_uv(0) - Config::cx_, centre_uv(1) - Config::cy_);
    for (int i = 0; i < 4; ++i) {
        caution_points_uv.push_back(base_caution_points_uv[i] + dxy);
        caution_points_depth.push_back(Camera::instance().get_depth_from_disparity(read_disparity(disparity_data.disparity,
                                                                                                  caution_points_uv[i](0),
                                                                                                  caution_points_uv[i](1))));
        dangerous_points_uv.push_back(base_dangerous_points_uv[i] + dxy);
        dangerous_points_depth.push_back(Camera::instance().get_depth_from_disparity(read_disparity(disparity_data.disparity,
                                                                                                    dangerous_points_uv[i](0),
                                                                                                    dangerous_points_uv[i](1))));
        emergency_points_uv.push_back(base_emergency_points_uv[i] + dxy);
        emergency_points_depth.push_back(Camera::instance().get_depth_from_disparity(read_disparity(disparity_data.disparity,
                                                                                                    emergency_points_uv[i](0),
                                                                                                    emergency_points_uv[i](1))));
    }

    get_collision_status(collision_uv, collision_depth);

    Eigen::Vector3d core_point;
    Eigen::Vector2d core_uv;

    bool found_safe_core_point = false;

    float disparity_value = Config::baseline_f_ / (collision_depth + 0.5);
    if (collisionStatus > 0) {
        collision_rect = get_collision_rect(disparity_data.disparity, collision_uv, disparity_value);
        PathDirection direction = check_path_direction(collision_uv, collision_rect);
        core_point = get_new_core_point_from_direction(direction, collision_uv);
        core_uv = Camera::instance().reproject_3d_point_2_px(core_point, T_cw_);

        if (!check_core_point_valid(disparity_data.disparity, core_point, core_uv, disparity_value, direction)) {
            // 如果默认优先的方向不合适, 遍历检测其他方向是否可以用于避障
            for (int k = 0; k < 2; ++k) {
                if (k != direction) {
                    printf("fast search dir %d\n", k);
                    core_point = get_new_core_point_from_direction((PathDirection)k, collision_uv);
                    core_uv = Camera::instance().reproject_3d_point_2_px(core_point, T_cw_);
                    if (check_core_point_valid(disparity_data.disparity, core_point, core_uv, disparity_value, (PathDirection)k)) {
                        found_safe_core_point = true;
                        break;
                    }
                } else {
                    printf("init fast search dir %d\n", k);
                }
            }
        } else {
            found_safe_core_point = true;
        }
    }

    if (collisionStatus == COLLISION_SAFE && check_poor_disparity(disparity_data.disparity)) {
        collisionStatus = COLLISION_POOR_DISPARITY;
    }

#ifdef DEBUG_LOG
    cv::Mat dis_8u;
    disparity_data.disparity.convertTo(dis_8u, CV_8U, 255 / (32 * 16.));
    cv::cvtColor(dis_8u, dis_8u, CV_GRAY2BGR);

    cv::circle(dis_8u, cv::Point(centre_uv[0], centre_uv[1]), 2, cv::Scalar(255, 255, 255), 2);
    for (int k = 0; k < caution_points_uv.size(); ++k) {
        cv::circle(dis_8u, cv::Point(caution_points_uv[k][0], caution_points_uv[k][1]), 2, cv::Scalar(0, 255, 0), 2);
        cv::circle(dis_8u, cv::Point(dangerous_points_uv[k][0], dangerous_points_uv[k][1]), 2, cv::Scalar(255, 255, 0), 2);
        cv::circle(dis_8u, cv::Point(emergency_points_uv[k][0], emergency_points_uv[k][1]), 2, cv::Scalar(0, 0, 255), 2);

        char num[50];
        sprintf(num, "depth: %.3f -> %d", collision_depth, collisionStatus);
        cv::putText(dis_8u, num, cv::Point(10, 20), CV_FONT_HERSHEY_PLAIN, 1, CV_RGB(0, 250, 250));
    }
    if (collision_rect.x != 0) {
        cv::rectangle(dis_8u, collision_rect, cv::Scalar(0, 0, 255));
    }
    if (safe_rect.x != 0 && found_safe_core_point) {
        cv::rectangle(dis_8u, safe_rect, cv::Scalar(0, 255, 255));
    }

    if (collision_uv != Eigen::Vector2d::Zero() && found_safe_core_point) {
        cv::circle(dis_8u, cv::Point(collision_uv[0], collision_uv[1]), 2, cv::Scalar(255, 0, 255), 2);
        cv::circle(dis_8u, cv::Point(core_uv[0], core_uv[1]), 2, cv::Scalar(0, 255, 255), 2);
    }
    cv::imshow("fast_find_path_method", dis_8u);

    printf("1********fast*****************1\n");
    if (collision_rect.width > 200) {
        cv::waitKey(0);
    }
#endif

    if (found_safe_core_point) {
        return core_point;
    } else {
        return Eigen::Vector3d::Zero();
    }
}

Eigen::Vector3d FastPathFinder::fast_find_safe_core_point(const cv::Mat &disparity, const Sophus::SE3d &T_wc) {
    T_wc_ = T_wc;
    T_cw_ = T_wc.inverse();

    printf("0********fast*****************0\n");
    caution_points_depth.clear();
    dangerous_points_depth.clear();
    emergency_points_depth.clear();

    caution_points_uv.clear();
    dangerous_points_uv.clear();
    emergency_points_uv.clear();

    collision_depth = -1;
    collision_uv = Eigen::Vector2d(-1, -1);
    collision_rect = cv::Rect(0, 0, 0, 0);
    safe_rect = cv::Rect(0, 0, 0, 0);

    Eigen::Vector3d dir = T_wc_.rotationMatrix() * Eigen::Vector3d(0, 0, 1);
    if (Config::is_fc_ned_) {
        dir(2) = 0;
    } else {
        dir(1) = 0;
    }
    dir = dir.normalized();
    look_dir = dir;

    centre_uv = Camera::instance().reproject_3d_point_2_px(T_wc_.translation() + dir, T_cw_);
    centre_depth = Camera::instance().get_depth_from_disparity(read_disparity(disparity, centre_uv(0), centre_uv(1)));

    Eigen::Vector2d dxy(centre_uv(0) - Config::cx_, centre_uv(1) - Config::cy_);
    for (int i = 0; i < 4; ++i) {
        caution_points_uv.push_back(base_caution_points_uv[i] + dxy);
        caution_points_depth.push_back(Camera::instance().get_depth_from_disparity(read_disparity(disparity,
                                                                                                  caution_points_uv[i](0),
                                                                                                  caution_points_uv[i](1))));
        dangerous_points_uv.push_back(base_dangerous_points_uv[i] + dxy);
        dangerous_points_depth.push_back(Camera::instance().get_depth_from_disparity(read_disparity(disparity,
                                                                                                    dangerous_points_uv[i](0),
                                                                                                    dangerous_points_uv[i](1))));
        emergency_points_uv.push_back(base_emergency_points_uv[i] + dxy);
        emergency_points_depth.push_back(Camera::instance().get_depth_from_disparity(read_disparity(disparity,
                                                                                                    emergency_points_uv[i](0),
                                                                                                    emergency_points_uv[i](1))));
    }

    get_collision_status(collision_uv, collision_depth);

    Eigen::Vector3d core_point(0, 0, 0);
    Eigen::Vector2d core_uv(0, 0);

    bool found_safe_core_point = false;

    float disparity_value = Config::baseline_f_ / (collision_depth + 0.5);
    if (collisionStatus > 0) {
        collision_rect = get_collision_rect(disparity, collision_uv, disparity_value);
        PathDirection direction = check_path_direction(collision_uv, collision_rect);
        core_point = get_new_core_point_from_direction(direction, collision_uv);
        core_uv = Camera::instance().reproject_3d_point_2_px(core_point, T_cw_);

        if (!check_core_point_valid(disparity, core_point, core_uv, disparity_value, direction)) {
            // 如果默认优先的方向不合适, 遍历检测其他方向是否可以用于避障
            for (int k = 0; k < 2; ++k) {
                if (k != direction) {
                    printf("fast search dir %d\n", k);
                    core_point = get_new_core_point_from_direction((PathDirection)k, collision_uv);
                    core_uv = Camera::instance().reproject_3d_point_2_px(core_point, T_cw_);
                    if (check_core_point_valid(disparity, core_point, core_uv, disparity_value, (PathDirection)k)) {
                        found_safe_core_point = true;
                        break;
                    }
                } else {
                    printf("init fast search dir %d\n", k);
                }
            }
        } else {
            found_safe_core_point = true;
        }
    }

//    if (collisionStatus == COLLISION_SAFE && check_poor_disparity(disparity)) {
//        collisionStatus = COLLISION_POOR_DISPARITY;
//    }

#ifdef DEBUG_LOG
    cv::Mat dis_8u;
    disparity.convertTo(dis_8u, CV_8U, 255 / (32 * 16.));
    cv::cvtColor(dis_8u, dis_8u, CV_GRAY2BGR);

    cv::circle(dis_8u, cv::Point(centre_uv[0], centre_uv[1]), 2, cv::Scalar(255, 255, 255), 2);
    for (int k = 0; k < caution_points_uv.size(); ++k) {
        cv::circle(dis_8u, cv::Point(caution_points_uv[k][0], caution_points_uv[k][1]), 2, cv::Scalar(0, 255, 0), 2);
        cv::circle(dis_8u, cv::Point(dangerous_points_uv[k][0], dangerous_points_uv[k][1]), 2, cv::Scalar(255, 255, 0), 2);
        cv::circle(dis_8u, cv::Point(emergency_points_uv[k][0], emergency_points_uv[k][1]), 2, cv::Scalar(0, 0, 255), 2);

        char num[50];
        sprintf(num, "depth: %.3f -> %d", collision_depth, collisionStatus);
        cv::putText(dis_8u, num, cv::Point(10, 20), CV_FONT_HERSHEY_PLAIN, 1, CV_RGB(0, 250, 250));
    }
    if (collision_rect.x != 0) {
        cv::rectangle(dis_8u, collision_rect, cv::Scalar(0, 0, 255));
    }
    if (safe_rect.x != 0 && found_safe_core_point) {
        cv::rectangle(dis_8u, safe_rect, cv::Scalar(0, 255, 255));
    }

    if (collision_uv != Eigen::Vector2d::Zero() && found_safe_core_point) {
        cv::circle(dis_8u, cv::Point(collision_uv[0], collision_uv[1]), 2, cv::Scalar(255, 0, 255), 2);
        cv::circle(dis_8u, cv::Point(core_uv[0], core_uv[1]), 2, cv::Scalar(0, 255, 255), 2);
    }
    cv::imshow("fast_find_path_method", dis_8u);

    printf("1********fast*****************1\n");
    if (collisionStatus == COLLISION_POOR_DISPARITY) {
        cv::waitKey(0);
    }
#endif

    if (found_safe_core_point) {
        return core_point;
    } else {
        return Eigen::Vector3d::Zero();
    }
}

void FastPathFinder::get_collision_status(Eigen::Vector2d &collision_uv, float &collision_depth) {
    collisionStatus = check_depth_status(centre_depth);
    if (collisionStatus == COLLISION_SAFE) {
        CollisionStatus caution_status = COLLISION_SAFE;
        Eigen::Vector2d caution_collision_uv(0, 0);
        float caution_depth;
        for (int i = 0; i < caution_points_depth.size(); ++i) {
            CollisionStatus status = check_depth_status(caution_points_depth[i]);
            if (status > caution_status) {
                caution_status = status;
                caution_collision_uv = caution_points_uv[i];
                caution_depth = caution_points_depth[i];
                printf("caution %d %f; %d\n", status, caution_points_depth[i], i);
            }
        }

        CollisionStatus dangerous_status = COLLISION_SAFE;
        Eigen::Vector2d dangerous_collision_uv(0, 0);
        float dangerous_depth;
        for (int i = 0; i < dangerous_points_depth.size(); ++i) {
            CollisionStatus status = check_depth_status(dangerous_points_depth[i]);
            if (status > dangerous_status) {
                dangerous_status = status;
                dangerous_collision_uv = dangerous_points_uv[i];
                dangerous_depth = dangerous_points_depth[i];
                printf("dangerous %d %f; %d\n", status, dangerous_points_depth[i], i);
            }
        }

        CollisionStatus emergency_status = COLLISION_SAFE;
        Eigen::Vector2d emergency_collision_uv(0, 0);
        float emergency_depth;
        for (int i = 0; i < emergency_points_depth.size(); ++i) {
            CollisionStatus status = check_depth_status(emergency_points_depth[i]);
            if (status > emergency_status) {
                emergency_status = status;
                emergency_collision_uv = emergency_points_uv[i];
                emergency_depth = emergency_points_depth[i];
                printf("emergency %d %f; %d\n", status, emergency_points_depth[i], i);
            }
        }

        if (caution_status >= dangerous_status && caution_status >= emergency_status) {
            collisionStatus = caution_status;
            collision_uv = caution_collision_uv;
            collision_depth = caution_depth;
        } else if (dangerous_status >= caution_status && dangerous_status >= emergency_status) {
            collisionStatus = dangerous_status;
            collision_uv = dangerous_collision_uv;
            collision_depth = dangerous_depth;
        } else if (emergency_status >= caution_status && emergency_status >= dangerous_status) {
            collisionStatus = emergency_status;
            collision_uv = emergency_collision_uv;
            collision_depth = emergency_depth;
        }

        float r_u = Camera::instance().get_distance_from_px(fabs(collision_uv(0) - centre_uv(0)), collision_depth);
        float r_v = Camera::instance().get_distance_from_px(fabs(collision_uv(1) - centre_uv(1)), collision_depth);

        printf("%d %d %d; %d; ru: %f uv: %f; depth: %f\n", caution_status, dangerous_status, emergency_status, collisionStatus, r_u, r_v, collision_depth);

        if (r_u > Config::safe_radii_ || r_v > Config::safe_radii_) {
            collisionStatus = COLLISION_SAFE;
            collision_depth = -1;
            collision_uv = Eigen::Vector2d::Zero();
        }
    } else {
        collision_uv = centre_uv;
        collision_depth = centre_depth;
    }
}

CollisionStatus FastPathFinder::check_depth_status(const float depth) {
    if (depth <= 0) {
        return CollisionStatus::COLLISION_SAFE;
    } else if (depth < Config::init_emergency_distance_) {
        return CollisionStatus::COLLISION_EMERGENCY;
    } else if (depth < Config::init_dangerous_distance_) {
        return CollisionStatus::COLLISION_DANGEROUS;
    } else if (depth < Config::init_caution_distance_) {
        return CollisionStatus::COLLISION_CAUTION;
    } else {
        return CollisionStatus::COLLISION_SAFE;
    }
}

cv::Rect FastPathFinder::get_collision_rect(const cv::Mat &disparity, const Eigen::Vector2d &uv_collision, const float disparity_value) {
    // 找到碰撞点左右上下最大的点
    int left_p = 32, right_p = disparity.cols, up_p = 0, down_p = disparity.rows;

    // left
    for (int i = uv_collision(0); i > 32; --i) {
        float d = read_disparity(disparity, i, (int)uv_collision(1));
        if (d < disparity_value && d > 0) {
            left_p = i;
            break;
        }
    }

    // right
    for (int i = uv_collision(0); i < disparity.cols; ++i) {
        float d = read_disparity(disparity, i, (int)uv_collision(1));
        if (d < disparity_value && d > 0) {
            right_p = i;
            break;
        }
    }

    int new_u = (left_p + right_p) / 2;

    // up
    for (int i = uv_collision(1); i > 0; --i) {
        float d = read_disparity(disparity, new_u, i);
        if (d < disparity_value && d > 0) {
            up_p = i;
            break;
        }
    }

    // down
    for (int i = uv_collision(1); i < disparity.rows; ++i) {
        float d = read_disparity(disparity, new_u, i);
        if (d < disparity_value && d > 0) {
            down_p = i;
            break;
        }
    }

    return cv::Rect(cv::Point(left_p, up_p), cv::Point(right_p, down_p));
}

cv::Rect FastPathFinder::get_safe_rect(const cv::Mat &disparity, const Eigen::Vector2d &uv_collision,
                                       const float disparity_value) {
    // 找到碰撞点左右上下最大的点
    int left_p = 32, right_p = disparity.cols, up_p = 0, down_p = disparity.rows;

    // left
    for (int i = uv_collision(0); i > 32; --i) {
        float d = read_disparity(disparity, i, (int)uv_collision(1));
        if (d > disparity_value) {
            left_p = i;
            break;
        }
    }

    // right
    for (int i = uv_collision(0); i < disparity.cols; ++i) {
        float d = read_disparity(disparity, i, (int)uv_collision(1));
        if (d > disparity_value) {
            right_p = i;
            break;
        }
    }

    int new_u = (left_p + right_p) / 2;

    // up
    for (int i = uv_collision(1); i > 0; --i) {
        float d = read_disparity(disparity, new_u, i);
        if (d > disparity_value) {
            up_p = i;
            break;
        }
    }

    // down
    for (int i = uv_collision(1); i < disparity.rows; ++i) {
        float d = read_disparity(disparity, new_u, i);
        if (d > disparity_value) {
            down_p = i;
            break;
        }
    }

    return cv::Rect(cv::Point(left_p, up_p), cv::Point(right_p, down_p));
}

PathDirection FastPathFinder::check_path_direction(const Eigen::Vector2d &core_uv, const cv::Rect &collision_rect) {
    double left = collision_rect.x;
    double right = collision_rect.x + collision_rect.width;
    double up = collision_rect.y;
    double down = collision_rect.y + collision_rect.height;

    // 先检测上下, 再检测左右
    if (core_uv(1) < up || core_uv(1) > down) {
        // up down
        double up_dist = fabs(up - core_uv(1));
        double down_dist = fabs(down - core_uv(1));
        if (up_dist < down_dist) {
            return GO_UP;
        } else {
            return GO_DOWN;
        }
    } else {
        // left right
        double left_dist = fabs(left - core_uv(0));
        double right_dist = fabs(right - core_uv(0));
        if (left_dist < right_dist) {
            return GO_LEFT;
        } else {
            return GO_RIGHT;
        }
    }
}

Eigen::Vector3d FastPathFinder::get_new_core_point_from_direction(const PathPlanning::PathDirection direction,
                                                                  const Eigen::Vector2d &collision_uv) {
    // 根据关键点在碰撞方框的方位, 从新生成更加稳定的关键点
    Eigen::Vector3d core_point;
    float px = -1;
    switch (direction) {
        case GO_LEFT:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, collision_depth);
            core_point = Camera::instance().reproject_px_2_3d_point(collision_rect.x - px, (int)collision_uv(1),
                                                                    T_wc_, collision_depth);
            break;
        case GO_RIGHT:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, collision_depth);
            core_point = Camera::instance().reproject_px_2_3d_point(collision_rect.x + collision_rect.width + px, (int)collision_uv(1),
                                                                    T_wc_, collision_depth);
            break;
        case GO_UP:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, collision_depth);
            core_point = Camera::instance().reproject_px_2_3d_point((int)collision_uv(0), collision_rect.y - px,
                                                                    T_wc_, collision_depth);
            break;
        case GO_DOWN:
            px = Camera::instance().get_px_from_distance(Config::safe_offset_distance_, collision_depth);
            core_point = Camera::instance().reproject_px_2_3d_point((int)collision_uv(0), collision_rect.y + collision_rect.height + px,
                                                                    T_wc_, collision_depth);
            break;
    }
    return core_point;
}

bool FastPathFinder::check_core_point_valid(const cv::Mat &disparity, const Eigen::Vector3d &core_point,
                                            const Eigen::Vector2d &core_uv, const float disparity_value,
                                            const PathDirection &direction) {
    // 如果关键点不能投影到图像上，或者距离碰撞体过远，说明前方障碍物不适合路径规划
    if (core_uv(0) < 32 || core_uv(1) < 0 ||
        core_uv(0) > Config::img_width_ - 3 ||
        core_uv(1) > Config::img_height_ - 3) {
        printf("reprojection uv out of bound; (%f %f) \n", core_uv(0), core_uv(1));
        return false;
    }

    Eigen::Vector3d end_point = core_point + look_dir;
    Eigen::Vector2d end_point_uv = Camera::instance().reproject_3d_point_2_px(end_point, T_cw_);
    float d = read_disparity(disparity, end_point_uv(0), end_point_uv(1));
    if (d <= 0 || Camera::instance().get_depth_from_disparity(d) < collision_depth * 1.5) {
        printf("end point d: %f \n", d);
        return false;
    }

    safe_rect = get_safe_rect(disparity, core_uv, disparity_value);
    printf("safe width %f\n", Camera::instance().get_distance_from_px(safe_rect.width, collision_depth));
    if (direction == GO_LEFT) {
        if (safe_rect.x > 32) {
            float width = Camera::instance().get_distance_from_px(fabs(safe_rect.x - core_uv(0)), collision_depth);
            if (width < Config::safe_radii_) {
                printf("left not safe, only has %f m\n", width);
                return false;
            } else {
                printf("left safe distance %f m\n", width);
            }
        } else {
            printf("on the left edge\n");
        }
    } else if (direction == GO_RIGHT) {
        if ((safe_rect.x + safe_rect.width) < Config::img_width_ - 3) {
            float width = Camera::instance().get_distance_from_px(fabs(safe_rect.x + safe_rect.width - core_uv(0)), collision_depth);
            if (width < Config::safe_radii_) {
                printf("right not safe, only has %f m\n", width);
                return false;
            } else {
                printf("right safe distance %f m\n", width);
            }
        } else {
            printf("on the right edge\n");
        }
    }

    if (check_disparity_valid(disparity, disparity_value, core_uv)) {
        printf("check disparity invalid\n");
        return false;
    }
    return true;
}

bool FastPathFinder::check_disparity_valid(const cv::Mat &disparity, const float disparity_value,
                                           const Eigen::Vector2d &uv) {
    int invalid_num = 0;
    for (int i = -2; i < 3; ++i) {
        for (int j = -2; j < 3; ++j) {
            float d = read_disparity(disparity, (int)(uv(0) + i), (int)(uv(1) + j));
            if (d <= 0 || d > disparity_value) {
                invalid_num++;
            }
        }
    }

    if (invalid_num > 10) {
        return true;
    } else {
        return false;
    }
}

bool FastPathFinder::check_poor_disparity(const cv::Mat &disparity) {
    int c1 = centre_uv(0) - 20, c2 = centre_uv(0) + 20;
    int r1 = centre_uv(0) - 10, r2 = centre_uv(0) + 10;
    printf("check_poor_disparity %d %d %d %d\n", c1, c2, r1, r2);
    cv::Mat disparity_rect = disparity.colRange(c1, c2)
                                      .rowRange(r1, r2);

    float rect_size = disparity_rect.rows * disparity_rect.cols;
    int poor_num = 0;
    for (int v = 0; v < disparity_rect.rows; ++v) {
        for (int u = 0; u < disparity_rect.cols; ++u) {
            float d = read_disparity(disparity_rect, u, v);
            if (d <= 0) {
                poor_num++;
            }
        }
    }

    float ratio = poor_num / rect_size;
    printf("poor dis ratio %f; %d %d\n", ratio, poor_num, (int)rect_size);
    if (ratio > 0.4) {
        return true;
    } else {
        return false;
    }
}

}