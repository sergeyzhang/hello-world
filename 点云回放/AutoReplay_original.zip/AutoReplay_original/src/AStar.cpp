//
// Created by ZZ_AI_Team on 18-5-14.
//

#include "../include/AStar.h"

//#define FC_NED

namespace PathPlanning {

std::array<Grid2DLocation, 4> Square2DGrid::DIRS_4 = {
        Grid2DLocation{1, 0},
        Grid2DLocation{-1, 0},
        Grid2DLocation{0, 1},
        Grid2DLocation{0, -1},
};

std::array<Grid2DLocation, 8> Square2DGrid::DIRS_8 = {
        Grid2DLocation{1, 0},
        Grid2DLocation{-1, 0},
        Grid2DLocation{0, 1},
        Grid2DLocation{0, -1},
        Grid2DLocation{1, 1},
        Grid2DLocation{1, -1},
        Grid2DLocation{-1, 1},
        Grid2DLocation{-1, -1},
};

std::array<Grid3DLocation, 10> Square3DGrid::DIRS = {
#ifdef FC_NED
        Grid3DLocation{1, 1, 0},
        Grid3DLocation{1, -1, 0},
        Grid3DLocation{-1, 1, 0},
        Grid3DLocation{-1, -1, 0},
#else
        Grid3DLocation{1, 0, 1},
        Grid3DLocation{1, 0, -1},
        Grid3DLocation{-1, 0, 1},
        Grid3DLocation{-1, 0, -1},
#endif
        Grid3DLocation{1, 0, 0},
        Grid3DLocation{-1, 0, 0},
        Grid3DLocation{0, 1, 0},
        Grid3DLocation{0, -1, 0},
        Grid3DLocation{0, 0, 1},
        Grid3DLocation{0, 0, -1}
};

}  // namespace PathPlanning
