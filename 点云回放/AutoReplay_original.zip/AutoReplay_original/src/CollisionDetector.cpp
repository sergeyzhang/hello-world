//
// Created by ZZ_AI_Team on 18-4-29.
//

#include "../include/Global.h"
#include "../include/CollisionDetector.h"
#include "../include/Camera.h"

#define USE_CAMERA_DIR

namespace PathPlanning {

CollisionDetector::CollisionDetector(VoxelMap *voxel_map) {
    voxel_map_ = voxel_map;
    last_timestamp_ = 0;
    has_velocity_value_ = false;
    velocity_queue_sum_ = Eigen::Vector3d::Zero();

    emergency_disparity_value_ = Config::baseline_f_ / Config::init_dangerous_distance_;
    caution_disparity_value_ = Config::baseline_f_ / Config::init_caution_distance_;
}

void CollisionDetector::set_velocity(const Eigen::Vector3d &velocity_w) {
    velocity_w_ = velocity_w;
    has_velocity_value_ = true;
}

CollisionStatus CollisionDetector::detect_collision() {
    std::map<int, Chunk_ptr> map = voxel_map_->get_chunk_map();
    RtTime curr_T_t = voxel_map_->get_curr_T_t();

    const Eigen::Matrix3d R_wc = curr_T_t.T_wc.rotationMatrix();
    const Eigen::Vector3d cam_pos = curr_T_t.T_wc.translation();
    double timestamp = curr_T_t.t;

    // 统计速度
    if (has_velocity_value_) {
        has_velocity_value_ = false;
        v_queue_.push(velocity_w_);
        velocity_queue_sum_ += velocity_w_;
    } else {
        if (last_timestamp_ != 0 && timestamp != last_timestamp_) {
            Eigen::Vector3d v = (cam_pos - last_pos_) / (timestamp - last_timestamp_);
            v_queue_.push(v);
            velocity_queue_sum_ += v;
        }
        last_pos_ = cam_pos;
        last_timestamp_ = timestamp;
    }

    // 计算一个平均速度
    avg_v_w = velocity_queue_sum_ / v_queue_.size();
    if (v_queue_.size() > 5) {
        velocity_queue_sum_ -= v_queue_.front();
        v_queue_.pop();
    }

    // 得到速度方向
    Eigen::Vector3d v_dir = avg_v_w.normalized();
    float v_norm = avg_v_w.norm();
    printf("v norm %f\n", v_norm);
    if (v_norm < 0.1) {
        // 几乎静止
        v_dir = (R_wc * Eigen::Vector3d(0, 0, 1)).normalized();
    } else {
#ifdef USE_CAMERA_DIR
        v_dir = R_wc * Eigen::Vector3d(0, 0, 1);
#endif
    }
    if (Config::is_fc_ned_) {
        v_dir(2) = 0;  // 取消pitch, 只进行前方检测, 不然会与地面进行碰撞检测
    } else {
        v_dir(1) = 0;
    }
    v_dir = v_dir.normalized();

    cam_mov_dir_w_ = v_dir;
    std::cout << "v dir " << v_dir << "\n";

    // 根据速度更新检测距离
    caution_dist_   = v_norm * Config::caution_velocity_ratio_ > Config::init_caution_distance_ ?
                      (v_norm * Config::caution_velocity_ratio_) : Config::init_caution_distance_;
    dangerous_dist_ = v_norm * Config::dangerous_velocity_ratio_ > Config::init_dangerous_distance_ ?
                      (v_norm * Config::dangerous_velocity_ratio_): Config::init_dangerous_distance_;
    emergency_dist_ = v_norm * Config::emergency_velocity_ratio_ > Config::init_emergency_distance_ ?
                      (v_norm * Config::emergency_velocity_ratio_) : Config::init_emergency_distance_;

    Eigen::Vector3d probe_pos = cam_pos + v_dir * caution_dist_;

    int caution_voxel_num = 0;
    int dangerous_voxel_num = 0;
    int emergency_voxel_num = 0;

    collision_voxel_pos_vec_.clear();
    caution_pos_vec_.clear();
    dangerous_pos_vec_.clear();

    for (int k = 0; k < caution_dist_ / CHUNK_SIDE_SIZE_M; ++k) {
        Eigen::Vector3d detect_p = probe_pos - v_dir * CHUNK_SIDE_SIZE_M * k * 0.7;

        int chunk_id;
        Eigen::Vector3i chunk_grid_num;
        grid_world_position(detect_p, chunk_id, chunk_grid_num);

        // 检查chunk里面的voxel是否在不同碰撞区域距离里面
        if (map.count(chunk_id)) {
            Chunk_ptr chunk = map[chunk_id];
            if (chunk->time_id != VoxelMap::chunk_next_id_) {
                chunk->time_id = VoxelMap::chunk_next_id_;
                for (int i = 0; i < chunk->voxels.size(); ++i) {
                    Voxel_ptr v = chunk->voxels[i];
                    if (v && v->is_valid) {
                        Eigen::Vector3d v_pos = chunk->voxels[i]->world_pos;
                        float r = get_point_2_line_dist(cam_pos, cam_pos + v_dir, v_pos);
                        if (r > Config::safe_radii_) {
                            // 检测voxel是否在运动方向半径为0.5m的桶形区域内, 剔除其他voxel的干扰
                            continue;
                        }

                        float dist = (cam_pos - v_pos).norm();
                        if (dist < emergency_dist_) {
                            emergency_voxel_num++;
                            chunk->voxels[i]->collision_level = 3;
                        } else if (dist < dangerous_dist_) {
                            dangerous_voxel_num++;
                            chunk->voxels[i]->collision_level = 2;
                            dangerous_pos_vec_.push_back(v_pos);
                        } else if (dist < caution_dist_) {
                            caution_voxel_num++;
                            chunk->voxels[i]->collision_level = 1;
                            caution_pos_vec_.push_back(v_pos);
                        } else {
                            chunk->voxels[i]->collision_level = 0;
                        }
                    }
                }
            }
        }
    }

    collision_status_ = COLLISION_SAFE;
    if (emergency_voxel_num > Config::emergency_voxel_num_) {
        collision_status_ = COLLISION_EMERGENCY;
    } else if (dangerous_voxel_num > Config::dangerous_voxel_num_) {
        collision_status_ = COLLISION_DANGEROUS;
        collision_voxel_pos_vec_ = dangerous_pos_vec_;
    } else if (caution_voxel_num > Config::caution_voxel_num_) {
        collision_status_ = COLLISION_CAUTION;
        collision_voxel_pos_vec_ = caution_pos_vec_;
    }

    analysis_disparity(collision_status_);

    collision_average_point = Eigen::Vector3d::Zero();
    if (collision_voxel_pos_vec_.size() > 0) {
        for (int i = 0; i < collision_voxel_pos_vec_.size(); ++i) {
            collision_average_point += collision_voxel_pos_vec_[i];
        }
        collision_average_point /= collision_voxel_pos_vec_.size();

        Eigen::Vector3d cam_pos = voxel_map_->get_T_wc().translation();
        average_collision_distance_ = (cam_pos - collision_average_point).norm();
    } else {
        average_collision_distance_ = -1;
    }

//    core_point_ = Eigen::Vector3d::Zero();
//    if (collision_status_ == COLLISION_SAFE) {
//        core_point_ = fast_path_finder.fast_find_safe_core_point(voxel_map_->get_disparity(), voxel_map_->get_T_wc());
//        if (fast_path_finder.get_collision_status() != COLLISION_SAFE) {
//            collision_status_ = fast_path_finder.get_collision_status();
//            average_collision_distance_ = fast_path_finder.get_collision_depth();
//        }
//    }

    printf("collision_status --> %d; dist: %f; voxel size: %d\n",
           collision_status_, average_collision_distance_, (int)collision_voxel_pos_vec_.size());

    return collision_status_;
}

void CollisionDetector::analysis_disparity(CollisionStatus &status) {
    cv::Mat dis_map = voxel_map_->get_disparity();
    if (dis_map.empty()) {
        return;
    }

    cv::Mat disparity = dis_map.colRange(dis_map.cols / 2 - CENTRE_RECT_W / 2,
                                         dis_map.cols / 2 + CENTRE_RECT_W / 2)
                               .rowRange(dis_map.rows / 2 - CENTRE_RECT_H / 2,
                                         dis_map.rows / 2 + CENTRE_RECT_H / 2);

#ifdef DEBUG_LOG
    emergency_map_ = cv::Mat(disparity.rows, disparity.cols, CV_8UC1, cv::Scalar(0));
    caution_map_ = cv::Mat(disparity.rows, disparity.cols, CV_8UC1, cv::Scalar(0));

    cv::Mat safe_map = cv::Mat(dis_map.rows, dis_map.cols, CV_8UC1, cv::Scalar(0));
    cv::Mat caution_map = cv::Mat(dis_map.rows, dis_map.cols, CV_8UC1, cv::Scalar(0));
    for (int v = 0; v < dis_map.rows; ++v) {
        for (int u = 0; u < dis_map.cols; ++u) {
            float d = read_disparity(dis_map, u, v);
            if (d > 0) {
                float depth = Camera::instance().get_depth_from_disparity(d);
                if (depth > 10) {
                    safe_map.at<uchar>(v, u) = 255;
                } else if (depth < 3.5) {
                    caution_map.at<uchar>(v, u) = 255;
                }
            }
        }
    }
#endif

    float rect_size = disparity.rows * disparity.cols;
    int valid_num = 0, caution_num = 0, emergency_num = 0;
    double total_depth = 0;
    for (int v = 0; v < disparity.rows; ++v) {
        for (int u = 0; u < disparity.cols; ++u) {
            float d = read_disparity(disparity, u, v);
            if (d > 0) {
                valid_num++;
                float depth = Camera::instance().get_depth_from_disparity(d);
                total_depth += depth;
            }

            if (d > emergency_disparity_value_) {
#ifdef DEBUG_LOG
                emergency_map_.at<uchar>(v, u) = 255;
#endif
                emergency_num++;
            } else if (d > caution_disparity_value_) {
#ifdef DEBUG_LOG
                caution_map_.at<uchar>(v, u) = 255;
#endif
                caution_num++;
            }
        }
    }

    mean_depth_ = total_depth / valid_num;
    float valid_ratio = valid_num / rect_size;
    float caution_ratio = caution_num / rect_size;
    float emergency_ratio = emergency_num / rect_size;

#ifdef DEBUG_LOG
    cv::Mat dis_8u;
    disparity.convertTo(dis_8u, CV_8U, 255 / (32 * 16.));
    cv::imshow("disrect", dis_8u);
    cv::imshow("emer", emergency_map_);
    cv::imshow("cau", caution_map_);
    //cv::imshow("safe map", safe_map);
    //cv::imshow("caution map", caution_map);
#endif

    if (emergency_ratio > Config::emergency_ratio_threshold_) {
        status = COLLISION_EMERGENCY;
    } else if (valid_ratio < Config::valid_ratio_threshold_) {
        if (status == COLLISION_EMERGENCY) {
            status = COLLISION_POOR_DIS_EMERGENCY;
        } else {
            status = COLLISION_POOR_DISPARITY;
        }
    } else if (mean_depth_ < emergency_dist_) {
        status = COLLISION_EMERGENCY;
    } else if (caution_ratio > Config::caution_ratio_threshold_ &&
               status > COLLISION_DANGEROUS) {
        status = COLLISION_DANGEROUS;
    }

#ifdef DEBUG_LOG
    printf("analysis_disparity: mean_d: %f; valid ratio: %f; emergency_ratio: %f; caution_ratio: %f\n",
           mean_depth_, valid_ratio, emergency_ratio, caution_ratio);
#endif
}

}  // namespace PathPlanning
