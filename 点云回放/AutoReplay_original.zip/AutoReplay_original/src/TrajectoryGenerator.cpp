//
// Created by ZZ_AI_Team on 18-6-4.
//

#include <mav_trajectory_generation/trajectory_sampling.h>
#include <mav_trajectory_generation/vertex.h>
#include <mav_trajectory_generation/polynomial_optimization_nonlinear.h>
#include "../include/TrajectoryGenerator.h"

namespace PathPlanning {

int Trajectory::derivative_to_optimize_ = mav_trajectory_generation::derivative_order::SNAP;

mav_trajectory_generation::Trajectory Trajectory::trajectory_;
mav_msgs::EigenTrajectoryPoint::Vector Trajectory::flat_states_;
mav_trajectory_generation::Segment::Vector Trajectory::segments_;

bool Trajectory::linear_generate_trajectory(const std::vector<Eigen::Vector3d> &positions,
                                            const std::vector<Eigen::Vector3d> &velocities,
                                            const Eigen::Vector3d &start_acceleration,
                                            double v_max,
                                            double a_max,
                                            double t_ratio,
                                            bool fabian_time) {
    if (positions.size() < 2) {
        return false;
    }

    mav_trajectory_generation::Vertex::Vector vertices;

    const int dimension = 3;
    mav_trajectory_generation::Vertex start(dimension);

    // start
    //start.makeStartOrEnd(core_points[0], derivative_to_optimize);
    start.addConstraint(mav_trajectory_generation::derivative_order::POSITION, positions[0]);
    start.addConstraint(mav_trajectory_generation::derivative_order::VELOCITY, velocities[0]);
    start.addConstraint(mav_trajectory_generation::derivative_order::ACCELERATION, start_acceleration);
    vertices.push_back(start);

    for (int k = 1; k < positions.size() - 1; ++k) {
        mav_trajectory_generation::Vertex p(dimension);
        p.addConstraint(mav_trajectory_generation::derivative_order::POSITION, Eigen::Vector3d(positions[k](0), positions[k](1), positions[k](2)));
        if (velocities[k] != Eigen::Vector3d::Zero()) {
            p.addConstraint(mav_trajectory_generation::derivative_order::VELOCITY, velocities[k]);
        }
        vertices.push_back(p);
    }

    mav_trajectory_generation::Vertex target(dimension);
    target.makeStartOrEnd(positions[positions.size() - 1], mav_trajectory_generation::derivative_order::SNAP);
    vertices.push_back(target);

    std::vector<double> segment_times;
    if (fabian_time) {
        const double magic_fabian_constant = 6.5; // A tuning parameter.
        segment_times = estimateSegmentTimes(vertices, v_max, a_max, magic_fabian_constant);
        for (int i = 0; i < segment_times.size(); ++i) {
            segment_times[i] *= t_ratio;
        }
    } else {
        if (!estimateSegmentTimesVelocityRamp(vertices, v_max, a_max, t_ratio, &segment_times)) {
            return false;
        }
    }

    const int N = 10;
    mav_trajectory_generation::PolynomialOptimization<N> opt(dimension);
    opt.setupFromVertices(vertices, segment_times, derivative_to_optimize_);
    bool success = opt.solveLinear();

    if (success) {
        segments_.clear();
        opt.getSegments(&segments_);
        opt.getTrajectory(&trajectory_);
    }

    return success;
}

bool Trajectory::nonlinear_generate_trajectory(const std::vector<Eigen::Vector3d> &positions,
                                               const std::vector<Eigen::Vector3d> &velocities,
                                               const Eigen::Vector3d &start_acceleration,
                                               double v_max,
                                               double a_max,
                                               double t_ratio) {
    if (positions.size() < 2) {
        return false;
    }

    mav_trajectory_generation::Vertex::Vector vertices;

    const int dimension = 3;
    const int derivative_to_optimize = mav_trajectory_generation::derivative_order::SNAP;

    // start
    mav_trajectory_generation::Vertex start(dimension);
    //start.makeStartOrEnd(core_points[0], derivative_to_optimize);
    start.addConstraint(mav_trajectory_generation::derivative_order::POSITION, positions[0]);
    start.addConstraint(mav_trajectory_generation::derivative_order::VELOCITY, velocities[0]);
    start.addConstraint(mav_trajectory_generation::derivative_order::ACCELERATION, start_acceleration);
    vertices.push_back(start);

    for (int k = 1; k < positions.size() - 1; ++k) {
        mav_trajectory_generation::Vertex p(dimension);
        p.addConstraint(mav_trajectory_generation::derivative_order::POSITION, Eigen::Vector3d(positions[k](0), positions[k](1), positions[k](2)));
        if (velocities[k] != Eigen::Vector3d::Zero()) {
            p.addConstraint(mav_trajectory_generation::derivative_order::VELOCITY, velocities[k]);
        }
        vertices.push_back(p);
    }

    mav_trajectory_generation::Vertex target(dimension);
    target.makeStartOrEnd(positions[positions.size() - 1], derivative_to_optimize);
    vertices.push_back(target);

    std::vector<double> segment_times;

    //const double magic_fabian_constant = 6.5; // A tuning parameter.
    //segment_times = estimateSegmentTimes(vertices, v_max, a_max, magic_fabian_constant);

    if (!estimateSegmentTimesVelocityRamp(vertices, v_max, a_max, t_ratio, &segment_times)) {
        return false;
    }

    mav_trajectory_generation::NonlinearOptimizationParameters parameters;
    parameters.max_iterations = 1000;
    parameters.f_rel = 0.05;
    parameters.x_rel = 0.1;
    parameters.time_penalty = 500.0;
    parameters.initial_stepsize_rel = 0.1;
    parameters.inequality_constraint_tolerance = 0.1;

    const int N = 10;
    mav_trajectory_generation::PolynomialOptimizationNonLinear<N> opt(dimension, parameters, false);
    opt.setupFromVertices(vertices, segment_times, derivative_to_optimize);
    opt.addMaximumMagnitudeConstraint(mav_trajectory_generation::derivative_order::VELOCITY, v_max);
    opt.addMaximumMagnitudeConstraint(mav_trajectory_generation::derivative_order::ACCELERATION, a_max);
    opt.optimize();

    segments_.clear();
    opt.getTrajectory(&trajectory_);
    trajectory_.getSegments(&segments_);
    return true;
}

void Trajectory::get_trajectory_position(std::vector<Eigen::Vector3d> &trajectory_positions,
                                         std::vector<Eigen::Vector3d> &trajectory_velocities,
                                         std::vector<Eigen::Matrix4d> &trajectory_poses,
                                         const double sampling_t) {
    trajectory_positions.clear();
    trajectory_velocities.clear();
    trajectory_poses.clear();
    flat_states_.clear();

    mav_trajectory_generation::sampleWholeTrajectory(trajectory_, sampling_t, &flat_states_);
    for (size_t i = 0; i < flat_states_.size(); ++i) {
        const mav_msgs::EigenTrajectoryPoint& flat_state = flat_states_[i];
        trajectory_positions.push_back(flat_state.position_W);
        trajectory_velocities.push_back(flat_state.velocity_W);

        Eigen::Matrix4d pose;
        pose.block(0, 0, 3, 3) = flat_states_[i].orientation_W_B.toRotationMatrix();
        Eigen::Vector3d pos = flat_states_[i].position_W;
        pose(0, 3) = pos(0); pose(1, 3) = pos(1); pose(2, 3) = pos(2); pose(3, 3) = 1;
        trajectory_poses.push_back(pose);
    }
}

void Trajectory::sample_trajectory_at_time(const double t,
                                           Eigen::Vector3d &position,
                                           Eigen::Vector3d &velocity,
                                           Eigen::Vector3d &acc) {
    mav_msgs::EigenTrajectoryPoint state;
    mav_trajectory_generation::sampleTrajectoryAtTime(trajectory_, t, &state);

    position = state.position_W;
    velocity = state.velocity_W;
    acc = state.acceleration_W;
}

}