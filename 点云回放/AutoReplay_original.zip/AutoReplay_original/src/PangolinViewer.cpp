//
// Created by ZZ_AI_Team on 17-2-22.
//

#include <pangolin/pangolin.h>
#include "../include/PangolinViewer.h"

#include "../include/ChunkVoxel.h"

using namespace std;

PangolinViewer::PangolinViewer(bool enable_random_map) {
    _view_point_X = 0;
    _view_point_Y = -0.7;
    _view_point_Z = -1.8;
    _view_point_F = 500;

    _camera_size = 0.08;
    _point_size = 2;
    _camera_line_width = 3;
    _keyFrame_size = 0.05;
    _keyFrame_line_width = 1;
    _trajectory_line_width = 0.9;

    _all_map_point.clear();
    _ref_map_point.clear();
    _key_frames_pose.clear();
    _all_positions.clear();

    _T_c_2_w = new pangolin::OpenGlMatrix();
    _T_c_2_w->SetIdentity();

    _c_dist = 0;
    _d_dist = 0;
    _e_dist = 0;

    _enable_draw_random_tree = enable_random_map;

    _re_generate_trajectory = false;

    motion_position_along_trajectory = Eigen::Vector3d::Zero();

    _viewer_thread = new std::thread(&PangolinViewer::Run, this);
}

PangolinViewer::~PangolinViewer() {
    {
        std::unique_lock<std::mutex> lock(_mutex_finish);
        _b_finished = true;
    }
    if (_viewer_thread) {
        _viewer_thread->join();
        delete _viewer_thread;
    }
    if (_T_c_2_w) {
        delete _T_c_2_w;
    }

    pangolin::BindToContext("PangolinViewer");
}

void PangolinViewer::Run() {
    _b_finished = false;

    pangolin::CreateWindowAndBind("SLAM PangolinViewer", 1024, 768);

    pangolin::Plotter plt();

    // 3D Mouse handler requires depth testing to be enabled
    glEnable(GL_DEPTH_TEST);

    // Issue specific OpenGl we might need
    glEnable (GL_BLEND);
    glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    pangolin::CreatePanel("menu").SetBounds(0.0, 1.0, 0.0, pangolin::Attach::Pix(175));

    pangolin::Var<bool> last_frame("menu.last_frame", false, false);
    pangolin::Var<bool> next_frame("menu.next_frame", false, false);
    pangolin::Var<bool> menuPause("menu.----PAUSE----", false, true);


    if (_enable_draw_random_tree) {
#define ENABLE_RANDOM_MAP
    }

#ifdef ENABLE_RANDOM_MAP
    pangolin::OpenGlRenderState s_cam(
            pangolin::ProjectionMatrix(1024, 768, _view_point_F, _view_point_F, 512, 389, 0.1, 10000),
            pangolin::ModelViewLookAt(-10, 0, -10, 0, 0, 0, 0.0, 0.0, -1.0)
    );
#else
    // Define Camera Render Object (for view / scene browsing)
    pangolin::OpenGlRenderState s_cam(
            pangolin::ProjectionMatrix(1024, 768, _view_point_F, _view_point_F, 512, 389, 0.1, 10000),
            pangolin::ModelViewLookAt(_view_point_X, _view_point_Y, _view_point_Z, 0, 0, 0, 0.0, -1.0, 0.0)
    );
#endif

    // Add named OpenGL viewport to window and provide 3D Handler
    pangolin::View& d_cam = pangolin::CreateDisplay()
            .SetBounds(0.0, 1.0, pangolin::Attach::Pix(175), 1.0, -1024.0f / 768.0f)
            .SetHandler(new pangolin::Handler3D(s_cam));

    pangolin::OpenGlMatrix T_c_2_w;
    bool bFollow = false;
    int snapshot_num = 0;

    while (true) {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        {
            std::unique_lock<std::mutex> lock(_mutex_T);
            T_c_2_w = *_T_c_2_w;
        }

        d_cam.Activate(s_cam);
        glClearColor(1.0f,1.0f,1.0f,1.0f);

        // draw slam data
        draw_current_camera(T_c_2_w);
        draw_all_map_points(true);

        draw_astar_path();
        draw_voxel_map();

        system_pause = menuPause;

        if(last_frame)
        {
            last_frame_t = last_frame;
            last_frame = false;
        }

        if(next_frame)
        {
            next_frame_t = next_frame;
            next_frame = false;
        }

        /*
         * 绘制地面网格
         */
        glLineWidth(0.1);
        glColor3f(0.3f, 0.3f, 0.3f);
        pangolin::glDraw_z0(0.5,100);
        glLineWidth(_camera_line_width);
        pangolin::glDrawAxis(2);

        // 绘制 probe
        glLineWidth(2);
        glColor3f(1.0f, 0.0f, 0.0f);
        glBegin(GL_LINES);
        glVertex3f(probe_vector(0)+self_t(0),probe_vector(1)+self_t(1),probe_vector(2)+self_t(2));
        glVertex3f(self_t(0),self_t(1),self_t(2));
        glEnd();

        glLineWidth(2);
        glColor3f(0.0f, 0.0f, 1.0f);
        glBegin(GL_LINES);
        glVertex3f(control_vector(0)+self_t(0),control_vector(1)+self_t(1),control_vector(2)+self_t(2));
        glVertex3f(self_t(0),self_t(1),self_t(2));
        glEnd();

        pangolin::FinishFrame();

        if(check_finish()) {
            break;
        }
    }
}

void PangolinViewer::send_core_point_path(const std::vector<Eigen::Vector3d> &points) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    _astar_path_data.clear();
    for (int i = 0; i < points.size(); ++i) {
        _astar_path_data.push_back(points[i]);
    }
}

void PangolinViewer::send_astar_path(const std::vector<Eigen::Vector3i> &path) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    _astar_path_data.clear();
    for (int i = 0; i < path.size(); ++i) {
        double x = path[i](0);
        double y = path[i](1);
        double z = path[i](2);

        double dx = x * 0.2 - 1000;
        double dy = y * 0.2 - 1000;
        double dz = z * 0.2 - 1000;

        _astar_path_data.push_back(Eigen::Vector3d(dx, dy, dz));
    }
}

void PangolinViewer::send_voxel_map(const std::vector<Eigen::Vector4d> &voxel_grid_map) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    _voxel_map_data.clear();
    for (int i = 0; i < voxel_grid_map.size(); ++i) {
        double x = voxel_grid_map[i](0);
        double y = voxel_grid_map[i](1);
        double z = voxel_grid_map[i](2);
//
//        double dx = x * VOXEL_SIZE_M - CENTRE_OFFSET_M;
//        double dy = y * VOXEL_SIZE_M - CENTRE_OFFSET_M;
//        double dz = z * VOXEL_SIZE_M - CENTRE_OFFSET_M;

        _voxel_map_data.push_back(Eigen::Vector4d(x,y,z, voxel_grid_map[i](3)));
    }
    usleep(2000);
}

void PangolinViewer::send_chunk_map(const std::vector<Eigen::Vector3d> &chunk_map) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    _chunk_map_data.clear();
    for (int i = 0; i < chunk_map.size(); i++) {
        _chunk_map_data.push_back(chunk_map[i]);
    }
}

void PangolinViewer::send_random_map(const std::vector<Eigen::Vector3i> &map) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    random_tree_map.clear();

    for (int i = 0; i < map.size(); ++i) {
        double x = map[i](0);
        double y = map[i](1);
        double z = map[i](2);

        double dx = x * 0.2 - 1000;
        double dy = y * 0.2 - 1000;
        double dz = z * 0.2 - 1000;

        printf("%f %f %f\n", dx, dy, dz);

        random_tree_map.push_back(Eigen::Vector3d(dx, dy, dz));
    }
}

void PangolinViewer::draw_random_tree() {
    for (int i = 0; i < random_tree_map.size(); ++i) {
        draw_fix_color_cube(random_tree_map[i](0), random_tree_map[i](1), random_tree_map[i](2), 0.2);
    }

    if (start_end_point.size() == 2) {
        draw_your_color_cube(start_end_point[0](0), start_end_point[0](1), start_end_point[0](2), 0.2,
                             Eigen::Vector4d(1, 1, 0, 1));

        draw_your_color_cube(start_end_point[1](0), start_end_point[1](1), start_end_point[1](2), 0.2,
                             Eigen::Vector4d(1, 0, 0, 1));

//        glPointSize(100);
//        glBegin(GL_POINTS);
//        glColor3f(1, 1, 0);
//        glVertex3f(start_end_point[0](0), start_end_point[0](1), start_end_point[0](2));
//        glEnd();
//
//        glPointSize(100);
//        glBegin(GL_POINTS);
//        glColor3f(0, 1, 0);
//        glVertex3f(start_end_point[1](0), start_end_point[1](1), start_end_point[1](2));
//        glEnd();
    }
}

void PangolinViewer::draw_voxel_map() {
    std::unique_lock<std::mutex> lock(_mutex_T);
    // draw voxel map
    for (int i = 0; i < _voxel_map_data.size(); i++) {
        if (_voxel_map_data[i](3) == 0) {
            int cc = _voxel_map_data[i](3);
            draw_fix_color_cube(_voxel_map_data[i](0), _voxel_map_data[i](1), _voxel_map_data[i](2), VOXEL_SIZE_M);
        } else if (_voxel_map_data[i](3) == 1) {
            draw_your_color_cube(_voxel_map_data[i](0), _voxel_map_data[i](1), _voxel_map_data[i](2), VOXEL_SIZE_M,
                                 Eigen::Vector4d(1, 1, 0, 1));
        } else if (_voxel_map_data[i](3) == 2) {
            draw_your_color_cube(_voxel_map_data[i](0), _voxel_map_data[i](1), _voxel_map_data[i](2), VOXEL_SIZE_M,
                                 Eigen::Vector4d(1, 0, 1, 1));
        } else if (_voxel_map_data[i](3) == 3) {
            draw_your_color_cube(_voxel_map_data[i](0), _voxel_map_data[i](1), _voxel_map_data[i](2), VOXEL_SIZE_M,
                                 Eigen::Vector4d(1, 0, 0, 1));
        }
    }
    for (int i = 0; i < _chunk_map_data.size(); ++i) {
        draw_your_color_cube(_chunk_map_data[i](0), _chunk_map_data[i](1), _chunk_map_data[i](2), CHUNK_SIDE_SIZE_M,
                             Eigen::Vector4d(0, 0, 0, 0.2));
    }
}

void PangolinViewer::draw_astar_path() {
    std::unique_lock<std::mutex> lock(_mutex_T);
    for (int i = 0; i < _astar_path_data.size(); ++i) {
//        if (i == 0) {
//            draw_your_color_cube(_astar_path_data[i](0)+0.5*VOXEL_SIZE_M, _astar_path_data[i](1)+0.5*VOXEL_SIZE_M, _astar_path_data[i](2)+0.5*VOXEL_SIZE_M, 0.2*VOXEL_SIZE_M,
//                                 Eigen::Vector4d(0, 0, 1, 1));
//        } else {
//            draw_your_color_cube(_astar_path_data[i](0)+0.5*VOXEL_SIZE_M, _astar_path_data[i](1)+0.5*VOXEL_SIZE_M, _astar_path_data[i](2)+0.5*VOXEL_SIZE_M, 0.2*VOXEL_SIZE_M,
//                                 Eigen::Vector4d(0, 1, 0, 1));
//        }

        if(i!=_astar_path_data.size()-1)
        {
            glLineWidth(_camera_line_width);
            glColor3f(1.0f, 0.0f, 0.0f);
            glBegin(GL_LINES);
            glVertex3f(_astar_path_data[i](0)+0.5*VOXEL_SIZE_M, _astar_path_data[i](1)+0.5*VOXEL_SIZE_M, _astar_path_data[i](2)+0.5*VOXEL_SIZE_M);
            glVertex3f(_astar_path_data[i+1](0)+0.5*VOXEL_SIZE_M, _astar_path_data[i+1](1)+0.5*VOXEL_SIZE_M, _astar_path_data[i+1](2)+0.5*VOXEL_SIZE_M);
            glEnd();
        }
    }
}



void PangolinViewer::draw_fix_color_cube(GLfloat x, GLfloat y, GLfloat z, GLfloat size) {
    const GLfloat x_1 = x + size;
    const GLfloat y_1 = y + size;
    const GLfloat z_1 = z + size;

    const GLfloat verts[] = {
            x,y,z,    x,y,z_1,    x_1,y,z_1,    x_1,y,z,      // FRONT
            x,y_1,z,  x,y_1,z_1,  x_1,y_1,z_1,  x_1,y_1,z,    // BACK
            x_1,y,z,  x_1,y,z_1,  x_1,y_1,z_1,  x_1,y_1,z,    // LEFT
            x,y,z,    x,y,z_1,    x,y_1,z_1,    x,y_1,z,      // RIGHT
            x,y,z,    x,y_1,z,    x_1,y_1,z,    x_1,y,z,      // TOP
            x,y,z_1,  x,y_1,z_1,  x_1,y_1,z_1,  x_1,y,z_1     // BOTTOM
    };

    {
        glLineWidth(0.1);
        glColor3f(0.0f, 0.0f, 0.0f);
        glBegin(GL_LINES);
        glVertex3f(x,y,z);
        glVertex3f(x,y,z_1);
        glVertex3f(x,y,z_1);
        glVertex3f(x_1,y,z_1);
        glVertex3f(x_1,y,z_1);
        glVertex3f(x_1,y,z);
        glVertex3f(x_1,y,z);
        glVertex3f(x,y,z);
        glEnd();

        glLineWidth(0.1);
        glColor3f(0.0f, 0.0f, 0.0f);
        glBegin(GL_LINES);
        glVertex3f(x,y_1,z);
        glVertex3f(x,y_1,z_1);
        glVertex3f(x,y_1,z_1);
        glVertex3f(x_1,y_1,z_1);
        glVertex3f(x_1,y_1,z_1);
        glVertex3f(x_1,y_1,z);
        glVertex3f(x_1,y_1,z);
        glVertex3f(x,y_1,z);
        glEnd();

        glLineWidth(0.1);
        glColor3f(0.0f, 0.0f, 0.0f);
        glBegin(GL_LINES);
        glVertex3f(x_1,y,z);
        glVertex3f(x_1,y,z_1);
        glVertex3f(x_1,y,z_1);
        glVertex3f(x_1,y_1,z_1);
        glVertex3f(x_1,y_1,z_1);
        glVertex3f(x_1,y_1,z);
        glVertex3f(x_1,y_1,z);
        glVertex3f(x_1,y,z);
        glEnd();

        glLineWidth(0.1);
        glColor3f(0.0f, 0.0f, 0.0f);
        glBegin(GL_LINES);
        glVertex3f(x,y,z);
        glVertex3f(x,y,z_1);
        glVertex3f(x,y,z_1);
        glVertex3f(x,y_1,z_1);
        glVertex3f(x,y_1,z_1);
        glVertex3f(x,y_1,z);
        glVertex3f(x,y_1,z);
        glVertex3f(x,y,z);
        glEnd();
    }


    double alpha = min(3.0+z,3.0)/3.0;
    double red=alpha;
    double green=1-alpha;
    double blue=0;

    {
        double tmp2 = 255*z/3.0f+100;
        int r=0,g=0,b=0;
        if(tmp2 ==0 )
        {
            r=0,g=0,b=0;
        }
        if (tmp2 <= 51)
        {
            b = 255;
            g = tmp2*5;
            r = 0;
        }
        else if (tmp2 <= 102)
        {
            tmp2-=51;
            b = 255-tmp2*5;
            g = 255;
            r = 0;
        }
        else if (tmp2 <= 153)
        {
            tmp2-=102;
            b = 0;
            g = 255;
            r = tmp2*5;
        }
        else if (tmp2 <= 204)
        {
            tmp2-=153;
            b = 0;
            g = 255-uchar(128.0*tmp2/51.0+0.5);
            r = 255;
        }
        else
        {
            tmp2-=204;
            b = 0;
            g = 127-uchar(127.0*tmp2/51.0+0.5);
            r = 255;
        }
        red=((double)r)/255.0d;
        green=((double)g)/255.0d;
        blue=((double)b)/255.0d;
    }


    glVertexPointer(3, GL_FLOAT, 0, verts);
    glEnableClientState(GL_VERTEX_ARRAY);

    //glColor4f(r, g, b, d);
    glColor4f(red, green, blue, 1);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 4, 4);

    //glColor4f(r, g, b, d);
    glColor4f(red, green, blue, 1);
    glDrawArrays(GL_TRIANGLE_FAN, 8, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 12, 4);

    //glColor4f(r, g, b, d);
    glColor4f(red, green, blue, 1);
    glDrawArrays(GL_TRIANGLE_FAN, 16, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 20, 4);

    glDisableClientState(GL_VERTEX_ARRAY);
}

void PangolinViewer::draw_your_color_cube(GLfloat x, GLfloat y, GLfloat z, GLfloat size, Eigen::Vector4d rgbd) {
    const GLfloat x_1 = x + size;
    const GLfloat y_1 = y + size;
    const GLfloat z_1 = z + size;

    float r = rgbd[0];
    float g = rgbd[1];
    float b = rgbd[2];
    float d = rgbd[3];

    const GLfloat verts[] = {
            x,y,z,    x,y,z_1,    x_1,y,z_1,    x_1,y,z,      // FRONT
            x,y_1,z,  x,y_1,z_1,  x_1,y_1,z_1,  x_1,y_1,z,    // BACK
            x_1,y,z,  x_1,y,z_1,  x_1,y_1,z_1,  x_1,y_1,z,    // LEFT
            x,y,z,    x,y,z_1,    x,y_1,z_1,    x,y_1,z,      // RIGHT
            x,y,z,    x,y_1,z,    x_1,y_1,z,    x_1,y,z,      // TOP
            x,y,z_1,  x,y_1,z_1,  x_1,y_1,z_1,  x_1,y,z_1     // BOTTOM
    };

    glVertexPointer(3, GL_FLOAT, 0, verts);
    glEnableClientState(GL_VERTEX_ARRAY);

    glColor4f(r, g, b, d);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 4, 4);

    glColor4f(r, g, b, d);
    glDrawArrays(GL_TRIANGLE_FAN, 8, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 12, 4);

    glColor4f(r, g, b, d);
    glDrawArrays(GL_TRIANGLE_FAN, 16, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 20, 4);

    glDisableClientState(GL_VERTEX_ARRAY);
}

void PangolinViewer::send_slam_data_to_viewer(const cv::Mat &T_c_2_w,
                                              const std::vector<cv::Point3d> &all_map_points,
                                              const std::vector<cv::Point3d> &ref_map_points,
                                              const std::vector<cv::Mat> &key_frames_pose) {
    if (!T_c_2_w.empty()) {
        std::unique_lock<std::mutex> lock(_mutex_T);
        cv_mat_2_gl_matrix(T_c_2_w, *_T_c_2_w);

        _all_positions.push_back(cv::Point3d(T_c_2_w.at<float>(0, 3),
                                             T_c_2_w.at<float>(1, 3),
                                             T_c_2_w.at<float>(2, 3)));

        _all_map_point.clear();
        _key_frames_pose.clear();
        _ref_map_point.clear();
        _all_map_point.insert(_all_map_point.begin(), all_map_points.begin(), all_map_points.end());
        _ref_map_point.insert(_ref_map_point.begin(), ref_map_points.begin(), ref_map_points.end());
        _key_frames_pose.insert(_key_frames_pose.begin(), key_frames_pose.begin(), key_frames_pose.end());
    }
    usleep(5000);
}

void PangolinViewer::send_slam_all_map_points_color(const std::vector<cv::Point3d> &color) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    _all_map_point_color = color;
}

void PangolinViewer::cv_mat_2_gl_matrix(const cv::Mat &pose_mat, pangolin::OpenGlMatrix &T_c_2_w) {
    cv::Mat pose;
    if (pose_mat.type() != CV_64F) {
        pose_mat.convertTo(pose, CV_64F);
    } else {
        pose = pose_mat;
    }

    T_c_2_w.m[0] = pose.at<double>(0, 0);
    T_c_2_w.m[1] = pose.at<double>(1, 0);
    T_c_2_w.m[2] = pose.at<double>(2, 0);
    T_c_2_w.m[3] = 0.0;

    T_c_2_w.m[4] = pose.at<double>(0, 1);
    T_c_2_w.m[5] = pose.at<double>(1, 1);
    T_c_2_w.m[6] = pose.at<double>(2, 1);
    T_c_2_w.m[7] = 0.0;

    T_c_2_w.m[8] = pose.at<double>(0, 2);
    T_c_2_w.m[9] = pose.at<double>(1, 2);
    T_c_2_w.m[10] = pose.at<double>(2, 2);
    T_c_2_w.m[11] = 0.0;

    T_c_2_w.m[12] = pose.at<double>(0, 3);
    T_c_2_w.m[13] = pose.at<double>(1, 3);
    T_c_2_w.m[14] = pose.at<double>(2, 3);
    T_c_2_w.m[15] = 1.0;
}

void PangolinViewer::draw_current_camera(const pangolin::OpenGlMatrix &T_c_2_w) {
    const float &w = _camera_size;
    const float h = w * 0.75;
//    const float z = w * 0.6;

    GLfloat x = 0-0.23;
    GLfloat y = 0-0.1;
    GLfloat z = 0-0.03;

    GLfloat x_1 = x + 0.2;
    GLfloat y_1 = y + 0.02;
    GLfloat z_1 = z + 0.2;

    double red=0, green=0, blue=0;

    const GLfloat verts[] = {
            x,y,z,    x,y,z_1,    x_1,y,z_1,    x_1,y,z,      // FRONT
            x,y_1,z,  x,y_1,z_1,  x_1,y_1,z_1,  x_1,y_1,z,    // BACK
            x_1,y,z,  x_1,y,z_1,  x_1,y_1,z_1,  x_1,y_1,z,    // LEFT
            x,y,z,    x,y,z_1,    x,y_1,z_1,    x,y_1,z,      // RIGHT
            x,y,z,    x,y_1,z,    x_1,y_1,z,    x_1,y,z,      // TOP
            x,y,z_1,  x,y_1,z_1,  x_1,y_1,z_1,  x_1,y,z_1     // BOTTOM
    };

    glPushMatrix();
    glMultMatrixd(T_c_2_w.m);

    glVertexPointer(3, GL_FLOAT, 0, verts);
    glEnableClientState(GL_VERTEX_ARRAY);

    //glColor4f(r, g, b, d);
    glColor4f(red, green, blue, 1);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 4, 4);

    //glColor4f(r, g, b, d);
    glColor4f(red, green, blue, 1);
    glDrawArrays(GL_TRIANGLE_FAN, 8, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 12, 4);

    //glColor4f(r, g, b, d);
    glColor4f(red, green, blue, 1);
    glDrawArrays(GL_TRIANGLE_FAN, 16, 4);
    glDrawArrays(GL_TRIANGLE_FAN, 20, 4);

    glDisableClientState(GL_VERTEX_ARRAY);


    glLineWidth(0.1);
    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);
    glVertex3f(x,y,z);
    glVertex3f(x,y,z_1);
    glVertex3f(x,y,z_1);
    glVertex3f(x_1,y,z_1);
    glVertex3f(x_1,y,z_1);
    glVertex3f(x_1,y,z);
    glVertex3f(x_1,y,z);
    glVertex3f(x,y,z);
    glEnd();

    glPopMatrix();


//------------------------------------------

//    glPushMatrix();
//    glMultMatrixd(T_c_2_w.m);
//
//    glLineWidth(_camera_line_width);
//    glColor3f(0.0f, 1.0f, 0.0f);
//    glBegin(GL_LINES);
//    glVertex3f(0, 0, 0);
//    glVertex3f(w, h, z);
//    glVertex3f(0, 0, 0);
//    glVertex3f(w, -h, z);
//    glVertex3f(0, 0, 0);
//    glVertex3f(-w, -h, z);
//    glVertex3f(0, 0, 0);
//    glVertex3f(-w, h, z);
//
//    glVertex3f(w, h, z);
//    glVertex3f(w, -h, z);
//
//    glVertex3f(-w, h, z);
//    glVertex3f(-w, -h, z);
//
//    glVertex3f(-w, h, z);
//    glVertex3f(w, h, z);
//
//    glVertex3f(-w, -h, z);
//    glVertex3f(w, -h, z);
//    glEnd();
//
//    glPopMatrix();

    /*********/
//    // 绘制相机前方向量
//    glPushMatrix();
//    glMultMatrixd(T_c_2_w.m);
//
//    glLineWidth(_camera_line_width + 1);
//    glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
//    glBegin(GL_LINES);
//
//    glVertex3f(0, 0, 0);
//    glVertex3f(0, 0, 1);
//    glEnd();

    glPopMatrix();
}

void PangolinViewer::draw_all_map_points(const bool b_draw_poinst) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    if (_all_map_point.empty() || !b_draw_poinst)
        return;

    if (_all_map_point_color.size() > 0) {
        glPointSize(_point_size);
        glBegin(GL_POINTS);

        for (int i = 0; i < _all_map_point.size(); ++i) {
            glVertex3f(_all_map_point[i].x, _all_map_point[i].y, _all_map_point[i].z);
            glColor3f(_all_map_point_color[i].x, _all_map_point_color[i].y, _all_map_point_color[i].z);
        }

        glEnd();
    } else {
        glPointSize(_point_size);
        glBegin(GL_POINTS);
        glColor3f(0.1, 0.1, 0.1);

        for (int i = 0; i < _all_map_point.size(); ++i) {
            glVertex3f(_all_map_point[i].x, _all_map_point[i].y, _all_map_point[i].z);
        }

        glEnd();
    }
}

void PangolinViewer::draw_ref_map_points(const bool b_draw_poinst) {
    std::unique_lock<std::mutex> lock(_mutex_T);
    if (_ref_map_point.empty() || !b_draw_poinst)
        return;

    glPointSize(_point_size);
    glBegin(GL_POINTS);
    glColor3f(1.0, 0.0, 0.0);

    for (int i = 0; i < _ref_map_point.size(); ++i) {
        glVertex3f(_ref_map_point[i].x, _ref_map_point[i].y, _ref_map_point[i].z);
    }

    glEnd();
}

void PangolinViewer::draw_keyFrames(const bool b_draw_KF) {
    const float &w = _keyFrame_size;
    const float h = w * 0.75;
    const float z = w * 0.6;

    if(b_draw_KF) {
        std::unique_lock<std::mutex> lock(_mutex_T);
        for (size_t i = 0; i< _key_frames_pose.size(); i++) {
            cv::Mat pose = _key_frames_pose[i];
            pangolin::OpenGlMatrix Twc;
            cv_mat_2_gl_matrix(pose, Twc);

            glPushMatrix();
            glMultMatrixd(Twc.m);

            glLineWidth(_keyFrame_line_width);
            glColor3f(0.0f, 0.0f, 1.0f);
            glBegin(GL_LINES);
            glVertex3f(0, 0, 0);
            glVertex3f(w, h, z);
            glVertex3f(0, 0, 0);
            glVertex3f(w, -h, z);
            glVertex3f(0, 0, 0);
            glVertex3f(-w, -h, z);
            glVertex3f(0, 0, 0);
            glVertex3f(-w, h, z);

            glVertex3f(w, h, z);
            glVertex3f(w, -h, z);

            glVertex3f(-w, h, z);
            glVertex3f(-w, -h, z);

            glVertex3f(-w, h, z);
            glVertex3f(w, h, z);

            glVertex3f(-w, -h, z);
            glVertex3f(w, -h, z);
            glEnd();

            glPopMatrix();
        }
    }
}

void PangolinViewer::draw_trajectory() {
    glLineWidth(_trajectory_line_width);
    glColor4f(0.0f,0.0f,0.0f,0.6f);
    glBegin(GL_LINES);

    std::unique_lock<std::mutex> lock(_mutex_T);
    for (int i = 1; i < _all_positions.size(); ++i) {
        glVertex3f(_all_positions[i - 1].x, _all_positions[i - 1].y, _all_positions[i - 1].z);
        glVertex3f(_all_positions[i].x, _all_positions[i].y, _all_positions[i].z);
    }

    glEnd();
}

void PangolinViewer::draw_trajectory_generation_data() {
    std::unique_lock<std::mutex> lock(_mutex_T);

    // draw positions
    glLineWidth(1.5);
    glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
    glBegin(GL_LINES);

    for (int i = 1; i < trajectory_positions.size(); ++i) {
        glVertex3f(trajectory_positions[i - 1](0), trajectory_positions[i - 1](1), trajectory_positions[i - 1](2));
        glVertex3f(trajectory_positions[i](0), trajectory_positions[i](1), trajectory_positions[i](2));
    }

    glEnd();

    glLineWidth(1.5);
    glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
    glBegin(GL_LINES);
    for (int i = 1; i < trajectory_positions2.size(); ++i) {
        glVertex3f(trajectory_positions2[i - 1](0), trajectory_positions2[i - 1](1), trajectory_positions2[i - 1](2));
        glVertex3f(trajectory_positions2[i](0), trajectory_positions2[i](1), trajectory_positions2[i](2));
    }
    glEnd();

    // draw velocity
    for (int i = 0; i < sampled_trajectory_velocities.size(); ++i) {
        pangolin::glSetFrameOfReference(sampled_trajectory_poses[i]);
        glLineWidth(1.5);
        glColor4f(1.0f, 0.0f, 1.0f, 1.0f);
        glBegin(GL_LINES);

        glVertex3f(0, 0, 0);
        glVertex3f(sampled_trajectory_velocities[i](0), sampled_trajectory_velocities[i](1), sampled_trajectory_velocities[i](2));

        glEnd();
        pangolin::glUnsetFrameOfReference();
    }

    // draw rotated Axis
    for (int i = 0; i < sampled_trajectory_poses.size(); ++i) {
        pangolin::glDrawAxis(sampled_trajectory_poses[i], 0.2);
    }

    // draw core points
    for (int i = 0; i < trajectory_core_points.size(); ++i) {
        glPushMatrix(); //remember current matrix

        if (i == 0) {
            glColor3f(1, 1, 0);
        } else if (i == trajectory_core_points.size() - 1) {
            glColor3f(1, 0, 0);
        } else {
            glColor3f(0, 1, 0);
        }

        GLUquadric *quad;
        quad = gluNewQuadric();
        glTranslatef(trajectory_core_points[i](0), trajectory_core_points[i](1), trajectory_core_points[i](2));
        gluSphere(quad, 0.1, 100, 20);
        glPopMatrix(); //restore matrix
    }

    if (motion_position_along_trajectory[0] != 0) {
        glPushMatrix();
        glColor3f(0, 1, 0);
        GLUquadric *quad;
        quad = gluNewQuadric();
        glTranslatef(motion_position_along_trajectory(0), motion_position_along_trajectory(1), motion_position_along_trajectory(2));
        gluSphere(quad, 0.1, 100, 20);
        glPopMatrix();
    }
}

bool PangolinViewer::check_finish() {
    std::unique_lock<std::mutex> lock(_mutex_finish);
    return _b_finished;
}

void PangolinViewer::reset_data() {
    std::unique_lock<std::mutex> lock(_mutex_T);
    _all_positions.clear();
    if (_T_c_2_w) {
        _T_c_2_w->SetIdentity();
    }
}