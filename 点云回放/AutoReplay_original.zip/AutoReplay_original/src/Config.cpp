//
// Created by ZZ_AI_Team on 7/4/18.
//

#include "../include/Config.h"
#include "opencv2/opencv.hpp"

namespace PathPlanning {

int Config::use_fast_path_finder = 0;
int Config::is_fc_ned_ = 0;

float Config::base_line_ = 0.07;      // Stereo baseline (m)
float Config::baseline_f_;            // Stereo baseline multiplied by fx.

// camera intrinsic parameters
float Config::fx_;
float Config::fy_;
float Config::cx_;
float Config::cy_;
Eigen::Matrix3d Config::K_;

int Config::img_width_  = 320;
int Config::img_height_ = 240;

// VoxelMap
float Config::map_scale_ = 1.2;
int   Config::map_type_ = 1;

float Config::point_max_distance_ = 6;
float Config::front_max_distance_ = 6;
float Config::back_max_distance_  = 3;

float Config::visable_voxel_theta_ = 0.65;
int Config::voxel_max_life_time_ = 5;

// CollisionDetector
float Config::init_caution_distance_   = 2.0;
float Config::init_dangerous_distance_ = 1.4;
float Config::init_emergency_distance_ = 0.8;

float Config::caution_velocity_ratio_    = 1.5;
float Config::dangerous_velocity_ratio_  = 1.0;
float Config::emergency_velocity_ratio_  = 0.5;

int Config::caution_voxel_num_ = 2;
int Config::dangerous_voxel_num_ = 3;
int Config::emergency_voxel_num_ = 4;

float Config::emergency_ratio_threshold_ = 0.4;
float Config::caution_ratio_threshold_ = 0.4;
float Config::valid_ratio_threshold_ = 0.4;

float Config::safe_radii_ = 0.5;

// PathFinder
float Config::safe_offset_distance_ = 0.6;

Config::Config(const std::string setting_file) {
    cv::FileStorage fileStorage(setting_file, cv::FileStorage::READ);
    if (!fileStorage.isOpened()) {
        std::cerr << "Failed to open settings file at: " << setting_file << std::endl;
        exit(-1);
    }

    fileStorage["Fast.pathFinder"] >> use_fast_path_finder;

    fileStorage["FC.ned"] >> is_fc_ned_;

    fileStorage["Camera.baseline"] >> base_line_;

    fileStorage["Map.scale"] >> map_scale_;
    if (map_scale_ == 0) {
        map_scale_ = 1.0;
    }
    fileStorage["Map.type"] >> map_type_;

    fileStorage["Camera.width"] >> img_width_;
    fileStorage["Camera.height"] >> img_height_;
    img_width_  /= 2;
    img_height_ /= 2;

    fileStorage["Camera.fx"] >> fx_;
    fileStorage["Camera.fy"] >> fy_;
    fileStorage["Camera.cx"] >> cx_;
    fileStorage["Camera.cy"] >> cy_;
    fx_ /= 2; fy_ /= 2;
    cx_ /= 2; cy_ /= 2;

    baseline_f_ = base_line_ * fx_;

    K_ = Eigen::Matrix3d::Identity();
    K_(0, 0) = fx_; K_(0, 2) = cx_;
    K_(1, 1) = fy_; K_(1, 2) = cy_;

    fileStorage["Voxel.point_max_dist"] >> point_max_distance_;
    fileStorage["Voxel.front_max_dist"] >> front_max_distance_;
    fileStorage["Voxel.back_max_dist"]  >> back_max_distance_;

    fileStorage["Voxel.visable_theta"] >> visable_voxel_theta_;
    fileStorage["Voxel.life_time"] >> voxel_max_life_time_;

    fileStorage["Collision.caution_dist"] >> init_caution_distance_;
    fileStorage["Collision.dangerous_dist"] >> init_dangerous_distance_;
    fileStorage["Collision.emergency_dist"] >> init_emergency_distance_;

    fileStorage["Collision.caution_v_ratio"] >> caution_velocity_ratio_;
    fileStorage["Collision.dangerous_v_ratio"] >> dangerous_velocity_ratio_;
    fileStorage["Collision.emergency_v_ratio"] >> emergency_velocity_ratio_;

    fileStorage["Collision.caution_num"] >> caution_voxel_num_;
    fileStorage["Collision.dangerous_num"] >> dangerous_voxel_num_;
    fileStorage["Collision.emergency_num"] >> emergency_voxel_num_;

    fileStorage["Collision.emergency_ratio"] >> emergency_ratio_threshold_;
    fileStorage["Collision.caution_ratio"] >> caution_ratio_threshold_;
    fileStorage["Collision.valid_ratio"] >> valid_ratio_threshold_;

    fileStorage["Collision.safe_radii"] >> safe_radii_;

    fileStorage["PathFinder.safe_offset_dist"] >> safe_offset_distance_;

    printf("******Config Parametres*********\n");
    printf("FC.ned: %d\n", is_fc_ned_);
    printf("Camera.baseline: %f; baseline_f: %f\n", base_line_, baseline_f_);
    printf("Map.scale: %f; Map.type: %d\n", map_scale_, map_type_);
    printf("Camera.width: %d; height: %d\n", img_width_, img_height_);
    printf("Camera.fx: %f, fy: %f, cx: %f, cy: %f\n", fx_, fy_, cx_, cy_);
    printf("Voxel.max_dist: %f; visable_theta: %f\n", point_max_distance_, visable_voxel_theta_);
    printf("Collision.caution_dist: %f, dangerous_dist: %f, emergency_dist: %f\n",
           init_caution_distance_, init_dangerous_distance_, init_emergency_distance_);
    printf("Collision.emergency_ratio: %f, caution_ratio: %f, valid_ratio: %f\n",
           emergency_ratio_threshold_, caution_ratio_threshold_, valid_ratio_threshold_);
    printf("PathFinder.safe_dist %f\n", safe_offset_distance_);
}

}  // namespace PathPlanning