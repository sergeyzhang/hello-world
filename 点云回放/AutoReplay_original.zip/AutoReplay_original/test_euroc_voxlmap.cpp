//
// Created by ZZ_AI_Team on 18-4-28.
//

/*
 * cd build
 * make -j4 && ./cmake/x86/test_euroc_voxlmap -p PathPlanningNeo_log
 */

#include <iostream>
#include <Eigen/Core>
#include <Eigen/Dense>
#include <map>
#include <fstream>

#include "cmdline.h"
#include <opencv2/opencv.hpp>

#include "include/ChunkVoxel.h"
#include "include/VoxelMap.h"

#include "include/PathPlanningSystem.h"

#include "include/Trajectory.h"
#include <thread>

#ifdef __ARM__
#include <nn.h>
#include <pubsub.h>
#include <reqrep.h>
#include "base.pb.h"
#include "obstacle_avoidance.pb.h"
#else
#include "include/PangolinViewer.h"
#endif

#include "timer.h"

using namespace PathPlanning;
using namespace std;

#define REPLAY_VOXEL
#define REPLAY_PTC

std::string image_base_path;     // 外部参数

bool pause_ = false;

int run() {

    PangolinViewer *pangolin_viewer = new PangolinViewer();

    /*
     * 读入 replay-log
     */
    std::vector<int> fnames;
    std::vector<Eigen::Vector3d> tanslations;
    std::vector<Eigen::Matrix3d> rotations;
    std::vector<bool> brake_cmd;
    std::vector<int> near_ptcs;
    std::vector<int> near_voxs;
    std::vector<int> brake_filter_fifo_cts;
    std::vector<Eigen::Vector3d> probes;
    std::vector<Eigen::Vector3d> crtls;
    std::vector<double> time_stamps;

    std::vector<int> v1;
    std::vector<int> v2;

    std::ifstream inf;
    inf.open((image_base_path+"/data.log").c_str(), std::ifstream::in);
    std::string line;

    char line_c[1200];
    memset(line_c,0,1200);

    /*
     * 解码字符信息
     */
    while (std::getline(inf,line) && !line.empty()) {

        memset(line_c,0,1200);
        strcpy(line_c,line.c_str());


        char *tokenPtr=strtok(line_c,"|");

        int item_ct = 0;
        while(tokenPtr!=NULL){
            if(item_ct == 0){
                float b=0;
                std::sscanf(tokenPtr,"%f",&b);
                time_stamps.push_back(b);
            }
            if(item_ct == 1){
                // tokenPtr 这就是此行数据编号
                fnames.push_back(atoi(tokenPtr));
            }
            else if(item_ct==2){
                // 飞机位置
                float x=0,y=0,z=0;
                std::sscanf(tokenPtr,"%f,%f,%f",&x,&y,&z);
                tanslations.push_back(Eigen::Vector3d(x,y,z));
//                cout<<"position : "<<x<<" | "<<y<<" | "<<z<<endl;
            }
            else if(item_ct == 3){
                // 飞机姿态
                Eigen::Matrix3d r;
                float r1=0;
                float r2=0;
                float r3=0;
                float r4=0;
                float r5=0;
                float r6=0;
                float r7=0;
                float r8=0;
                float r9=0;
                std::sscanf(tokenPtr,"%f,%f,%f,%f,%f,%f,%f,%f,%f",
                            &r1,
                            &r2,
                            &r3,
                            &r4,
                            &r5,
                            &r6,
                            &r7,
                            &r8,
                            &r9
                );

                r(0,0)=r1;
                r(0,1)=r2;
                r(0,2)=r3;
                r(1,0)=r4;
                r(1,1)=r5;
                r(1,2)=r6;
                r(2,0)=r7;
                r(2,1)=r8;
                r(2,2)=r9;
                rotations.push_back(r);

//                cout<<tokenPtr<<endl;
//                cout<<r<<endl;
            }
            else if(item_ct == 5){
                int b=0;
                std::sscanf(tokenPtr,"%d",&b);
                brake_cmd.push_back(b);
                cout << "brake_cmd: " << b << endl;
            }
            else if(item_ct == 6){
                int b=0;
                std::sscanf(tokenPtr,"%d",&b);
                near_ptcs.push_back(b);
                cout << "near_ptcs: " << b << endl;
            }
            else if(item_ct == 7)
            {
                int b=0;
                std::sscanf(tokenPtr,"%d",&b);
                near_voxs.push_back(b);
                cout << "near_voxs: " << b << endl;
            }
            else if(item_ct == 8)
            {
                float tx=0;
                float ty=0;
                float tz=0;
                std::sscanf(tokenPtr,"%f,%f,%f",
                            &tx,
                            &ty,
                            &tz
                );
                Eigen::Vector3d pb;
                pb(0)=tx;
                pb(1)=ty;
                pb(2)=tz;
                probes.push_back(pb);
            }
            else if(item_ct == 9)
            {
                int b=0;
                std::sscanf(tokenPtr,"%d",&b);
                brake_filter_fifo_cts.push_back(b);
            }
            else if(item_ct == 10)
            {
                float tx=0;
                float ty=0;
                float tz=0;
                std::sscanf(tokenPtr,"%f,%f,%f",
                            &tx,
                            &ty,
                            &tz
                );
                Eigen::Vector3d pb;
                pb(0)=tx;
                pb(1)=ty;
                pb(2)=tz;
                crtls.push_back(pb);
            }
            else if(item_ct == 14)
            {
                int b=0;
                std::sscanf(tokenPtr,"%d",&b);
                v1.push_back(b);
                cout << "v1: " << b << endl;
            }
            else if(item_ct == 15)
            {
                int b=0;
                std::sscanf(tokenPtr,"%d",&b);
                v2.push_back(b);
                cout << "v2: " << b << endl;
            }

            tokenPtr=strtok(NULL,"|");
            item_ct++;
        }
        cout<<endl;
        delete tokenPtr;
    }


    inf.close();

    /*
     * 解码空间信息
     */
    std::vector<cv::Point3d> point_cloud;
    bool space_snapshot2[snapshot_x][snapshot_y][snapshot_z];
    std::vector<Eigen::Vector4d> voxel_map_viewer_data;

    for(int i=0;i<fnames.size();i++){

        char img_name[200];
        char img_ct[100];

        memset(img_name,0,200);
        memset(img_ct,0,100);
        stringstream ss;ss<<fnames[i];ss>>img_ct;


#ifdef REPLAY_VOXEL
        // 显示体素模式
        strcat(img_name,(image_base_path+"/").c_str());
        strcat(img_name,img_ct);
        strcat(img_name,".bmp");

        std::string fucking_name(img_name);
//        cout<<"funcking name: " << fucking_name<<endl;

        cv::Mat voxmap;
        voxmap = cv::imread(fucking_name,1);

        if(!voxmap.empty()) {//log4-------------
            /*
             * 读入局部体素图, 进行可视化
             */
            memset(space_snapshot2,1,snapshot_x*snapshot_x*snapshot_z*sizeof(bool));
            voxel_map_viewer_data.clear();

            // 解码体素
            for(int x=0;x<snapshot_x;x++){
                for(int y=0;y<snapshot_y;y++){
                    bool vertical_20[20];
                    char c1 = voxmap.data[y*100*3+x*3+0];
                    char c2 = voxmap.data[y*100*3+x*3+1];
                    char c3 = voxmap.data[y*100*3+x*3+2];

                    vertical_20[0] = c1 & (1<<0);
                    vertical_20[1] = c1 & (1<<1);
                    vertical_20[2] = c1 & (1<<2);
                    vertical_20[3] = c1 & (1<<3);
                    vertical_20[4] = c1 & (1<<4);
                    vertical_20[5] = c1 & (1<<5);
                    vertical_20[6] = c1 & (1<<6);
                    vertical_20[7] = c1 & (1<<7);

                    vertical_20[8] = c2 & (1<<0);
                    vertical_20[9] = c2 & (1<<1);
                    vertical_20[10] = c2 & (1<<2);
                    vertical_20[11] = c2 & (1<<3);
                    vertical_20[12] = c2 & (1<<4);
                    vertical_20[13] = c2 & (1<<5);
                    vertical_20[14] = c2 & (1<<6);
                    vertical_20[15] = c2 & (1<<7);

                    vertical_20[16] = c3 & (1<<0);
                    vertical_20[17] = c3 & (1<<1);
                    vertical_20[18] = c3 & (1<<2);
                    vertical_20[19] = c3 & (1<<3);

                    for(int z=0;z<snapshot_z;z++)
                    {
                        if(vertical_20[z])
                        {
                            Eigen::Vector4d d;
                            d(0) = (x+CENTRE_OFFSET_M/VOXEL_SIZE_M-CHUNK_SIDE_SIZE_VOXEL*(5)+floor(tanslations[i](0)/VOXEL_SIZE_M))*VOXEL_SIZE_M-CENTRE_OFFSET_M;
                            d(1) = (y+CENTRE_OFFSET_M/VOXEL_SIZE_M-CHUNK_SIDE_SIZE_VOXEL*(5)+floor(tanslations[i](1)/VOXEL_SIZE_M))*VOXEL_SIZE_M-CENTRE_OFFSET_M;
                            d(2) = (z+CENTRE_OFFSET_M/VOXEL_SIZE_M-CHUNK_SIDE_SIZE_VOXEL*(1)+floor(tanslations[i](2)/VOXEL_SIZE_M))*VOXEL_SIZE_M-CENTRE_OFFSET_M;
                            d(3) = 0;

                            voxel_map_viewer_data.push_back(d);
                        }
                    }
                }
            }

            pangolin_viewer->send_voxel_map(voxel_map_viewer_data);

//            cv::imshow("voxmap",voxmap);  //-------------
//            cv::waitKey(100);
        }

#endif

#ifdef REPLAY_PTC

        // 显示点云模式
        point_cloud.clear();

        union short_char{
            char c[2];
            short int s;
        };
        short_char short_char_c1;
        short_char short_char_c2;
        short_char short_char_c3;

        char img_name_x[200];
        memset(img_name_x,0,200);
        strcat(img_name_x,(image_base_path+"/ptcx_").c_str());
        strcat(img_name_x,img_ct);
        strcat(img_name_x,".bmp");
        char img_name_y[200];
        memset(img_name_y,0,200);
        strcat(img_name_y,(image_base_path+"/ptcy_").c_str());
        strcat(img_name_y,img_ct);
        strcat(img_name_y,".bmp");
        char img_name_z[200];
        memset(img_name_z,0,200);
        strcat(img_name_z,(image_base_path+"/ptcz_").c_str());
        strcat(img_name_z,img_ct);
        strcat(img_name_z,".bmp");


        std::string fucking_name_x(img_name_x);
        std::string fucking_name_y(img_name_y);
        std::string fucking_name_z(img_name_z);

        cv::Mat ptcmap_x;
        cv::Mat ptcmap_y;
        cv::Mat ptcmap_z;
        ptcmap_x = cv::imread(fucking_name_x,1);
        ptcmap_y = cv::imread(fucking_name_y,1);
        ptcmap_z = cv::imread(fucking_name_z,1);

        //log3-------------------------
        if(!ptcmap_x.empty()&&!ptcmap_y.empty()&&!ptcmap_z.empty() ){
            for(int y=0;y<ptcmap_x.rows;y++)
            {
                for(int x=0;x<ptcmap_x.cols;x++)
                {
                    // 分别解码三个通道数据还原为float, 保存到点云中
                    short_char_c1.c[0] = ptcmap_x.data[y*ptcmap_x.cols*3+x*3+0];
                    short_char_c1.c[1] = ptcmap_x.data[y*ptcmap_x.cols*3+x*3+1];

                    short_char_c2.c[0] = ptcmap_y.data[y*ptcmap_x.cols*3+x*3+0];
                    short_char_c2.c[1] = ptcmap_y.data[y*ptcmap_x.cols*3+x*3+1];

                    short_char_c3.c[0] = ptcmap_z.data[y*ptcmap_x.cols*3+x*3+0];
                    short_char_c3.c[1] = ptcmap_z.data[y*ptcmap_x.cols*3+x*3+1];

                    double ptx = ((double)short_char_c1.s)/100.0f;
                    double pty = ((double)short_char_c2.s)/100.0f;
                    double ptz = ((double)short_char_c3.s)/100.0f;

                    point_cloud.push_back(cv::Point3d(ptx,pty,ptz));

//                cout<<ptx<<" | "<<pty<<" | "<<ptz<<endl;
                }
            }

            //------------------------------------------------
//            cv::imshow("ptcmap_x",ptcmap_x);
//            cv::imshow("ptcmap_y",ptcmap_y);
//            cv::imshow("ptcmap_z",ptcmap_z);
        }

#endif

        cout<<"near_ptcs ============================"<<near_ptcs[i]<<endl;
        cout<<"near_voxs ==============================="<<near_voxs[i]<<endl;

        /*
         * 显示位置和姿态
         */
        {
            Eigen::Matrix3d r;
            Eigen::Vector3d t;
            std::vector<cv::Point3d> voxel_3d_points;

            r = rotations[i];
            t = tanslations[i];

            cv::Mat rt_mat(3, 4, CV_32F);
            Eigen::Matrix4d pose_wc = Eigen::Matrix4d::Identity();
            for (int m = 0; m < 3; ++m) {
                for (int n = 0; n < 3; ++n) {
                    pose_wc(m, n) = r(m, n);
                    rt_mat.at<float>(m, n) = r(m, n);
                }
                pose_wc(m, 3) = t(m);
                rt_mat.at<float>(m, 3) = t(m);
            }
            std::vector<cv::Point3d> ref_points;
            std::vector<cv::Mat> kf_poses;

            pangolin_viewer->send_slam_data_to_viewer(rt_mat, point_cloud, ref_points, kf_poses);
//
//
//            pangolin_viewer->self_t = t;
//            pangolin_viewer->probe_vector = probes[i];
//            pangolin_viewer->control_vector = crtls[i];
        }

        char left_name[200];
        char right_name[200];
        memset(left_name,0,200);
        memset(right_name,0,200);

        strcat(left_name,(image_base_path+"/left_").c_str());
        strcat(right_name,(image_base_path+"/right_").c_str());
        strcat(left_name,img_ct);
        strcat(left_name,".bmp");
        strcat(right_name,img_ct);
        strcat(right_name,".bmp");
        std::string fucking_name_left(left_name);
        std::string fucking_name_right(right_name);

        cv::Mat left_rect = cv::imread(fucking_name_left,0);
        cv::Mat right_rect = cv::imread(fucking_name_right,0);

        cv::StereoBM bm;
        bm.state->preFilterCap = 31;
        bm.state->SADWindowSize = 21;
        bm.state->minDisparity = 0;
        bm.state->numberOfDisparities = 32;
        bm.state->textureThreshold = 10;
        bm.state->uniquenessRatio = 15;
        bm.state->speckleWindowSize = 100;
        bm.state->speckleRange = 32;
        bm.state->disp12MaxDiff = 1;

        if(!left_rect.empty()&&!right_rect.empty())
        {
            cv::Mat disparity;
            bm(left_rect, right_rect, disparity);
            cv::Mat disp8;
            disparity.convertTo(disp8, disparity.type(),64);

            //log1--------------------
            if(brake_cmd[i]){
                cv::putText(left_rect," BREAK ! ", cv::Point(100,100), CV_FONT_HERSHEY_PLAIN , 2, CV_RGB(250,250,250));
                cv::imshow("brake", left_rect);
            } else {
                cv::putText(left_rect," OK ", cv::Point(100,100), CV_FONT_HERSHEY_PLAIN , 2, CV_RGB(250,250,250));
                cv::imshow("brake", left_rect);
            }


            cv::imshow("left_img",left_rect);
            cv::imshow("right_img",right_rect);

            cv::line(disp8,cv::Point(0,240*0.3),cv::Point(320,240*0.3),cv::Scalar(255,255,255),1,CV_AA);
            cv::line(disp8,cv::Point(0,240*0.7),cv::Point(320,240*0.7),cv::Scalar(255,255,255),1,CV_AA);
            cv::imshow("disp",disp8);
        }

        cout<<"  brake : ==================================================        "<<brake_cmd[i]<<endl;

        int sleep_t = 200;

//        if(brake_cmd[i])  ///检测刹车, 停止播放, 但没用,不停
//        {
//            pause_ = true;
//        }

        int key_cmd = cv::waitKey(sleep_t);

        pause_ = pangolin_viewer->system_pause;

        if(pangolin_viewer->last_frame_t)
        {
            pause_ = false;
            i-=2;
            i=max((int)i,(int)0);
            pangolin_viewer->last_frame_t = false;
            continue;
        }
        else if(pangolin_viewer->next_frame_t)
        {
            pause_ = false;
            pangolin_viewer->next_frame_t = false;
            continue;
        }

        while(pause_){
            if(!left_rect.empty()&&!right_rect.empty())
            {
                cv::Mat disparity;
                bm(left_rect, right_rect, disparity);
                cv::Mat disp8;
                disparity.convertTo(disp8, disparity.type(),64);

                //log2--------------------
                if(brake_cmd[i]){
                    cv::putText(left_rect," BREAK! ", cv::Point(100,100), CV_FONT_HERSHEY_PLAIN , 2, CV_RGB(250,250,250));
                    cv::imshow("brake", left_rect);
                } else {
                    cv::putText(left_rect," OK ", cv::Point(100,100), CV_FONT_HERSHEY_PLAIN , 2, CV_RGB(250,250,250));
                    cv::imshow("brake", left_rect);
                }


                cv::imshow("left_img",left_rect);
                cv::imshow("right_img",right_rect);

                cv::line(disp8,cv::Point(0,240*0.3),cv::Point(320,240*0.3),cv::Scalar(255,255,255),1,CV_AA);
                cv::line(disp8,cv::Point(0,240*0.7),cv::Point(320,240*0.7),cv::Scalar(255,255,255),1,CV_AA);
                cv::imshow("disp",disp8);
            }

            int key_cmd = cv::waitKey(sleep_t);

            pause_ = pangolin_viewer->system_pause;

            if(pangolin_viewer->last_frame_t)
            {
                pause_ = false;
                i-=2;
                i=max((int)i,(int)0);
                pangolin_viewer->last_frame_t = false;
                continue;
            }
            else if(pangolin_viewer->next_frame_t)
            {
                pause_ = false;
                pangolin_viewer->next_frame_t = false;
                continue;
            }
        }

        if(i>=fnames.size()-1)i=0;
    }


    delete pangolin_viewer;


    return 0;
}


int main(int argc, char **argv) {

    cmdline::parser parser;
    parser.add<std::string>("imagepath", 'p', "image path", true);
    parser.parse_check(argc, argv);

    image_base_path = parser.get<std::string>("imagepath");     // 外部参数

    system(("grep time "+image_base_path+"/AutoPilot.std.log > "+image_base_path+"/data.log").c_str());

    sleep(1);

    run();

    return 0;
}



